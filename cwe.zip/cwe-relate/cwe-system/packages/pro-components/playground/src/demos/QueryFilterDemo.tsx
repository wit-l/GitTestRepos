import { Form, Input, Select } from "antd";

import { QueryFilter } from "../../../src";

export default function QueryFilterDemo() {
  return (
    <QueryFilter>
      <Form.Item name="username" label="用户名">
        <Input placeholder="请输入用户名" />
      </Form.Item>
      <Form.Item name="password" label="密码">
        <Input.Password placeholder="请输入密码" />
      </Form.Item>
      <Form.Item name="email" label="邮箱">
        <Input placeholder="请输入邮箱" />
      </Form.Item>
      <Form.Item name="phone" label="手机号">
        <Input placeholder="请输入手机号" />
      </Form.Item>
      <Form.Item name="status" label="状态">
        <Select
          placeholder="请选择状态"
          options={[
            { label: "启用", value: "1" },
            { label: "禁用", value: "0" },
          ]}
        />
      </Form.Item>
      <Form.Item name="address" label="地址">
        <Input placeholder="请输入地址" />
      </Form.Item>
    </QueryFilter>
  );
}
