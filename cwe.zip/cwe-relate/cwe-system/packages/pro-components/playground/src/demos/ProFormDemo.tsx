// import { Button, Col, Form, Input, message, Row, Space } from "antd";
// import { useState } from "react";

import { Form, Input, message } from "antd";

import { ProForm } from "../../../src/form";

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export default function ProFormDemo() {
  // const [radom, setRadom] = useState(() => Math.random());
  return (
    <>
      {/* <Button onClick={() => setRadom(Math.random())}>刷新</Button> */}

      <ProForm<{ name: string; age: number; email: string }>
        wrapperCol={{ span: 22 }}
        labelCol={{ span: 2 }}
        grid
        rowProps={{ gutter: 16 }}
        colProps={{ span: 12 }}
        onFinish={async (values) => {
          console.log(values);
          await delay(2000);
          message.success(JSON.stringify(values));
        }}
        // submitter={{
        //   render: (props, doms) => {
        //     return (
        //       <Row>
        //         <Col offset={1} span={12}>
        //           <Space>{doms}</Space>
        //         </Col>
        //       </Row>
        //     );
        //   },
        // }}
        // params={{ a: radom }}
        // requestDeps={[radom]}
        // request={async (params) => {
        //   console.log(params);
        //   await delay(5000);
        //   return { name: '张三', age: 18, email: 'a@qq.com' };
        // }}
      >
        <Form.Item name="name" label="姓名">
          <Input placeholder="请输入" />
        </Form.Item>
        <Form.Item name="age" label="年龄">
          <Input placeholder="请输入" />
        </Form.Item>
        <Form.Item name="email" label="邮箱">
          <Input placeholder="请输入" />
        </Form.Item>
        {/* <Row>
        <Col span={12}>
          <Form.Item name="name" label="姓名">
            <Input placeholder="请输入" />
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item name="email" label="邮箱">
            <Input placeholder="请输入" />
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item name="email" label="邮箱">
            <Input placeholder="请输入" />
          </Form.Item>
        </Col>
      </Row> */}
      </ProForm>
    </>
  );
}
