// import { DownloadOutlined, EllipsisOutlined, PlusOutlined } from "@ant-design/icons";
// import { Button, Dropdown, Image, Input, Space, Table, Tooltip } from "antd";
// import { useEffect, useRef, useState } from "react";

import { Image, Input } from "antd";
import { useRef } from "react";

import { ProTable } from "../../../src";
import type { ProColumnsType, ProTableActionType } from "../../../src";

interface DataType {
  address: string;
  avatar?: string;
  birthdate: string;
  city: string;
  createAt: string;
  email: string;
  gender: string;
  id: string;
  name: string;
}

const isNonNullable = <T,>(val: T): val is NonNullable<T> => val !== undefined && val !== null;

const toURLSearchParams = <T extends Record<PropertyKey, any>>(record: T) => {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(record)) {
    if (isNonNullable(value)) {
      params.append(key, value);
    }
  }
  return params;
};

export default function ProTableDemo() {
  const actionRef = useRef<ProTableActionType>(null);
  const columns: ProColumnsType<DataType>[] = [
    {
      title: "Name",
      dataIndex: "name",
      sorter: true,
      // hideInSetting: true,
      // hidden: true,
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Gender",
      dataIndex: "gender",
      filters: [
        { text: "Male", value: "male" },
        { text: "Female", value: "female" },
      ],
    },
    {
      title: "Birthday",
      dataIndex: "birthdate",
      sorter: true,
    },
    {
      title: "City",
      dataIndex: "city",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Address",
      dataIndex: "address",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Avatar",
      dataIndex: "avatar",
      render: (_, record) => record.avatar && <Image src={record.avatar} alt={record.name} width={30} />,
    },
    {
      title: "Email",
      dataIndex: "email",
    },
  ];

  return (
    <>
      {/* <Button onClick={() => actionRef.current?.reset()}>重置</Button>
      <Button onClick={() => actionRef.current?.reload()}>刷新</Button>
      <Button onClick={() => actionRef.current?.clearSelected()}>清空</Button> */}
      <ProTable<DataType>
        actionRef={actionRef}
        columns={columns}
        rowKey="id"
        focusTimespan={50_000}
        // columnsSettingConfig={{
        //   persistenceKey: 'test',
        //   persistenceType: 'localStorage',
        //   defaultValue: { name: { hidden: true, fixed: 'start' } },
        // }}
        // columnEmptyText="--"
        // onReset={() => {
        //   console.log('reset');
        // }}
        // onSearch={(params, filter, sort) => {
        //   console.log(params, filter, sort);
        // }}
        // loading

        // pagination={{ defaultPageSize: 5, defaultCurrent: 1 }}
        // pagination={{
        //   defaultCurrent: 2,
        //   // showTotal(total, range) {
        //   //   return `Total ${total} items`;
        //   // },
        // }}
        // pagination={false}

        // rowSelection={false}
        // rowSelection={{
        //   selections: [Table.SELECTION_ALL, Table.SELECTION_INVERT],
        //   defaultSelectedRowKeys: ['8'],
        //   preserveSelectedRowKeys: true,
        // }}
        // tableAlertInfoRender={({ selectedRowKeys, selectedRows, onClearSelected }) => {
        //   console.log(selectedRowKeys, selectedRows);
        //   return (
        //     <Space size={24}>
        //       <span>
        //         已选 {selectedRowKeys.length} 项
        //         <a style={{ marginInlineStart: 8 }} onClick={onClearSelected}>
        //           取消选择
        //         </a>
        //       </span>
        //       <span>{`选中 ids: ${selectedRows.map((item) => item.id).join(',')}`}</span>
        //     </Space>
        //   );
        // }}
        // tableAlertOptionRender={() => {
        //   return (
        //     <Space size={16}>
        //       <a>批量删除</a>
        //       <a>批量下载</a>
        //       <a>批量导出</a>
        //     </Space>
        //   );
        // }}

        // toolbar={false}
        // toolbar={{
        //   headerTitle: '测试标题',
        //   setting: (defaultSetting) => {
        //     return [
        //       ...defaultSetting,
        //       <Tooltip key="download" title="下载">
        //         <DownloadOutlined />
        //       </Tooltip>,
        //     ];
        //   },
        //   action: () => [
        //     <Space key="extra">
        //       <Button
        //         key="button"
        //         icon={<PlusOutlined />}
        //         onClick={() => {
        //           actionRef.current?.reload();
        //         }}
        //         type="primary"
        //       >
        //         新建
        //       </Button>
        //       <Dropdown
        //         key="menu"
        //         menu={{
        //           items: [
        //             { label: '导入数据', key: 'import' },
        //             { label: '导出数据', key: 'export' },
        //             { label: '批量分配', key: 'assign' },
        //           ],
        //         }}
        //       >
        //         <Button>
        //           <EllipsisOutlined />
        //         </Button>
        //       </Dropdown>
        //     </Space>,
        //   ],
        // }}
        request={async (params, filter, sort) => {
          console.log(params, filter, sort);
          const { current, pageSize, ...restParams } = params || {};

          const sortField = Array.isArray(sort) ? undefined : sort.field;
          const sortOrder = Array.isArray(sort) ? undefined : sort.order;

          const queryParams: any = {
            ...restParams,
            limit: pageSize,
            page: current,
          };

          if (sortField) {
            queryParams.orderby = sortField;
            queryParams.order = sortOrder === "ascend" ? "asc" : "desc";
          }

          if (filter) {
            Object.entries(filter).forEach(([key, value]) => {
              if (isNonNullable(value)) {
                queryParams[key] = value;
              }
            });
          }

          // await delay(3000);
          const response = await fetch(
            `https://660d2bd96ddfa2943b33731c.mockapi.io/api/users?${toURLSearchParams(queryParams)}`
          );

          const data = await response.json();
          return {
            data,
            total: 100,
          };
        }}
      />
    </>
  );
}
