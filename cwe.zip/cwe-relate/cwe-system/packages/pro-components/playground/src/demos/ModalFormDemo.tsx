import { Button, Form, Input, message /*  Row, Space, Col */ } from "antd";
// import { useState } from "react";

import { ModalForm /* ProForm */ } from "../../../src/form";

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export default function ModalFormDemo() {
  const [form] = ModalForm.useForm();

  return (
    <>
      {/* <Button onClick={() => setRadom(Math.random())}>刷新</Button> */}

      <ModalForm<{ name: string; age: number; email: string }>
        title="基础表单"
        form={form}
        // wrapperCol={{ span: 20 }}
        // labelCol={{ span: 4 }}
        // grid
        // rowProps={{ gutter: 16 }}
        // colProps={{ span: 24 }}
        onFinish={async (values) => {
          await delay(2000);
          message.success(JSON.stringify(values));
          return false;
        }}
        // onFinish={async (values) => {
        //   console.log(values);
        //   await delay(2000);
        //   message.success(JSON.stringify(values));
        // }}
        // params={{ a: radom }}
        // requestDeps={[radom]}
        request={async (params) => {
          console.log(params);
          await delay(1000);
          return { name: "张三", age: 18, email: "a@qq.com" };
        }}
        trigger={<Button type="primary">Open Modal</Button>}
        // modalProps={{
        //   footer(originNode, { CancelBtn, OkBtn }) {
        //     return (
        //       <Space>
        //         <CancelBtn />
        //         <OkBtn />
        //         <Button
        //           type="primary"
        //           onClick={() => {
        //             form.setFieldsValue({ age: 24 });
        //           }}
        //         >
        //           Change Age
        //         </Button>
        //       </Space>
        //     );
        //   },
        // }}
      >
        <Form.Item name="name" label="姓名" rules={[{ required: true, message: "请输入姓名" }]}>
          <Input placeholder="请输入" />
        </Form.Item>
        <Form.Item name="age" label="年龄">
          <Input placeholder="请输入" />
        </Form.Item>
        <Form.Item name="email" label="邮箱">
          <Input placeholder="请输入" />
        </Form.Item>
        {/* <Row>
        <Col span={12}>
          <Form.Item name="name" label="姓名">
            <Input placeholder="请输入" />
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item name="email" label="邮箱">
            <Input placeholder="请输入" />
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item name="email" label="邮箱">
            <Input placeholder="请输入" />
          </Form.Item>
        </Col>
      </Row> */}
      </ModalForm>
    </>
  );
}
