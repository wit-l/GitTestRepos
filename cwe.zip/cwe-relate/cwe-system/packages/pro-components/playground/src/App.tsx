// import { Divider } from "antd";

import ModalFormDemo from "./demos/ModalFormDemo";
// import ProFormDemo from "./demos/ProFormDemo";
// import ProTableDemo from "./demos/ProTableDemo";
// import QueryFilterDemo from "./demos/QueryFilterDemo";
import ThemeProvider from "./ThemeProvider";

export function App() {
  return (
    <div style={{ padding: 20 }}>
      <ThemeProvider>
        {/* <QueryFilterDemo /> */}
        {/* <Divider /> */}
        {/* <ProTableDemo /> */}
        {/* <ProFormDemo /> */}
        <ModalFormDemo />
      </ThemeProvider>
    </div>
  );
}
