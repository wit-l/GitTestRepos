// import { App as AntApp } from "antd";
// import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import { App } from "./App";

import "./style.css";

createRoot(document.querySelector("#app")!).render(<App />);
