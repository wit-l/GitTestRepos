import { theme as antTheme, Button, ConfigProvider, Divider, Space } from "antd";
import type { MappingAlgorithm, ThemeConfig } from "antd";
import zhCN from "antd/es/locale/zh_CN";
import { useEffect, useMemo, useState } from "react";

interface ThemeProviderProps {
  children?: React.ReactNode;
}

const themeColorsPreset = [
  "#1677ff",
  "#1890ff",
  "#2f54eb",
  "#f1212c",
  "#f7531c",
  "#f7ab14",
  "#13bdbd",
  "#51c11a",
  "#13c2c2",
  "#722ed1",
  "#eb2f96",
];

export default function ThemeProvider(props: ThemeProviderProps) {
  const [isDark, setIsDark] = useState(false);
  const [primaryColor, setPrimaryColor] = useState<string>("#1677ff");

  useEffect(() => {
    if (document.documentElement.classList.contains("dark")) {
      setIsDark(true);
    }
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
  }, [isDark]);

  const combineTheme: ThemeConfig = useMemo(() => {
    const algorithm: MappingAlgorithm[] = [];
    if (isDark) {
      algorithm.push(antTheme.darkAlgorithm);
    }
    return {
      algorithm,
      token: {
        colorPrimary: primaryColor,
      },
      hashed: false,
    };
  }, [isDark, primaryColor]);

  return (
    <ConfigProvider theme={combineTheme} locale={zhCN}>
      <Space.Compact>
        <Button type="primary" onClick={() => setIsDark(!isDark)}>
          Toggle Theme
        </Button>
        {themeColorsPreset.map((color) => (
          <Button key={color} onClick={() => setPrimaryColor(color)} type="primary" style={{ backgroundColor: color }}>
            {color}
          </Button>
        ))}
      </Space.Compact>
      <Divider />
      {props.children}
    </ConfigProvider>
  );
}
