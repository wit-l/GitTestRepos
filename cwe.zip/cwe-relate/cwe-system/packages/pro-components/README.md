# ProComponents

此组件库并不基于 ProComponents 一比一实现其所有功能，仅结合项目来看，将常用的核心功能实现以增加灵活性和可维护性，但相对的，灵活的使用的成本就是更多的重复性配置。

为了更好的[摇树](https://rspack.rs/zh/guide/optimization/tree-shaking)优化，减少封装代码的复杂性，组件不实现 Schema 模式，所有的输入控件都由使用侧传入，组件内部仅做渲染的回调

该实现方式与 ProComponents 相比会增加部分样板代码的编写，整体使用体验并不及 ProComponents，因为 ProComponents 拥有极高的封装度核复杂度。但相较于常规 antd 组件，依然会减少较多的样板代码。

## TODO

### Global

- [ ] 单测，减少后续改动对已有功能的影响（WIP）

#### Hooks

- [x] useDefaultProps
- [x] useSemanticProps
- [ ] useAsync
- [ ] useTable

#### Components

- [x] QueryFilter
- [x] ProTable
- [x] ProForm
- [x] ProModal
- [ ] ProDrawer

### ProTable

- [x] 搜索控件支持隐藏和自定义
- [x] 传入 `manual` 是可以用 ref 手动控制，或者直接暴露一系列的 ref instance
- [x] ref 透出更多方法，同上
- [x] Toolbar 工具栏
  - [x] 支持自定义左侧和右侧区域
  - [x] 支持 `persistenceKey`（待定）
- [x] 支持多选操作栏
- [ ] 支持传入 params 参数覆盖内部管理的状态
- [x] 支持 `columnEmptyText` "-"
- [x] 支持 ErrorBoundary
- [x] 重写 useAntdTable 目前这个 hook 存在大量问题，基本无法用于生产，DX 体验也不好，后续需要参考 ahooks 的实现来重构

### ProField

- [x] Checkbox
- [x] Radio
- [x] Input
- [x] Select
- [x] TreeSelect
- [x] Cascader
- [x] DatePicker
- [x] RangePicker
- [x] TimePicker
- [x] InputNumber
- [x] TextArea
- [x] Switch
- [ ] Upload
- [ ] Slider
- [ ] ColorPicker
- [x] Rate

### ProForm

- [x] 支持 params 对 request 的影响

### ProModal

WIP

### ProDrawer

WIP

### 改进

- [ ] 添加排序和过滤的状态管理（优先级低）

ProTable 不计划支持混合排序，即前端和后端排序同时存在，这种情况会造成一些问题：

- 若混合排序，分页请求后端，但是部分排序是前端的，那么本地数据排序只会排当前页的数据，这并不合理
  - 例如：每页请求 10 条，本地排序也仅仅会排序这 10 条，此时会造成分页数量、页码与实际显示数据不符
  - 例如：在本地排序后，你可以在第 1 页总数 100 条的情况下看到仅显示 2 条数据
- 若需要本地数据排序，建议使用 `dataSource` 管理，传入 `dataSource` 时，ProTable 会视为纯前端数据，不会再做后端请求调用

## 注意事项

### props 合并规则

所有 props 都是浅合并，这意味着如果传递一个 props 为深层 object，那么会直接替换掉内部的同属性。

部分常用 props 会做额外的特殊处理，如：QueryFilter 的 `submitter` 属性，如果传递了 `submitter.submitButtonProps.loading`，那么不会影响 `submitter.submitButtonProps.type` 属性

目前额外处理（深合并）的 props 属性如下：

- QueryFilter `submitter`
- ProTable `pagination`
