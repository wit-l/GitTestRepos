import { ModalForm, ProFormInput } from "@cwe/pro-components";
import { Button, Form, Input, message } from "antd";

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export default function Demo() {
  return (
    <ModalForm<{ name: string; age: number; email: string }>
      title="基础表单"
      request={async (params) => {
        console.log(params);
        await delay(1000);
        return { name: "张三", age: 18, email: "a@qq.com" };
      }}
      onFinish={async (values) => {
        await delay(2000);
        message.success(JSON.stringify(values));
        return false;
      }}
      trigger={<Button type="primary">Open Modal</Button>}
    >
      <ProFormInput name="name" label="姓名" rules={[{ required: true, message: "请输入姓名" }]} />
      <Form.Item name="age" label="年龄">
        <Input placeholder="请输入" />
      </Form.Item>
      <Form.Item name="email" label="邮箱">
        <Input placeholder="请输入" />
      </Form.Item>
    </ModalForm>
  );
}
