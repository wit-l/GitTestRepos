import type { Meta, StoryObj } from "@storybook/react-vite";

import Basic from "./demos/basic";
import basicSource from "./demos/basic?raw";

const meta: Meta = { title: "ModalForm" };
export default meta;

type Story = StoryObj;

const sourceParams = (code: string) => ({
  docs: { source: { code, language: "tsx", type: "code" } },
});

export const BasicUsage: Story = {
  name: "基础使用",
  render: () => <Basic />,
  parameters: sourceParams(basicSource),
};
