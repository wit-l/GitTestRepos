import type { ProColumnsType } from "@cwe/pro-components";
import { ProTable } from "@cwe/pro-components";
import { Image, Input } from "antd";
import { useEffect, useState } from "react";

import type { DataType } from "./_utils/type";

/**
 * 本地数据排序 / 筛选：
 * - 受控化后由 ProTable 托管 filter / sort，重置时列头 UI 与数据一并复位
 * - 排序仍由 antd `sorter` 回调本地完成；筛选仍由 `onFilter` 本地完成
 */
export default function Demo() {
  const [dataSource, setDataSource] = useState<DataType[]>([]);
  const [loading, setLoading] = useState(false);

  // biome-ignore lint/correctness/useExhaustiveDependencies: <explanation> ignore
  useEffect(() => {
    getTableData();
  }, []);

  async function getTableData() {
    setLoading(true);
    const response = await fetch(`https://660d2bd96ddfa2943b33731c.mockapi.io/api/users?limit=100&page=1`);
    const data = await response.json();
    setDataSource(data);
    setLoading(false);
  }

  const columns: ProColumnsType<DataType>[] = [
    {
      title: "Name",
      dataIndex: "name",
      sorter: (a, b) => a.name.localeCompare(b.name),
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Gender",
      dataIndex: "gender",
      filters: [
        { text: "Male", value: "male" },
        { text: "Female", value: "female" },
      ],
      onFilter: (value, record) => record.gender === value,
    },
    {
      title: "Birthday",
      dataIndex: "birthdate",
      sorter: (a, b) => a.birthdate.localeCompare(b.birthdate),
    },
    {
      title: "City",
      dataIndex: "city",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Address",
      dataIndex: "address",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Avatar",
      dataIndex: "avatar",
      render: (_, record) => record.avatar && <Image src={record.avatar} alt={record.name} width={30} />,
    },
    {
      title: "Email",
      dataIndex: "email",
    },
  ];

  return <ProTable<DataType> columns={columns} rowKey="id" dataSource={dataSource} loading={loading} />;
}
