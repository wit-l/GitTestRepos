import type { ProColumnsType } from "@cwe/pro-components";
import { ProTable } from "@cwe/pro-components";
import { Image, Input } from "antd";
import qs from "query-string";

import parseRequestParams from "./_utils/parseParams";
import type { DataType } from "./_utils/type";

export default function Demo() {
  const columns: ProColumnsType<DataType>[] = [
    {
      title: "Name",
      dataIndex: "name",
      sorter: true,
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Gender",
      dataIndex: "gender",
      filters: [
        { text: "Male", value: "male" },
        { text: "Female", value: "female" },
      ],
      defaultFilteredValue: ["female"],
    },
    {
      title: "Birthday",
      dataIndex: "birthdate",
      sorter: true,
      defaultSortOrder: "descend",
    },
    {
      title: "City",
      dataIndex: "city",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Address",
      dataIndex: "address",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Avatar",
      dataIndex: "avatar",
      render: (_, record) => record.avatar && <Image src={record.avatar} alt={record.name} width={30} />,
    },
    {
      title: "Email",
      dataIndex: "email",
    },
  ];

  return (
    <ProTable<DataType>
      columns={columns}
      rowKey="id"
      request={async (params, filter, sort) => {
        console.log(params, filter, sort);
        const parseParams = parseRequestParams(params, filter, sort);

        const response = await fetch(
          `https://660d2bd96ddfa2943b33731c.mockapi.io/api/users?${qs.stringify(parseParams)}`
        );

        const data = await response.json();
        return {
          data,
          total: 100,
        };
      }}
    />
  );
}
