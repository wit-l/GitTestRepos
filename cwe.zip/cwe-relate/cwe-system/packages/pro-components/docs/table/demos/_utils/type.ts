export interface DataType {
  address: string;
  avatar?: string;
  birthdate: string;
  city: string;
  createAt: string;
  email: string;
  gender: string;
  id: string;
  name: string;
}
