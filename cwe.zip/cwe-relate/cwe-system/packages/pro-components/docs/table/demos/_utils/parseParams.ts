export default function parseRequestParams(params: any, filter: any, sort: any) {
  const { current, pageSize, ...restParams } = params || {};

  const sortField = Array.isArray(sort) ? undefined : sort.field;
  const sortOrder = Array.isArray(sort) ? undefined : sort.order;

  const queryParams = {
    ...restParams,
    limit: pageSize,
    page: current,
  };

  if (sortField) {
    queryParams.orderby = sortField;
    queryParams.order = sortOrder === "ascend" ? "asc" : "desc";
  }

  if (filter) {
    Object.entries(filter).forEach(([key, value]) => {
      if (value !== null || value !== undefined) {
        queryParams[key] = value;
      }
    });
  }

  return queryParams;
}
