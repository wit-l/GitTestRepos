import type { Meta, StoryObj } from "@storybook/react-vite";

import Basic from "./demos/basic";
import basicSource from "./demos/basic.tsx?raw";
import ColumnsSettingPersistence from "./demos/columns-setting-persistence";
import columnsSettingPersistenceSource from "./demos/columns-setting-persistence.tsx?raw";
import CustomToolbar from "./demos/custom-toolbar";
import customToolbarSource from "./demos/custom-toolbar.tsx?raw";
import FilterSortLocal from "./demos/filter-sort-local";
import filterSortLocalSource from "./demos/filter-sort-local.tsx?raw";
import FilterSortServer from "./demos/filter-sort-server";
import filterSortServerSource from "./demos/filter-sort-server.tsx?raw";
import LocalData from "./demos/local-data";
import localDataSource from "./demos/local-data.tsx?raw";
import MultipleSelect from "./demos/multiple-select";
import MultipleSelectCustom from "./demos/multiple-select-custom";
import multipleSelectCustomSource from "./demos/multiple-select-custom.tsx?raw";
import multipleSelectSource from "./demos/multiple-select.tsx?raw";

const meta: Meta = { title: "ProTable" };
export default meta;

type Story = StoryObj;

const sourceParams = (code: string) => ({
  docs: { source: { code, language: "tsx", type: "code" } },
});

export const BasicUsage: Story = {
  name: "基础使用",
  render: () => <Basic />,
  parameters: sourceParams(basicSource),
};

export const LocalDataSource: Story = {
  name: "dataSource 一次性渲染",
  render: () => <LocalData />,
  parameters: sourceParams(localDataSource),
};

export const CustomToolbarStory: Story = {
  name: "自定义 toolbar",
  render: () => <CustomToolbar />,
  parameters: sourceParams(customToolbarSource),
};

export const MultipleSelectStory: Story = {
  name: "开启 Table 多选",
  render: () => <MultipleSelect />,
  parameters: sourceParams(multipleSelectSource),
};

export const MultipleSelectCustomStory: Story = {
  name: "多选自定义操作栏",
  render: () => <MultipleSelectCustom />,
  parameters: sourceParams(multipleSelectCustomSource),
};

export const ColumnsSettingPersistenceStory: Story = {
  name: "列配置缓存",
  render: () => <ColumnsSettingPersistence />,
  parameters: sourceParams(columnsSettingPersistenceSource),
};

export const FilterSortServerStory: Story = {
  name: "筛选与排序（远程数据）",
  render: () => <FilterSortServer />,
  parameters: sourceParams(filterSortServerSource),
};

export const FilterSortLocalStory: Story = {
  name: "筛选与排序（本地数据）",
  render: () => <FilterSortLocal />,
  parameters: sourceParams(filterSortLocalSource),
};
