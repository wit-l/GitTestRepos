import type { Meta, StoryObj } from "@storybook/react-vite";

import Basic from "./demos/basic";
import basicSource from "./demos/basic?raw";
import CustomSubmitter from "./demos/custom-submitter";
import customSubmitterSource from "./demos/custom-submitter?raw";
import FormItem from "./demos/form-item";
import formItemSource from "./demos/form-item?raw";
import GridForm from "./demos/grid-form";
import gridSource from "./demos/grid-form?raw";
import RequestParam from "./demos/request-param";
import requestParamSource from "./demos/request-param?raw";

const meta: Meta = { title: "ProForm" };
export default meta;

type Story = StoryObj;

const sourceParams = (code: string) => ({
  docs: { source: { code, language: "tsx", type: "code" } },
});

export const BasicUsage: Story = {
  name: "基础使用",
  render: () => <Basic />,
  parameters: sourceParams(basicSource),
};

export const FormItemStory: Story = {
  name: "增强的 FormItem",
  render: () => <FormItem />,
  parameters: sourceParams(formItemSource),
};

export const CustomSubmitterStory: Story = {
  name: "自定义 Submitter",
  render: () => <CustomSubmitter />,
  parameters: sourceParams(customSubmitterSource),
};

export const GridFormStory: Story = {
  name: "Form Grid 布局",
  render: () => <GridForm />,
  parameters: sourceParams(gridSource),
};

export const RequestParamStory: Story = {
  name: "请求参数",
  render: () => <RequestParam />,
  parameters: sourceParams(requestParamSource),
};
