import { ProForm } from "@cwe/pro-components";
import { Input, message, Switch } from "antd";
import { useState } from "react";

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export default function Demo() {
  const [enableReadOnly, setEnableReadOnly] = useState(false);

  return (
    <>
      <div style={{ marginBottom: 16 }}>
        Switch ReadyOnly Mode：
        <Switch checked={enableReadOnly} onChange={setEnableReadOnly} />
      </div>

      <ProForm<{ name: string; age: number; email: string }>
        readonly={enableReadOnly}
        request={async () => {
          await delay(1000);
          return { name: "张三", age: 18, email: "a@qq.com" };
        }}
        onFinish={async (values) => {
          await delay(2000);
          message.success(JSON.stringify(values));
        }}
      >
        <ProForm.Item name="name" label="姓名">
          <Input placeholder="请输入" />
        </ProForm.Item>
        <ProForm.Item name="age" label="年龄" renderText={(value) => `Custom Render Age Value is ${value}`}>
          <Input placeholder="请输入" />
        </ProForm.Item>
        <ProForm.Item name="email" label="邮箱">
          <Input placeholder="请输入" />
        </ProForm.Item>
        <ProForm.Item name="address" label="地址" readonly={false}>
          <Input placeholder="单独设置的 readonly 优先级更高" />
        </ProForm.Item>
      </ProForm>
    </>
  );
}
