import { ProForm } from "@cwe/pro-components";
import { Button, Form, Input, message, Space } from "antd";

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export default function Demo() {
  return (
    <ProForm<{ name: string; age: number; email: string }>
      request={async (_params) => {
        await delay(1000);
        return { name: "张三", age: 18, email: "a@qq.com" };
      }}
      onFinish={async (values) => {
        await delay(2000);
        message.success(JSON.stringify(values));
      }}
      submitter={{
        render: (_props, doms) => (
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <Space>
              {doms}
              <Button type="primary" onClick={() => message.info("click extra button")}>
                Extra Button
              </Button>
            </Space>
          </div>
        ),
      }}
    >
      <Form.Item name="name" label="姓名">
        <Input placeholder="请输入" />
      </Form.Item>
      <Form.Item name="age" label="年龄">
        <Input placeholder="请输入" />
      </Form.Item>
      <Form.Item name="email" label="邮箱">
        <Input placeholder="请输入" />
      </Form.Item>
    </ProForm>
  );
}
