import { ProForm } from "@cwe/pro-components";
import { DatePicker, Form, Input } from "antd";

export default function Demo() {
  return (
    <ProForm grid rowProps={{ gutter: [16, 16] }} colProps={{ span: 12 }}>
      <Form.Item name="name" label="姓名">
        <Input placeholder="请输入" />
      </Form.Item>
      <Form.Item name="age" label="年龄">
        <Input placeholder="请输入" />
      </Form.Item>
      <Form.Item name="email" label="邮箱">
        <Input placeholder="请输入" />
      </Form.Item>
      <Form.Item name="address" label="地址">
        <Input placeholder="请输入" />
      </Form.Item>
      <Form.Item name="datetime" label="日期">
        <DatePicker style={{ width: "100%" }} />
      </Form.Item>

      <ProForm.Item name="description" label="描述" colProps={{ span: 24 }}>
        <Input.TextArea placeholder="请输入" />
      </ProForm.Item>
    </ProForm>
  );
}
