import type { Meta, StoryObj } from "@storybook/react-vite";

import ComposeForm from "./demos/compose-form";
import composeFormSource from "./demos/compose-form?raw";

const meta: Meta = { title: "ProFormFields" };
export default meta;

type Story = StoryObj;

const sourceParams = (code: string) => ({
  docs: { source: { code, language: "tsx", type: "code" } },
});

export const ComposeFormStory: Story = {
  name: "表单项",
  render: () => <ComposeForm />,
  parameters: sourceParams(composeFormSource),
};
