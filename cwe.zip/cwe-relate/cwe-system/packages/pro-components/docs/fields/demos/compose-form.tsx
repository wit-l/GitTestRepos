import {
  ProForm,
  ProFormCascader,
  ProFormCheckbox,
  ProFormDatePicker,
  ProFormInput,
  ProFormInputNumber,
  ProFormRadio,
  ProFormRate,
  ProFormSelect,
  ProFormSwitch,
  ProFormTimePicker,
  ProFormTreeSelect,
} from "@cwe/pro-components";
import { message, Space, Switch } from "antd";
import { useState } from "react";

interface UserValue {
  label: string;
  value: string;
  avatar?: string;
}

const treeSelectData = [
  {
    value: "p-1",
    text: "parent 1",
    children: [
      {
        value: "p-1-0",
        text: "parent 1-0",
        children: [
          { value: "l1", text: "leaf1" },
          { value: "l2", text: "leaf2" },
          { value: "l3", text: "leaf3" },
          { value: "l4", text: "leaf4" },
          { value: "l5", text: "leaf5" },
          { value: "l6", text: "leaf6" },
        ],
      },
      {
        value: "p-1-1",
        text: "parent 1-1",
        children: [{ value: "l11", text: <b style={{ color: "#08c" }}>leaf11</b> }],
      },
    ],
  },
];

const cascaderData = [
  {
    value: "zhejiang",
    label: "浙江",
    children: [
      {
        value: "hangzhou",
        label: "杭州",
        children: [
          { value: "xihu", label: "西湖" },
          { value: "xiasha", label: "下沙" },
        ],
      },
    ],
  },
  {
    value: "jiangsu",
    label: "江苏",
    children: [
      {
        value: "nanjing",
        label: "南京",
        children: [{ value: "zhonghuamen", label: "中华门" }],
      },
    ],
  },
];

export default function Demo() {
  const [readyOnly, setReadyOnly] = useState(false);
  return (
    <>
      <Switch
        style={{ marginBottom: 16 }}
        checked={readyOnly}
        onChange={setReadyOnly}
        checkedChildren="Edit"
        unCheckedChildren="readonly"
      />

      <ProForm
        readonly={readyOnly}
        layout="vertical"
        grid
        rowProps={{ gutter: 16 }}
        colProps={{ span: 6 }}
        submitter={{ render: (_, defaultDom) => <Space>{defaultDom}</Space> }}
        onFinish={(values) => {
          message.success(JSON.stringify(values));
        }}
        initialValues={{
          input: "Hello World!",
          password: "cwe123456",
          textarea: "This is a textarea.\nThis is a second line.",
          select: "54",
          inputNumber: 100,
          // switch: true,
          rate: 3,
          checkbox: true,
          checkboxGroup: ["Apple", "Orange"],
          radioGroup: "Option 1",
        }}
      >
        <ProFormInput name="input" label="Input" />
        <ProFormInput.Password name="password" label="Password" />
        <ProFormInput.TextArea name="textarea" label="Textarea" />
        <ProFormSelect<string>
          name="select"
          label="Select"
          showSearch
          fieldProps={{ optionLabelProp: "label" }}
          // showSearch={{ filterOption: false }}
          // initialValue={'54'}
          // mode="multiple"
          // separator=" / " // 自定义只读模式下的分隔符
          request={async (value) =>
            fetch(`https://660d2bd96ddfa2943b33731c.mockapi.io/api/users/?search=${value}`)
              .then((res) => res.json())
              .then((res) => {
                const results = Array.isArray(res) ? res : [];
                return results.map<UserValue>((user) => ({
                  label: user.name,
                  value: user.id,
                }));
              })
          }
        />
        <ProFormInputNumber
          fieldProps={{ style: { width: "100%" }, controls: false, suffix: "元" }}
          name="inputNumber"
          label="InputNumber"
        />
        <ProFormSwitch name="switch" label="Switch" checkedChildren="开" unCheckedChildren="关" />
        <ProFormRate name="rate" label="Rate" />
        <ProFormCheckbox name="checkbox" label="Checkbox">
          Checkbox
        </ProFormCheckbox>
        <ProFormCheckbox.Group name="checkboxGroup" label="CheckboxGroup" options={["Apple", "Pear", "Orange"]} />

        <ProFormRadio.Group name="radioGroup" label="RadioGroup" options={["Option 1", "Option 2", "Option 3"]} />

        <ProFormDatePicker name="datePicker" label="DatePicker" fieldProps={{ style: { width: "100%" } }} />
        <ProFormDatePicker.RangePicker
          name="dateRangePicker"
          label="DateRangePicker"
          fieldProps={{ style: { width: "100%" } }}
        />

        <ProFormTimePicker name="timePicker" label="TimePicker" fieldProps={{ style: { width: "100%" } }} />
        <ProFormTimePicker.RangePicker
          name="timeRangePicker"
          label="TimeRangePicker"
          fieldProps={{ style: { width: "100%" } }}
        />

        <ProFormTreeSelect
          name="treeSelect"
          label="TreeSelect"
          fieldNames={{ label: "text" }}
          treeData={treeSelectData}
        />

        <ProFormCascader
          multiple
          name="cascader"
          label="Cascader"
          fieldProps={{ style: { width: "100%" } }}
          options={cascaderData}
        />
      </ProForm>
    </>
  );
}
