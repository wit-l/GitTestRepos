import pluginBabel from "@rolldown/plugin-babel";
import { reactCompilerPreset } from "@vitejs/plugin-react";
import { defineConfig } from "tsdown";

// const isDev = process.env.NODE_ENV === "development";

export default defineConfig({
  dts: true,
  platform: "neutral",
  target: ["es2022"],
  entry: ["./src/index.ts"],
  unbundle: true,
  logLevel: "warn",
  // inputOptions: {
  //   transform: {
  //     jsx: 'react',
  //   },
  // },
  plugins: [
    pluginBabel({
      presets: [reactCompilerPreset()],
    }),
  ],
});
