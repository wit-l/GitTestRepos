import { useControlledState, useEvent } from "@rc-component/util";
import { cloneElement } from "react";

import type { Updater } from "../../_common/type";

export interface OverlayOptions {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  trigger?: React.JSX.Element;
}
export default function useOverlay(options: OverlayOptions) {
  const { open: propOpen, trigger, onOpenChange } = options;
  const [open, setOpenInner] = useControlledState(false, propOpen);

  const setOpen: Updater<boolean> = useEvent((updater) => {
    setOpenInner((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      onOpenChange?.(next);
      return next;
    });
  });

  const triggerDom = trigger
    ? cloneElement(trigger, {
        ...trigger.props,
        onClick: (e: any) => {
          trigger.props?.onClick?.(e);
          setOpen(true);
        },
      })
    : null;

  return { open, setOpen, triggerDom };
}
