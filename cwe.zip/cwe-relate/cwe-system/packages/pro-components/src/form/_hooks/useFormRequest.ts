import useAsync from "../../_hook/useAsync";

export interface UseFormRequestOptions<Values, Params> {
  request?: (params?: Params) => Promise<Values>;
  params?: Params;
  requestDeps?: React.DependencyList;
  ready?: boolean;
}

export default function useFormRequest<Values = any, Params = any>(options: UseFormRequestOptions<Values, Params>) {
  const { request, params, requestDeps = [], ready = true } = options;

  const result = useAsync(request, {
    ready,
    refreshDeps: requestDeps,
    defaultParams: [params],
    refreshDepsAction: () => {
      result.run(params);
    },
  });

  return {
    data: result.data,
    error: result.error,
    refresh: result.refresh,
    // request 没有传递时，首帧不应该显示 loading
    loading: !!request && result.loading,
  };
}
