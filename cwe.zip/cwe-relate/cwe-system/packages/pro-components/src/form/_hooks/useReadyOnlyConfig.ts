import { useContext, useMemo } from "react";

import { ReadOnlyFormContext } from "../base/form-layout/context";

interface UseReadyOnlyConfigOptions {
  readonly?: boolean;
  emptyText?: React.ReactNode;
}

export default function useReadyOnlyConfig(options: UseReadyOnlyConfigOptions) {
  const { readonly, emptyText } = options;
  const context = useContext(ReadOnlyFormContext);

  return useMemo(
    () => ({ readonly: readonly ?? context.readonly, emptyText: emptyText ?? context.emptyText }),
    [context.emptyText, context.readonly, emptyText, readonly]
  );
}
