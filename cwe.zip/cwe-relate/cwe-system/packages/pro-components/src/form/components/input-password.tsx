import { EyeInvisibleOutlined, EyeOutlined } from "@ant-design/icons";
import { useControlledState, useEvent } from "@rc-component/util";
import { Input, Space } from "antd";
import type { PasswordProps } from "antd/es/input";

import type { Updater } from "../../_common/type";
import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../base/pure-form-item";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import { isNilOrEmptyStr } from "./_utils/util";

export interface ProFormInputPasswordProps<Values = any>
  extends Omit<PureFormLayoutItemProps<Values>, "children">, Pick<PasswordProps, "placeholder" | "value" | "onChange"> {
  /**
   * @description 是否打开密码 仅 readonly 模式下生效
   */
  open?: boolean;
  /**
   * @description 密码可见更改时触发 仅 readonly 模式下生效
   */
  onOpenChange?: (open: boolean) => void;
  fieldProps?: PasswordProps;
}

function InternalProFormInputPassword<Values = any>(props: ProFormInputPasswordProps<Values>) {
  const {
    // top level input password props
    value,
    onChange,
    placeholder = "请输入",

    // readonly props
    open: propOpen,
    onOpenChange,

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });
  const [open, setOpenInner] = useControlledState(false, propOpen);

  const setOpen: Updater<boolean> = useEvent((updater) => {
    setOpenInner((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      onOpenChange?.(next);
      return next;
    });
  });

  const renderText = (value?: Values) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(value);
    }

    if (isNilOrEmptyStr(value)) {
      return emptyText;
    }

    const { prefix = "", suffix = "" } = fieldProps || {};
    return (
      <>
        {prefix}
        <Space>
          <span>{open ? (value as string) : "********"}</span>
          <a onClick={() => setOpen(!open)}>{open ? <EyeOutlined /> : <EyeInvisibleOutlined />}</a>
        </Space>
        {suffix}
      </>
    );
  };

  return (
    <PureFormLayoutItem<Values> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Input.Password value={value} onChange={onChange} placeholder={placeholder} {...fieldProps} />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormInputPassword & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormInputPassword = InternalProFormInputPassword as CompoundedComponent;

ProFormInputPassword.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormInputPassword.displayName = "ProFormInputPassword";
}

export default ProFormInputPassword;
