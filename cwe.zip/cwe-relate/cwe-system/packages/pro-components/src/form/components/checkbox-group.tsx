import { Checkbox, ConfigProvider } from "antd";
import type { CheckboxGroupProps, CheckboxOptionType } from "antd/es/checkbox";
import clsx from "clsx";
import { useContext, useMemo } from "react";

import useAntdStyle from "../../theme/useAntdStyle";
import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import PureFormLayoutItem from "../base/pure-form-item";
import renderGroupText from "./_utils/render-group-text";

export interface ProFormCheckboxGroupProps<T = any>
  extends Omit<PureFormLayoutItemProps<T>, "children">, Pick<CheckboxGroupProps<T>, "value" | "onChange" | "options"> {
  /**
   * @description `valueEnum` 属于 `options` 的一个变体属性，将 `{y: x}` 转换成 `{label: x, value: y}`
   *
   * 当 `options` 传递时，此属性无效
   */
  valueEnum?: Record<string, React.ReactNode>;
  /**
   * @description 布局方向（与 Radio 的属性保持一致）
   * @default 'horizontal'
   */
  orientation?: "horizontal" | "vertical";
  /**
   * @description 只读模式下的分隔符
   * @default ','
   */
  separator?: React.ReactNode;
  fieldProps?: CheckboxGroupProps<T>;
}

function normalizeValueEnum(valueEnum: Record<string, React.ReactNode>): CheckboxOptionType[] {
  return Object.entries(valueEnum).map(([value, label]) => ({ label, value }));
}

function InternalProFormCheckboxGroup<T = any>(props: ProFormCheckboxGroupProps<T>) {
  const {
    value,
    onChange,
    options: propOptions,

    valueEnum,
    orientation = "horizontal",
    separator = ",",

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const options = useMemo(() => {
    if (fieldProps?.options) {
      return fieldProps.options;
    }
    if (propOptions) {
      return propOptions;
    }
    if (valueEnum) {
      return normalizeValueEnum(valueEnum);
    }
    return undefined;
  }, [fieldProps?.options, propOptions, valueEnum]);

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (val?: T) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    return renderGroupText({ value: val, options, emptyText, separator: separator });
  };

  const { getPrefixCls } = useContext(ConfigProvider.ConfigContext);
  const prefixCls = getPrefixCls("pro-field");
  const componentCls = `${prefixCls}-checkbox-group`;

  const hashId = useAntdStyle("ProCheckbox", (token) => ({
    [`.${componentCls}`]: {
      "&-vertical": {
        [`&${token.antCls}-checkbox-group`]: {
          flexDirection: "column",
          rowGap: token.marginXS, // 和 radio 的 vertical 间距保持一致
        },
      },
      // TODO: radio 每一个 label 有一个 mr 8px 的间距 是否要保持一致
    },
  }));

  const { className, ...restFieldProps } = fieldProps || {};

  return (
    <PureFormLayoutItem<T> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Checkbox.Group<T>
        className={clsx(hashId, `${componentCls}-${orientation}`, className)}
        value={value}
        onChange={onChange}
        {...restFieldProps}
        options={options}
      />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormCheckboxGroup & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormCheckboxGroup = InternalProFormCheckboxGroup as CompoundedComponent;

ProFormCheckboxGroup.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormCheckboxGroup.displayName = "ProFormCheckboxGroup";
}

export default ProFormCheckboxGroup;
