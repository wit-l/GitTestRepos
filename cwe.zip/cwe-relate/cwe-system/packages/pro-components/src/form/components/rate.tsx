import { Rate } from "antd";
import type { RateProps } from "antd";
import { isNil } from "es-toolkit";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../base/pure-form-item";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";

export interface ProFormRateProps<Values = number>
  extends Omit<PureFormLayoutItemProps<Values>, "children">, Pick<RateProps, "value" | "onChange"> {
  fieldProps?: RateProps;
}

function InternalProFormRate<Values = number>(props: ProFormRateProps<Values>) {
  const {
    // top level rate props
    value,
    onChange,

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (value?: Values) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(value);
    }

    if (isNil(value)) {
      return emptyText;
    }

    return <Rate {...fieldProps} value={value as number} allowHalf disabled />;
  };

  return (
    <PureFormLayoutItem<Values> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Rate value={value} onChange={onChange} {...fieldProps} />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormRate & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormRate = InternalProFormRate as CompoundedComponent;

ProFormRate.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormRate.displayName = "ProFormRate";
}

export default ProFormRate;
