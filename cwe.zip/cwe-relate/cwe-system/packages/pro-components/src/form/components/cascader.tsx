import type { CascaderProps } from "antd";
import { Cascader, Space } from "antd";
import type { DefaultOptionType } from "antd/es/cascader";
import { isEmpty } from "es-toolkit/compat";
import { Fragment, useCallback, useMemo } from "react";

import useAsync from "../../_hook/useAsync";
import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import PureFormLayoutItem from "../base/pure-form-item";

export interface ProFormCascaderProps<
  OptionType extends DefaultOptionType = DefaultOptionType,
  ValueField extends keyof OptionType = keyof OptionType,
  Multiple extends boolean = boolean,
>
  extends
    Omit<PureFormLayoutItemProps, "children">,
    Pick<
      CascaderProps<OptionType, ValueField, Multiple>,
      "placeholder" | "options" | "value" | "onChange" | "fieldNames" | "allowClear" | "multiple" | "showSearch"
    > {
  /**
   * @description 远程加载 options（仅在 mount 时执行一次，不支持远程搜索）
   */
  request?: () => Promise<OptionType[]>;
  /**
   * @description 多选模式下，只读时多个值之间的分隔符
   * @default ','
   */
  separator?: React.ReactNode;
  fieldProps?: CascaderProps<OptionType, ValueField, Multiple>;
}

function buildValueLabelMap(options: any[], fieldNames: { label: any; value: any; children: any }): Map<any, any> {
  const { label: labelKey, value: valueKey, children: childrenKey } = fieldNames;
  const map = new Map();

  const traverse = (nodes: any[]) => {
    for (const node of nodes) {
      const val = node[valueKey];
      const lbl = node[labelKey];
      if (val !== undefined) {
        map.set(val, lbl);
      }
      const children = node[childrenKey];
      if (Array.isArray(children) && children.length) {
        traverse(children);
      }
    }
  };

  traverse(options);
  return map;
}

function InternalProFormCascader<
  ValueType = string[] | number[],
  OptionType extends DefaultOptionType = DefaultOptionType,
  ValueField extends keyof OptionType = keyof OptionType,
  Multiple extends boolean = boolean,
>(props: ProFormCascaderProps<OptionType, ValueField, Multiple>) {
  const {
    // top level cascader props
    fieldNames: propFieldNames,
    value,
    onChange,
    placeholder = "请选择",
    allowClear,
    multiple,
    showSearch,
    options: propOptions,

    request,
    separator = ",",

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  // ============================= Request / options =============================
  const { data: requestData } = useAsync(request, {
    ready: !propOptions && !fieldProps?.options && !request,
  });
  const mergedOptions = fieldProps?.options ?? propOptions ?? requestData;

  // ============================= Readonly Render =============================
  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const valueLabelMap = useMemo(() => {
    if (!mergedOptions) {
      return new Map();
    }
    return buildValueLabelMap(mergedOptions, {
      label: propFieldNames?.label ?? fieldProps?.fieldNames?.label ?? "label",
      value: propFieldNames?.value ?? fieldProps?.fieldNames?.value ?? "value",
      children: propFieldNames?.children ?? fieldProps?.fieldNames?.children ?? "children",
    });
  }, [mergedOptions, propFieldNames, fieldProps?.fieldNames]);

  const getLabelPathFast = useCallback(
    (valuePath: any[]): string[] => valuePath.map((v) => valueLabelMap.get(v) ?? String(v)),
    [valueLabelMap]
  );
  const renderText = (val?: ValueType): React.ReactNode => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    if (isEmpty(val)) {
      return emptyText;
    }

    // 多选模式：val 是二维数组，例如 [['zhejiang','hangzhou'], ['jiangsu','nanjing']]
    if (multiple && Array.isArray(val) && Array.isArray(val[0])) {
      const paths = val as unknown[][];
      return (
        <Space size={2} separator={separator} wrap>
          {paths.map((path, idx) => (
            <Fragment key={`cascader-${idx}`}>{getLabelPathFast(path).join(" / ")}</Fragment>
          ))}
        </Space>
      );
    }

    // 单选模式：val 是一维数组，例如 ['zhejiang', 'hangzhou', 'xihu']
    if (Array.isArray(val)) {
      return getLabelPathFast(val).join(" / ");
    }

    return val as React.ReactNode;
  };

  return (
    <PureFormLayoutItem<ValueType> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Cascader<OptionType, ValueField>
        allowClear={allowClear}
        placeholder={placeholder}
        value={value}
        // TODO: 消除 Cascader 的 ts 类型错误，暂时不知道怎么解决，抑制一下
        /* @ts-expect-error */
        onChange={onChange}
        options={mergedOptions}
        showSearch={showSearch}
        multiple={multiple}
        {...fieldProps}
        fieldNames={propFieldNames ?? fieldProps?.fieldNames}
      />
    </PureFormLayoutItem>
  );
}
type CompoundedComponent = typeof InternalProFormCascader & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormCascader = InternalProFormCascader as CompoundedComponent;

ProFormCascader.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormCascader.displayName = "ProFormCascader";
}

export default ProFormCascader;
