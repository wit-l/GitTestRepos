import type { TreeDataNode, TreeSelectProps } from "antd";
import { Space, Spin, TreeSelect } from "antd";
import { isEmpty } from "es-toolkit/compat";
import { Fragment, useCallback, useMemo } from "react";

import useAsync from "../../_hook/useAsync";
import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import PureFormLayoutItem from "../base/pure-form-item";

// 这两个类型基本属于复写 rc-tree-select 的类型，因为 antd 没有对外 export
interface ProDataNode extends Record<string, any>, Omit<TreeDataNode, "key" | "children"> {
  key?: React.Key;
  value?: Exclude<React.Key, bigint>;
  children?: ProDataNode[];
}

interface ProFieldNames {
  value?: string;
  label?: string;
  children?: string;
  _title?: string[];
}

export interface ProFormTreeSelectProps<ValueType = any>
  extends
    Omit<PureFormLayoutItemProps<ValueType>, "children">,
    Pick<
      TreeSelectProps<ValueType>,
      "placeholder" | "treeData" | "value" | "onChange" | "fieldNames" | "treeNodeLabelProp" | "allowClear" | "multiple"
    > {
  /**
   * @description 远程加载 treeData（仅在 mount 时执行一次，不支持远程搜索）
   */
  request?: () => Promise<any[]>;
  /**
   * @description 多选 / treeCheckable 模式下，只读时多个值之间的分隔符
   * @default ','
   */
  separator?: React.ReactNode;
  fieldProps?: TreeSelectProps<ValueType>;
}

// https://github.com/react-component/tree-select/blob/master/src/utils/valueUtil.ts#L6-L14
const fillFieldNames = (fieldNames?: ProFieldNames) => {
  const { label, value, children } = fieldNames || {};
  return {
    _title: label ? [label] : ["title", "label"],
    value: value || "value",
    key: value || "value",
    children: children || "children",
  };
};

function InternalProFormTreeSelect<ValueType = any, OptionType extends ProDataNode = ProDataNode>(
  props: ProFormTreeSelectProps<ValueType>
) {
  const {
    // top level tree select props
    fieldNames: propFieldNames,
    value,
    onChange,
    placeholder = "请选择",
    allowClear,
    treeNodeLabelProp,
    multiple,
    treeData: propTreeData,

    request,
    separator = ",",

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  // ============================= fieldNames =============================
  const privateFieldNames = useMemo(
    () => fillFieldNames(propFieldNames ?? fieldProps?.fieldNames),
    [propFieldNames, fieldProps?.fieldNames]
  );

  // ============================= Request / treeData =============================
  const { data: requestData, loading } = useAsync(request, {
    ready: !propTreeData && !fieldProps?.treeData,
  });
  const mergedTreeData = (fieldProps?.treeData ?? propTreeData ?? requestData) as OptionType[];

  // ============================= Readonly Render =============================
  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  // https://github.com/react-component/tree-select/blob/master/src/TreeSelect.tsx#L297-L316
  const getLabel = useCallback(
    (item?: OptionType) => {
      if (!item) {
        return undefined;
      }

      if (treeNodeLabelProp) {
        return item[treeNodeLabelProp];
      }

      // Loop from fieldNames
      const { _title: titleList } = privateFieldNames;
      for (const key of titleList) {
        const title = item[key];
        if (title !== undefined) {
          return title;
        }
      }
      return undefined;
    },
    [privateFieldNames, treeNodeLabelProp]
  );

  // 递归在 treeData 中查找匹配 value 的节点
  const findNode = useCallback(
    (data: OptionType[] | undefined, targetValue: any): OptionType | undefined => {
      if (!data) {
        return undefined;
      }
      for (const item of data) {
        if (item[privateFieldNames.value] === targetValue) {
          return item;
        }
        const found = findNode(item[privateFieldNames.children], targetValue);
        if (found) {
          return found;
        }
      }
      return undefined;
    },
    [privateFieldNames]
  );

  const renderText = (val?: ValueType) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    if (isEmpty(val)) {
      return emptyText;
    }

    // multiple / treeCheckable 模式
    if (Array.isArray(val)) {
      return (
        <Space size={2} separator={separator} wrap>
          {val.map((v, i) => (
            <Fragment key={`tree-select-${i}`}>{getLabel(findNode(mergedTreeData, v)) ?? v}</Fragment>
          ))}
        </Space>
      );
    }

    // 单选模式
    return getLabel(findNode(mergedTreeData, val)) ?? String(val);
  };

  return (
    <PureFormLayoutItem<ValueType> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <TreeSelect<ValueType, OptionType>
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        allowClear={allowClear}
        multiple={multiple}
        fieldNames={propFieldNames}
        treeNodeLabelProp={treeNodeLabelProp}
        notFoundContent={loading ? <Spin size="small" /> : undefined}
        {...fieldProps}
        treeData={mergedTreeData}
      />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormTreeSelect & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormTreeSelect = InternalProFormTreeSelect as CompoundedComponent;

ProFormTreeSelect.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormTreeSelect.displayName = "ProFormTreeSelect";
}

export default ProFormTreeSelect;
