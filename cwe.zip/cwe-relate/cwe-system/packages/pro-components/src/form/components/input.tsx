import { Input } from "antd";
import type { InputProps } from "antd";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../base/pure-form-item";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import ProFormInputPassword from "./input-password";
import ProFormTextArea from "./textarea";

export interface ProFormInputProps<Values = any>
  extends Omit<PureFormLayoutItemProps<Values>, "children">, Pick<InputProps, "placeholder" | "value" | "onChange"> {
  fieldProps?: InputProps;
}

function InternalProFormInput<Values = any>(props: ProFormInputProps<Values>) {
  const {
    // top level input props
    value,
    onChange,
    placeholder = "请输入",

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (value?: Values) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(value);
    }

    const { prefix = "", suffix = "" } = fieldProps || {};
    return (
      <>
        {prefix}
        {value ?? emptyText}
        {suffix}
      </>
    );
  };

  return (
    <PureFormLayoutItem<Values> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Input value={value} onChange={onChange} placeholder={placeholder} {...fieldProps} />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormInput & {
  Password: typeof ProFormInputPassword;
  TextArea: typeof ProFormTextArea;
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormInput = InternalProFormInput as CompoundedComponent;

ProFormInput.Password = ProFormInputPassword;
ProFormInput.TextArea = ProFormTextArea;
ProFormInput.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormInput.displayName = "ProFormInput";
}

export default ProFormInput;
