import { Checkbox } from "antd";
import type { CheckboxProps } from "antd";
import { isNil } from "es-toolkit";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../base/pure-form-item";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import ProFormCheckboxGroup from "./checkbox-group";

export interface ProFormCheckboxProps<Values = boolean>
  extends Omit<PureFormLayoutItemProps<Values>, "children">, Pick<CheckboxProps, "checked" | "onChange"> {
  children?: React.ReactNode;
  fieldProps?: Omit<CheckboxProps, "children">;
}

function InternalProFormCheckbox<Values = boolean>(props: ProFormCheckboxProps<Values>) {
  const {
    checked,
    onChange,
    children,

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (val?: Values) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    if (isNil(val)) {
      return emptyText;
    }

    return children;
  };

  return (
    <PureFormLayoutItem<Values>
      // see: https://ant.design/components/checkbox-cn#faq-form-item-limitations
      valuePropName="checked"
      {...formItemProps}
      readonly={readonly}
      emptyText={emptyText}
      renderText={renderText}
    >
      <Checkbox checked={checked} onChange={onChange} {...fieldProps}>
        {children}
      </Checkbox>
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormCheckbox & {
  Group: typeof ProFormCheckboxGroup;
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormCheckbox = InternalProFormCheckbox as CompoundedComponent;

ProFormCheckbox.Group = ProFormCheckboxGroup;
ProFormCheckbox.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormCheckbox.displayName = "ProFormCheckbox";
}

export default ProFormCheckbox;
