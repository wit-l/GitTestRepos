import type { DatePickerProps } from "antd";
import { DatePicker, Space } from "antd";
import type { Dayjs } from "dayjs";
import { isNil } from "es-toolkit";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import PureFormLayoutItem from "../base/pure-form-item";
import { formatDayjsToText, PICKER_FORMAT } from "./_utils/util";
import ProFormRangePicker from "./range-picker";

export interface ProFormDatePickerProps<ValueType = Dayjs, IsMultiple extends boolean = false>
  extends
    Omit<PureFormLayoutItemProps<ValueType>, "children">,
    Pick<
      DatePickerProps<ValueType, IsMultiple>,
      "placeholder" | "value" | "onChange" | "format" | "picker" | "allowClear" | "showTime"
    > {
  /**
   * @description 只读模式下的分隔符
   * @default ','
   */
  separator?: React.ReactNode;
  fieldProps?: DatePickerProps<ValueType, IsMultiple>;
}

const DATE_TIME_FORMAT = "YYYY-MM-DD HH:mm:ss";

function InternalProFormDatePicker<ValueType = Dayjs, IsMultiple extends boolean = false>(
  props: ProFormDatePickerProps<ValueType, IsMultiple>
) {
  const {
    // top level date picker props
    value,
    onChange,
    placeholder,
    format: propFormat,
    picker = "date",
    allowClear,
    showTime,

    separator = ",",

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (val?: ValueType) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    if (isNil(val)) {
      return emptyText;
    }

    const externalFormat = propFormat ?? fieldProps?.format;
    const externalShowTime = showTime ?? fieldProps?.showTime;
    const fallbackFormat = externalShowTime && picker === "date" ? DATE_TIME_FORMAT : PICKER_FORMAT[picker];

    if (Array.isArray(val)) {
      return (
        <Space size={2} separator={separator} wrap>
          {val.map((item, index) => (
            <span key={`date-picker-${index}`}>
              {formatDayjsToText({ value: item, format: externalFormat, fallbackFormat })}
            </span>
          ))}
        </Space>
      );
    }

    return formatDayjsToText({ value: val, format: externalFormat, fallbackFormat });
  };

  return (
    <PureFormLayoutItem<ValueType> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <DatePicker<ValueType, IsMultiple>
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        format={propFormat}
        picker={picker}
        allowClear={allowClear}
        showTime={showTime}
        {...fieldProps}
      />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormDatePicker & {
  displayName?: string;
  RangePicker: typeof ProFormRangePicker;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormDatePicker = InternalProFormDatePicker as CompoundedComponent;
ProFormDatePicker.RangePicker = ProFormRangePicker;
ProFormDatePicker.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormDatePicker.displayName = "ProFormDatePicker";
}

export default ProFormDatePicker;
