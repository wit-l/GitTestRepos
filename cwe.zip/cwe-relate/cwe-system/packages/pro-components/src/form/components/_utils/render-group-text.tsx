import { Space } from "antd";
import { Fragment } from "react";

import { isNilOrEmptyStr } from "./util";

interface FieldNamesType {
  label?: string;
  value?: string;
}

const findOptionLabel = (options?: any[], value?: any, filedNames?: FieldNamesType): React.ReactNode => {
  const { label: labelFieldName = "label", value: valueFieldName = "value" } = filedNames || {};

  const findData = options?.find((item) => {
    // 这里兼容的是 radio 和 checkbox
    if (typeof item === "string" || typeof item === "number") {
      return item === value;
    }
    // 这里是正常的 Select 等组件
    return item[valueFieldName as keyof typeof item] === value;
  });

  if (!findData) {
    return value;
  }

  if (typeof findData === "string" || typeof findData === "number") {
    return findData;
  }

  return findData[labelFieldName as keyof typeof findData] ?? value;
};

interface RenderGroupProps {
  value?: any;
  separator?: React.ReactNode;
  emptyText?: React.ReactNode;
  options?: any[];
  fieldNames?: FieldNamesType;
}
export default function renderGroupText(props?: RenderGroupProps) {
  const { value, separator, emptyText, options, fieldNames } = props || {};

  // 不过滤数字 0
  if (isNilOrEmptyStr(value) || (Array.isArray(value) && value.length === 0)) {
    return emptyText;
  }

  if (Array.isArray(value)) {
    return (
      <Space size={2} separator={separator} wrap>
        {value.map((v, i) => (
          <Fragment key={`group-separator-${i}`}>{findOptionLabel(options, v, fieldNames)}</Fragment>
        ))}
      </Space>
    );
  }

  return findOptionLabel(options, value, fieldNames);
}
