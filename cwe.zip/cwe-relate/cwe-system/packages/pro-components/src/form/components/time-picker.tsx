import { TimePicker } from "antd";
import type { TimePickerProps } from "antd";
import type { Dayjs } from "dayjs";
import { isNil } from "es-toolkit";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../base/pure-form-item";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import { formatDayjsToText } from "./_utils/util";
import ProFormRangePicker from "./range-picker";
import type { ProFormRangePickerProps } from "./range-picker";

export interface ProFormTimePickerProps<ValueType = Dayjs>
  extends
    Omit<PureFormLayoutItemProps<ValueType>, "children">,
    Pick<TimePickerProps, "placeholder" | "value" | "onChange" | "format" | "allowClear"> {
  fieldProps?: TimePickerProps;
}

const DEFAULT_TIME_FORMAT = "HH:mm:ss";

function InternalProFormTimePicker<ValueType = Dayjs>(props: ProFormTimePickerProps<ValueType>) {
  const {
    // top level time picker props
    value,
    onChange,
    placeholder,
    format: propFormat,
    allowClear,

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (val?: ValueType) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    if (isNil(val)) {
      return emptyText;
    }

    const externalFormat = propFormat ?? fieldProps?.format;

    return formatDayjsToText({
      value: val,
      format: externalFormat,
      fallbackFormat: DEFAULT_TIME_FORMAT,
    });
  };

  return (
    <PureFormLayoutItem<ValueType> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <TimePicker
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        format={propFormat}
        allowClear={allowClear}
        {...fieldProps}
      />
    </PureFormLayoutItem>
  );
}

export type ProFormTimeRangePickerProps = Omit<ProFormRangePickerProps, "picker">;

function ProFormTimeRangePicker<ValueType = Dayjs>(props: ProFormTimeRangePickerProps) {
  return <ProFormRangePicker<ValueType> {...props} picker="time" />;
}

type CompoundedComponent = typeof InternalProFormTimePicker & {
  RangePicker: typeof ProFormTimeRangePicker;
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormTimePicker = InternalProFormTimePicker as CompoundedComponent;
ProFormTimePicker.RangePicker = ProFormTimeRangePicker;
ProFormTimePicker.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormTimePicker.displayName = "ProFormTimePicker";
}

export default ProFormTimePicker;
