import { Switch } from "antd";
import type { SwitchProps } from "antd";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../base/pure-form-item";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";

export interface ProFormSwitchProps<Values = boolean>
  extends
    Omit<PureFormLayoutItemProps<Values>, "children">,
    Pick<SwitchProps, "value" | "onChange" | "checkedChildren" | "unCheckedChildren"> {
  fieldProps?: SwitchProps;
}

function InternalProFormSwitch<Values = boolean>(props: ProFormSwitchProps<Values>) {
  const {
    // top level switch props
    value,
    onChange,
    checkedChildren: propCheckedChildren,
    unCheckedChildren: propUnCheckedChildren,

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (value?: Values) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(value);
    }
    // 由于 Switch 必定会落在一侧，如果初始 undefined 显示 emptyText 会和视觉上有冲突
    // if (value === undefined || value === null) {
    //   return emptyText;
    // }
    const { checkedChildren = propCheckedChildren || "打开", unCheckedChildren = propUnCheckedChildren || "关闭" } =
      fieldProps || {};
    return value ? checkedChildren : unCheckedChildren;
  };

  return (
    <PureFormLayoutItem<Values> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Switch
        value={value}
        unCheckedChildren={propUnCheckedChildren}
        checkedChildren={propCheckedChildren}
        onChange={onChange}
        {...fieldProps}
      />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormSwitch & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormSwitch = InternalProFormSwitch as CompoundedComponent;

ProFormSwitch.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormSwitch.displayName = "ProFormSwitch";
}

export default ProFormSwitch;
