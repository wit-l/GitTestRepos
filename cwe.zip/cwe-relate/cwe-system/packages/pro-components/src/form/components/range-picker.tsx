import { DatePicker, Space } from "antd";
import type { Dayjs } from "dayjs";
import { isNil } from "es-toolkit";
import type React from "react";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import PureFormLayoutItem from "../base/pure-form-item";
import { formatDayjsToText, PICKER_FORMAT } from "./_utils/util";

type RangePickerProps = React.ComponentProps<typeof DatePicker.RangePicker>;

export type ProFormRangePickerValue<ValueType = Dayjs> = [ValueType | null, ValueType | null] | null;

export interface ProFormRangePickerProps
  extends
    Omit<PureFormLayoutItemProps, "children">,
    Pick<RangePickerProps, "placeholder" | "value" | "onChange" | "format" | "picker" | "allowClear" | "showTime"> {
  /**
   * @description 只读模式下的分隔符
   * @default '~'
   */
  separator?: React.ReactNode;
  fieldProps?: RangePickerProps;
}

const DATE_TIME_FORMAT = "YYYY-MM-DD HH:mm:ss";

function InternalProFormRangePicker<ValueType = Dayjs>(props: ProFormRangePickerProps) {
  const {
    // top level range picker props
    value,
    onChange,
    placeholder,
    format: propFormat,
    picker = "date",
    allowClear,
    showTime,

    separator = "~",

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (val?: ProFormRangePickerValue<ValueType>) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    if (isNil(val)) {
      return emptyText;
    }

    const externalFormat = propFormat ?? fieldProps?.format;
    const externalShowTime = showTime ?? fieldProps?.showTime;
    const fallbackFormat = externalShowTime && picker === "date" ? DATE_TIME_FORMAT : PICKER_FORMAT[picker];

    return (
      <Space size={2} separator={separator} wrap>
        {val.map((item, i) => (
          <span key={`range-picker-${i}`}>
            {isNil(item) ? emptyText : formatDayjsToText({ value: item, format: externalFormat, fallbackFormat })}
          </span>
        ))}
      </Space>
    );
  };

  return (
    <PureFormLayoutItem<ProFormRangePickerValue<ValueType>>
      {...formItemProps}
      readonly={readonly}
      emptyText={emptyText}
      renderText={renderText}
    >
      <DatePicker.RangePicker
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        format={propFormat}
        picker={picker}
        allowClear={allowClear}
        showTime={showTime}
        {...fieldProps}
      />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormRangePicker & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormRangePicker = InternalProFormRangePicker as CompoundedComponent;

ProFormRangePicker.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormRangePicker.displayName = "ProFormRangePicker";
}

export default ProFormRangePicker;
