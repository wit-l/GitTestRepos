import type { CheckboxOptionType } from "antd";
import { Radio } from "antd";
import type { RadioGroupProps } from "antd/es/radio";
import { useMemo } from "react";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import PureFormLayoutItem from "../base/pure-form-item";
import renderGroupText from "./_utils/render-group-text";

export interface ProFormRadioGroupProps<T = any>
  extends
    Omit<PureFormLayoutItemProps<T>, "children">,
    Pick<RadioGroupProps, "value" | "onChange" | "options" | "orientation"> {
  /**
   * @description `valueEnum` 属于 `options` 的一个变体属性，将 `{y: x}` 转换成 `{label: x, value: y}`
   *
   * 当 `options` 传递时，此属性无效
   */
  valueEnum?: Record<string, React.ReactNode>;
  /**
   * @description 只读模式下的分隔符
   * @default ','
   */
  separator?: React.ReactNode;
  fieldProps?: RadioGroupProps;
}

function normalizeValueEnum(valueEnum: Record<string, React.ReactNode>): CheckboxOptionType[] {
  return Object.entries(valueEnum).map(([value, label]) => ({ label, value }));
}

function InternalProFormRadioGroup<T = any>(props: ProFormRadioGroupProps<T>) {
  const {
    // top level radio group props
    value,
    onChange,
    options: propOptions,
    orientation,

    valueEnum,
    separator = ",",

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const options = useMemo(() => {
    if (fieldProps?.options) {
      return fieldProps.options;
    }
    if (propOptions) {
      return propOptions;
    }
    if (valueEnum) {
      return normalizeValueEnum(valueEnum);
    }
    return undefined;
  }, [fieldProps?.options, propOptions, valueEnum]);

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (val?: T) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    return renderGroupText({ value: val, options, emptyText, separator: separator });
  };

  return (
    <PureFormLayoutItem<T> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Radio.Group value={value} onChange={onChange} orientation={orientation} {...fieldProps} options={options} />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormRadioGroup & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormRadioGroup = InternalProFormRadioGroup as CompoundedComponent;

ProFormRadioGroup.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormRadioGroup.displayName = "ProFormRadioGroup";
}

export default ProFormRadioGroup;
