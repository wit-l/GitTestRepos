import { ConfigProvider, Input } from "antd";
import type { TextAreaProps } from "antd/es/input";
import clsx from "clsx";
import { useContext } from "react";

import useAntdStyle from "../../theme/useAntdStyle";
import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../base/pure-form-item";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";

export interface ProFormTextAreaProps<Values = any>
  extends Omit<PureFormLayoutItemProps<Values>, "children">, Pick<TextAreaProps, "placeholder" | "value" | "onChange"> {
  fieldProps?: TextAreaProps;
}

function InternalProFormTextArea<Values = any>(props: ProFormTextAreaProps<Values>) {
  const {
    // top level input textarea props
    value,
    onChange,
    placeholder = "请输入",

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const { getPrefixCls } = useContext(ConfigProvider.ConfigContext);
  const prefixCls = getPrefixCls("pro-field-readonly");
  const componentCls = `${prefixCls}-textarea`;

  const hashId = useAntdStyle("ProTextArea", (token) => ({
    [`.${componentCls}`]: {
      display: "inline-block",
      lineHeight: token.lineHeight,
      maxWidth: "100%",
      whiteSpace: "pre-wrap",
    },
  }));

  const renderText = (value?: Values) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(value);
    }

    return <span className={clsx(hashId, componentCls)}>{(value as string) ?? emptyText}</span>;
  };

  return (
    <PureFormLayoutItem<Values> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Input.TextArea value={value} onChange={onChange} placeholder={placeholder} {...fieldProps} />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormTextArea & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormTextArea = InternalProFormTextArea as CompoundedComponent;

ProFormTextArea.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormTextArea.displayName = "ProFormTextArea";
}

export default ProFormTextArea;
