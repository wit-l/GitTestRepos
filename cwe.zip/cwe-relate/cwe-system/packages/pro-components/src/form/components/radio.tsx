import { Radio } from "antd";
import type { RadioProps } from "antd";
import { isNil } from "es-toolkit";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../base/pure-form-item";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import ProFormRadioGroup from "./radio-group";

export interface ProFormRadioProps<Values = boolean>
  extends Omit<PureFormLayoutItemProps<Values>, "children">, Pick<RadioProps, "checked" | "onChange" | "children"> {
  fieldProps?: Omit<RadioProps, "children">;
}

// 6.x 的 antd Radio 单独使用其实是不可点击的，5.x 及之前并未存在这个问题
function InternalProFormRadio<Values = boolean>(props: ProFormRadioProps<Values>) {
  const {
    checked,
    onChange,
    children,

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (val?: Values) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    if (isNil(val)) {
      return emptyText;
    }

    return children;
  };

  return (
    <PureFormLayoutItem<Values> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Radio checked={checked} onChange={onChange} {...fieldProps}>
        {children}
      </Radio>
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormRadio & {
  Group: typeof ProFormRadioGroup;
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormRadio = InternalProFormRadio as CompoundedComponent;

ProFormRadio.Group = ProFormRadioGroup;
ProFormRadio.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormRadio.displayName = "ProFormRadio";
}

export default ProFormRadio;
