import type { DatePickerProps } from "antd";
import dayjs from "dayjs";
import { isNil } from "es-toolkit";

export function isNilOrEmptyStr(value: unknown): value is "" | null | undefined {
  return isNil(value) || value === "";
}

interface FormatDayjsToTextOptions {
  value: any;
  format?: any;
  fallbackFormat: string;
}
export function formatDayjsToText(options: FormatDayjsToTextOptions): string {
  const { value, format, fallbackFormat } = options;

  const dayjsValueOrValue = dayjs.isDayjs(value) ? value : dayjs(value);

  if (typeof format === "string") {
    return dayjsValueOrValue.format(format);
  }
  if (Array.isArray(format) && typeof format[0] === "string") {
    return dayjsValueOrValue.format(format[0]);
  }
  if (typeof format === "function") {
    return (format as (date: any) => string)(value);
  }

  return dayjsValueOrValue.format(fallbackFormat);
}

export const PICKER_FORMAT: Record<NonNullable<DatePickerProps["picker"]>, string> = {
  date: "YYYY-MM-DD",
  month: "YYYY-MM",
  quarter: "YYYY-[Q]Q",
  year: "YYYY",
  week: "YYYY-wo",
  time: "HH:mm:ss",
};
