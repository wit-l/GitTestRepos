import { InputNumber } from "antd";
import type { InputNumberProps } from "antd";

import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../base/pure-form-item";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import { isNilOrEmptyStr } from "./_utils/util";

type ValueType = string | number;

export interface ProFormInputNumberProps<T extends ValueType = ValueType>
  extends
    Omit<PureFormLayoutItemProps<T>, "children">,
    Pick<InputNumberProps<T>, "placeholder" | "value" | "onChange" | "max" | "min"> {
  fieldProps?: InputNumberProps<T>;
}

function InternalProFormInputNumber<T extends ValueType = ValueType>(props: ProFormInputNumberProps<T>) {
  const {
    // top level input number props
    value,
    onChange,
    placeholder = "请输入",
    max,
    min = 0 as T,

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  const renderText = (value?: T) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(value);
    }

    if (isNilOrEmptyStr(value)) {
      return emptyText;
    }

    const { prefix = "", suffix = "", formatter } = fieldProps || {};
    const displayValue = formatter ? formatter(value, { userTyping: false, input: String(value) }) : value;

    return (
      <>
        {prefix}
        {displayValue}
        {suffix}
      </>
    );
  };

  return (
    <PureFormLayoutItem<T> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <InputNumber<T> value={value} onChange={onChange} placeholder={placeholder} max={max} min={min} {...fieldProps} />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormInputNumber & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormInputNumber = InternalProFormInputNumber as CompoundedComponent;

ProFormInputNumber.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormInputNumber.displayName = "ProFormInputNumber";
}

export default ProFormInputNumber;
