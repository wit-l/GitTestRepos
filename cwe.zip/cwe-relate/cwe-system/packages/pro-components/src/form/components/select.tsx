import type { SelectProps } from "antd";
import { Select, Spin } from "antd";
import type { BaseOptionType, DefaultOptionType } from "antd/es/select";
import { debounce } from "es-toolkit";
import { useEffect, useMemo } from "react";

import useAsync from "../../_hook/useAsync";
import useReadyOnlyConfig from "../_hooks/useReadyOnlyConfig";
import type { PureFormLayoutItemProps } from "../base/pure-form-item";
import PureFormLayoutItem from "../base/pure-form-item";
import renderGroupText from "./_utils/render-group-text";

export type ProFormSelectOptions<OptionType extends BaseOptionType | DefaultOptionType = DefaultOptionType> =
  | OptionType[]
  | string[]
  | number[];

export interface ProFormSelectProps<
  Values = any,
  OptionType extends BaseOptionType | DefaultOptionType = DefaultOptionType,
>
  extends
    Omit<PureFormLayoutItemProps<Values>, "children">,
    Pick<
      SelectProps<Values, OptionType>,
      "placeholder" | "value" | "fieldNames" | "onChange" | "mode" | "allowClear" | "showSearch"
    > {
  /**
   * @description 扩展 Select options，支持 `string[]`
   *
   * 当 `fieldProps.options` 传入时，此属性无效
   */
  options?: ProFormSelectOptions<OptionType>;
  /**
   * @description `valueEnum` 属于 `options` 的一个变体属性，将 `{y: x}` 转换成 `{label: x, value: y}`
   *
   * 当 `options` 传递时，此属性无效
   */
  valueEnum?: Record<string, React.ReactNode>;
  /**
   * @description 远程请求 options，返回 `OptionType[]` 或 `string[]`
   *
   * 当 `options` |`valueEnum` | `fieldProps.options` 传递时，此属性无效
   *
   * **默认仅在 mount 时加载一次**，如果需要远程搜索，请传入 `showSearch={{ filterOption: false }}` 即关闭本地筛选
   */
  request?: (value: string) => Promise<ProFormSelectOptions<OptionType>>;
  /**
   * @description 远程搜索防抖时间，仅当 `request` 存在且 `showSearch.filterOption === false` 时生效
   *
   * 默认 `request` 仅在 mount 时加载一次；若需要边输入边远程查询，请显式传入 `showSearch={{ filterOption: false }}`
   * @default 250ms
   */
  debounceTime?: number;
  /**
   * @description `mode` 为 `'multiple'` 或 `'tags'` 时，且在只读模式下的分隔符
   * @default ','
   */
  separator?: React.ReactNode;
  fieldProps?: SelectProps<Values, OptionType>;
}

function normalizeValueEnum(valueEnum: Record<string, React.ReactNode>): DefaultOptionType[] {
  return Object.entries(valueEnum).map(([value, label]) => ({ label, value }));
}

function InternalProFormSelect<Values = any, OptionType extends BaseOptionType | DefaultOptionType = DefaultOptionType>(
  props: ProFormSelectProps<Values, OptionType>
) {
  const {
    // top level select props
    fieldNames: propFieldNames,
    value,
    onChange,
    mode,
    placeholder = "请选择",
    allowClear,
    showSearch: propShowSearch,

    options: propOptions,
    valueEnum,
    request,
    debounceTime = 250,
    separator = ",",

    fieldProps,
    readonly: propReadonly,
    emptyText: propEmptyText,
    ...formItemProps
  } = props;

  const fieldNames = fieldProps?.fieldNames ??
    propFieldNames ?? { label: "label", value: "value", options: "options", groupLabel: "label" };

  const {
    data: requestData,
    loading,
    run,
  } = useAsync(request, {
    ready: !fieldProps?.options && !propOptions && !valueEnum,
    defaultParams: [""], // 和 onChange 的 value 类型保持一致
  });

  const options: OptionType[] | undefined = useMemo(() => {
    // merged options
    const raw = fieldProps?.options ?? propOptions ?? (valueEnum ? normalizeValueEnum(valueEnum) : requestData);
    if (!raw) {
      return undefined;
    }

    if (raw.length > 0 && (typeof raw[0] === "string" || typeof raw[0] === "number")) {
      return (raw as string[]).map((item) => ({ label: item, value: item }) as OptionType);
    }
    return raw as OptionType[];
  }, [fieldProps?.options, propOptions, valueEnum, requestData]);

  // ============================= Readonly Render =============================
  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });
  const renderText = (val?: Values) => {
    if (formItemProps.renderText) {
      return formItemProps.renderText(val);
    }

    return renderGroupText({ value: val, options, emptyText, separator: separator, fieldNames });
  };

  // ============================= Search =============================
  const debouncedSearch = useMemo(() => debounce((v: string) => run(v), debounceTime), [run, debounceTime]);
  useEffect(() => debouncedSearch.cancel, [debouncedSearch]);

  const showSearch = useMemo<ProFormSelectProps<Values, OptionType>["showSearch"]>(() => {
    // 通常情况下，默认搜索的是 label，因此设为默认配置项
    const baseShowSearch = { optionFilterProp: "label" };

    // 无 request、showSearch 未传递、showSearch 为 true 或 false，这种情况下，一律不会发起远程请求
    if (!request || typeof propShowSearch === "boolean" || !propShowSearch) {
      if (propShowSearch === false) {
        return false;
      }
      return { ...baseShowSearch };
    }

    // 本地搜索，同样不发起远程请求
    if (propShowSearch?.filterOption !== false) {
      return { ...baseShowSearch, ...propShowSearch };
    }

    return {
      ...baseShowSearch,
      ...propShowSearch,
      onSearch: (v: string) => {
        propShowSearch.onSearch?.(v);
        debouncedSearch(v);
      },
    };
  }, [propShowSearch, request, debouncedSearch]);

  return (
    <PureFormLayoutItem<Values> {...formItemProps} readonly={readonly} emptyText={emptyText} renderText={renderText}>
      <Select
        showSearch={showSearch}
        allowClear={allowClear}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        mode={mode}
        options={options}
        loading={loading}
        notFoundContent={loading ? <Spin size="small" /> : undefined}
        {...fieldProps}
        fieldNames={fieldNames}
      />
    </PureFormLayoutItem>
  );
}

type CompoundedComponent = typeof InternalProFormSelect & {
  displayName?: string;
  /** @internal */
  __CWE_PRO_FIELD: boolean;
};

const ProFormSelect = InternalProFormSelect as CompoundedComponent;

ProFormSelect.__CWE_PRO_FIELD = true;

if (process.env.NODE_ENV !== "production") {
  ProFormSelect.displayName = "ProFormSelect";
}

export default ProFormSelect;
