import type { SubmitterProps } from "../../_common/Submitter";
import type { IAnyObject } from "../../_common/type";
import type { BaseFormLayoutProps, FormRequestProps } from "../base/form-layout/interface";

export interface ProFormProps<Values = any, Params = IAnyObject>
  extends Omit<BaseFormLayoutProps<Values>, "footerNode" | "footerInline">, FormRequestProps<Values, Params> {
  /**
   * @description 提交按钮 loading 状态，不传则内部受控
   */
  loading?: boolean;
  /**
   * @description 内部 submit loading 变更回调
   */
  onLoadingChange?: (loading: boolean) => void;
  /**
   * @description 提交按钮配置，false 表示不渲染
   */
  submitter?: SubmitterProps<Values> | false;
  /**
   * @description 表单提交，返回 Promise 时自动接管 loading
   */
  onFinish?: (values: Values) => Promise<void> | void;
}
