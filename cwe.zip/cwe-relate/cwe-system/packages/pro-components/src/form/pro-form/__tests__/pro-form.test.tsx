import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Input } from "antd";
import { describe, expect, it, vi } from "vitest";

import ProForm from "../index";

function renderForm(props?: any) {
  return render(
    <ProForm {...props}>
      <ProForm.Item name="name" label="姓名">
        <Input data-testid="input-name" />
      </ProForm.Item>
      <ProForm.Item name="email" label="邮箱">
        <Input data-testid="input-email" />
      </ProForm.Item>
    </ProForm>
  );
}

/** antd Button 在 cssVar 模式下 CJK 字符间会插入空格 */
function textMatcher(target: string) {
  return (content: string) => content.replaceAll(/\s/g, "") === target;
}

describe("ProForm", () => {
  it("渲染子元素和提交/重置按钮", () => {
    renderForm();

    expect(screen.getByTestId("input-name")).toBeInTheDocument();
    expect(screen.getByTestId("input-email")).toBeInTheDocument();
    expect(screen.getByText(textMatcher("提交"))).toBeInTheDocument();
    expect(screen.getByText(textMatcher("重置"))).toBeInTheDocument();
  });

  it("submitter=false 隐藏提交和重置按钮", () => {
    renderForm({ submitter: false });

    expect(screen.queryByText(textMatcher("提交"))).not.toBeInTheDocument();
    expect(screen.queryByText(textMatcher("重置"))).not.toBeInTheDocument();
  });

  it("自定义 submitter 文本", () => {
    renderForm({ submitter: { submitText: "保存", resetText: "清空" } });

    expect(screen.getByText(textMatcher("保存"))).toBeInTheDocument();
    expect(screen.getByText(textMatcher("清空"))).toBeInTheDocument();
  });

  it("onFinish 提交表单", async () => {
    const onFinish = vi.fn();
    renderForm({ onFinish });

    fireEvent.change(screen.getByTestId("input-name"), { target: { value: "test" } });
    fireEvent.change(screen.getByTestId("input-email"), { target: { value: "a@b.com" } });

    fireEvent.click(screen.getByText(textMatcher("提交")));

    await waitFor(() => {
      expect(onFinish).toHaveBeenCalledWith(expect.objectContaining({ name: "test", email: "a@b.com" }));
    });
  });

  it("点击重置恢复初始值", async () => {
    const onFinish = vi.fn();
    renderForm({ onFinish, initialValues: { name: "test", email: "a@b.com" } });

    // 先修改值
    fireEvent.change(screen.getByTestId("input-name"), { target: { value: "changed" } });

    // 重置恢复初始值
    fireEvent.click(screen.getByText(textMatcher("重置")));

    fireEvent.click(screen.getByText(textMatcher("提交")));
    await waitFor(() => {
      expect(onFinish).toHaveBeenCalledWith(expect.objectContaining({ name: "test", email: "a@b.com" }));
    });
  });

  it("request 异步加载表单数据", async () => {
    const request = vi.fn().mockResolvedValue({ name: "远程用户", email: "remote@test.com" });

    renderForm({ request });

    // 请求中渲染骨架屏
    expect(document.querySelector(".ant-skeleton")).toBeInTheDocument();

    // 请求完成后渲染表单
    await waitFor(() => {
      expect(screen.getByTestId("input-name")).toBeInTheDocument();
    });

    expect(request).toHaveBeenCalled();
  });

  it("空子元素不崩溃", () => {
    const { container } = render(<ProForm />);

    expect(container.querySelector("form")).toBeInTheDocument();
    expect(screen.getByText(textMatcher("提交"))).toBeInTheDocument();
  });
});
