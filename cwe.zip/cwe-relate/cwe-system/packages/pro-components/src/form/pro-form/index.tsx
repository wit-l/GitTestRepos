import { useControlledState, useEvent } from "@rc-component/util";
import { Form, Skeleton } from "antd";
import type { Store } from "antd/es/form/interface";
import { isPromise } from "es-toolkit";

import Submitter from "../../_common/Submitter";
import useFormRequest from "../_hooks/useFormRequest";
import BaseFormLayout from "../base/form-layout";
import type { ProFormProps } from "./interface";

function InternalProForm<Values extends Store = any>(props: ProFormProps<Values>) {
  const {
    // 提交相关
    loading,
    onFinish,
    onLoadingChange,
    submitter,

    // 请求相关
    request,
    params,
    requestDeps,
    initialValues,

    // 内容布局相关
    readonly,
    grid,
    rowProps,
    colProps,
    children,

    ...formProps
  } = props;

  const [submitLoading, setSubmitLoading] = useControlledState(false, loading);

  const onFormFinish = useEvent(async (values: Values) => {
    if (!onFinish) {
      return;
    }
    if (submitLoading) {
      return;
    }

    const maybePromiseFn = onFinish(values);
    if (!isPromise(maybePromiseFn)) {
      return;
    }

    setSubmitLoading(true);
    onLoadingChange?.(true);
    try {
      await maybePromiseFn;
    } finally {
      setSubmitLoading(false);
      onLoadingChange?.(false);
    }
  });

  const requestResult = useFormRequest<Values>({ request, params, requestDeps });

  // request 加载态：整体 Skeleton 占位（外层无外壳，直接顶替）
  if (request && requestResult.loading) {
    return <Skeleton active title={false} paragraph={{ rows: 4 }} />;
  }

  const isCustomRenderSubmitter = typeof submitter === "object" && !!submitter?.render;
  const submitterNode =
    submitter === false ? null : (
      <Submitter {...submitter} submitButtonProps={{ loading: submitLoading, ...submitter?.submitButtonProps }} />
    );

  return (
    <Form<Values>
      autoComplete="off"
      {...formProps}
      initialValues={requestResult.data ?? initialValues}
      onFinish={onFormFinish}
    >
      <BaseFormLayout
        readonly={readonly}
        grid={grid}
        rowProps={rowProps}
        colProps={colProps}
        footerNode={submitterNode}
        footerInline={!isCustomRenderSubmitter}
        labelCol={formProps.labelCol}
      >
        {children}
      </BaseFormLayout>
    </Form>
  );
}

type CompoundedComponent = typeof InternalProForm & {
  useForm: typeof BaseFormLayout.useForm;
  Item: typeof BaseFormLayout.Item;
  Unwrap: typeof BaseFormLayout.Unwrap;
  displayName?: string;
};

const ProForm = InternalProForm as CompoundedComponent;

ProForm.useForm = BaseFormLayout.useForm;
ProForm.Item = BaseFormLayout.Item;
ProForm.Unwrap = BaseFormLayout.Unwrap;

if (process.env.NODE_ENV !== "production") {
  ProForm.displayName = "ProForm";
}

export default ProForm;
