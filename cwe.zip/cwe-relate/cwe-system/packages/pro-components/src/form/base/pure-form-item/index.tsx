import { omit } from "@rc-component/util";
import { Form } from "antd";
import type { ColProps, FormItemProps } from "antd";

export interface PureFormLayoutItemProps<Values = any> extends FormItemProps<Values> {
  colProps?: ColProps;
  renderText?: (value?: Values) => React.ReactNode;
  readonly?: boolean;
  emptyText?: React.ReactNode;
}

/**
 *  Pure Form Item 不会消费 BaseForm 的 context，只在封装 ProField 组件时使用，ProFiled 始终自定义属性（context）值，因此消费 context 无意义
 *
 * Pro Form Item 则对外开放，基于 Pure Form Item 做消费 context 的封装
 *
 * 将两者拆开是为了减少重复的 context 消费，避免重复渲染
 */
function InternalPureFormItem<Values = any>(props: PureFormLayoutItemProps<Values>) {
  const {
    children,
    renderText,
    readonly: propReadonly,
    emptyText: propEmptyText,
    valuePropName,
    ...restProps
  } = omit(props, ["colProps"]);

  return (
    <Form.Item<Values> data-form-item-readonly={propReadonly} valuePropName={valuePropName} {...restProps}>
      {propReadonly ? (
        <ReadonlyView render={renderText} emptyText={propEmptyText} valuePropName={valuePropName} />
      ) : (
        children
      )}
    </Form.Item>
  );
}

interface ReadonlyFormItemViewProps<Values> {
  // 这个 value 是 antd 直接通过 cloneElement 注入的
  value?: Values;
  render?: (value?: Values) => React.ReactNode;
  emptyText?: React.ReactNode;
  valuePropName?: string;
}

function ReadonlyView<Values>(props: ReadonlyFormItemViewProps<Values>) {
  const { value, render, emptyText = "-", valuePropName } = props;
  // 这里需要兼容 Checkbox 的 checked 传递的 valuePropName="checked"
  //  https://ant.design/components/checkbox-cn#faq-form-item-limitations

  // 当传递 valuePropName 时，antd Form 会将注入的 value 这个字段替换成 valuePropName 的值，
  // 例：正常情况下，props: {value: xxx, ...}；当传递 valuePropName="checked" 时变成 --> props: {check: xxx, ...}
  const fieldValue = (valuePropName ? props[valuePropName as keyof typeof props] : value) as Values | undefined;

  if (render) {
    return render(fieldValue);
  }

  if (fieldValue === undefined || fieldValue === null || fieldValue === "") {
    return emptyText;
  }

  return fieldValue;
}

type CompoundedComponent = typeof InternalPureFormItem & {
  displayName?: string;
};

const PureFormItem = InternalPureFormItem as CompoundedComponent;

if (process.env.NODE_ENV !== "production") {
  PureFormItem.displayName = "PureFormItem";
}

export default PureFormItem;
