import { omit } from "@rc-component/util";

import useReadyOnlyConfig from "../../_hooks/useReadyOnlyConfig";
import PureFormLayoutItem from "../pure-form-item";
import type { PureFormLayoutItemProps } from "../pure-form-item";

export interface FormLayoutItemProps<Values = any> extends PureFormLayoutItemProps<Values> {}

function InternalFormLayoutItem<Values = any>(props: FormLayoutItemProps<Values>) {
  const { readonly: propReadonly, emptyText: propEmptyText, ...restProps } = omit(props, ["colProps", "renderText"]);

  const { readonly, emptyText } = useReadyOnlyConfig({ readonly: propReadonly, emptyText: propEmptyText });

  return (
    <PureFormLayoutItem<Values>
      data-form-item-readonly={readonly}
      readonly={readonly}
      emptyText={emptyText}
      {...restProps}
    />
  );
}

type CompoundedComponent = typeof InternalFormLayoutItem & {
  /** @internal */
  __CWE_PRO_FORM_ITEM: boolean;
  displayName?: string;
};

const FormLayoutItem = InternalFormLayoutItem as CompoundedComponent;

FormLayoutItem.__CWE_PRO_FORM_ITEM = true;

if (process.env.NODE_ENV !== "production") {
  FormLayoutItem.displayName = "FormLayoutItem";
}

export default FormLayoutItem;
