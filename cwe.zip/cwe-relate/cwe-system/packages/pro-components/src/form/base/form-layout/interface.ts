import type { ColProps, FormProps, RowProps } from "antd";

import type { IAnyObject } from "../../../_common/type";

/**
 * @description 表单请求相关的 props
 */
export interface FormRequestProps<Values = any, Params = IAnyObject> {
  /**
   * @description 请求函数，返回值会作为 initialValues 注入表单，会覆盖传入的 initialValues
   */
  request?: (params?: Params) => Promise<Values>;
  /**
   * @description 执行 request 的参数，会作为 request 函数的入参
   *
   * 注意：此参数本身**不**作为 effect deps 触发刷新，需要配合 `requestDeps` 控制刷新时机
   */
  params?: Params;
  /**
   * @description 重新执行 request 的依赖项，类似 useEffect 的 deps，值变化时会重新触发 request
   * @default []
   */
  requestDeps?: React.DependencyList;
}

/**
 * @description 表单布局相关的 props
 */
export interface FormLayoutProps {
  /**
   * @description 控制输入类组件的只读状态（仅对 ProFields 组件有效）
   */
  readonly?: boolean;
  /**
   * @description 只读的状态时，用于展示空值
   * @default '-'
   */
  emptyText?: React.ReactNode;
  /**
   * @description form children 之后的尾部节点（应用于提交按钮区域）。未传则不占用任何布局空间
   */
  footerNode?: React.ReactNode;
  /**
   * @description footer 是否参与 form 布局
   * @default true
   */
  footerInline?: boolean;
  /**
   * @description children render，用于自定义渲染
   */
  children?: React.ReactNode;
  /**
   * @description 是否启用 grid 布局（自动对 FormItem 嵌套 Row Col），仅 true 时， `rowProps` 和 `colProps` 生效
   */
  grid?: boolean;
  /**
   * @description `Row` props，仅在 `grid` 为 true 时生效
   */
  rowProps?: RowProps;
  /**
   * @description `Col` props，仅在 `grid` 为 true 时生效。可在子项 `BaseFormLayout.Item` 上传 `colProps` 单独覆盖
   */
  colProps?: ColProps;
}

export interface BaseFormLayoutProps<Values = any> extends Omit<FormProps<Values>, "children">, FormLayoutProps {}
