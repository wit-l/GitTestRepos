import { render, screen } from "@testing-library/react";
import { Button, Input } from "antd";
import { describe, expect, it } from "vitest";

import BaseFormLayout from "../form-layout";

function renderLayout(props?: any) {
  return render(<BaseFormLayout {...props} />);
}

const basicChildren = (
  <>
    <BaseFormLayout.Item name="name" label="姓名">
      <Input data-testid="input-name" />
    </BaseFormLayout.Item>
    <BaseFormLayout.Item name="email" label="邮箱">
      <Input data-testid="input-email" />
    </BaseFormLayout.Item>
  </>
);

describe("BaseFormLayout", () => {
  it("渲染子元素", () => {
    renderLayout({ children: basicChildren });

    expect(screen.getByTestId("input-name")).toBeInTheDocument();
    expect(screen.getByTestId("input-email")).toBeInTheDocument();
  });

  it("grid 模式渲染 Row/Col 布局", () => {
    const { container } = renderLayout({ children: basicChildren, grid: true });

    expect(container.querySelector(".ant-row")).toBeInTheDocument();
    expect(container.querySelector(".ant-col")).toBeInTheDocument();
  });

  it("readonly 模式下渲染文本而非输入框", () => {
    render(
      <BaseFormLayout readonly>
        <BaseFormLayout.Item name="name" label="姓名">
          <Input data-testid="input-name" />
        </BaseFormLayout.Item>
      </BaseFormLayout>
    );

    expect(screen.queryByTestId("input-name")).not.toBeInTheDocument();
  });

  it("渲染 footerNode", () => {
    renderLayout({
      children: basicChildren,
      footerNode: <Button data-testid="footer-btn">提交</Button>,
    });

    expect(screen.getByTestId("footer-btn")).toBeInTheDocument();
  });

  it("footerInline=false 时 footer 在 grid 外部", () => {
    renderLayout({
      children: basicChildren,
      grid: true,
      footerNode: <Button data-testid="footer-btn">提交</Button>,
      footerInline: false,
    });

    expect(screen.getByTestId("footer-btn")).toBeInTheDocument();
  });

  it("空子元素不崩溃", () => {
    const { container } = renderLayout();
    expect(container).toBeInTheDocument();
  });
});
