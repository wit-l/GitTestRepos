function InternalFormLayoutUnwrap({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

type CompoundedComponent = typeof InternalFormLayoutUnwrap & {
  /** @internal */
  __CWE_PRO_FORM_UN_WRAP: boolean;
  displayName?: string;
};

const FormLayoutUnwrap = InternalFormLayoutUnwrap as CompoundedComponent;

FormLayoutUnwrap.__CWE_PRO_FORM_UN_WRAP = true;

if (process.env.NODE_ENV !== "production") {
  FormLayoutUnwrap.displayName = "FormLayoutUnwrap";
}

export default FormLayoutUnwrap;
