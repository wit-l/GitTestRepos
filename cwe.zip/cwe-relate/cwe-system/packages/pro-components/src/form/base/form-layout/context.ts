import type { ColProps, RowProps } from "antd";
import { createContext } from "react";

export interface ReadOnlyFormContextValue {
  readonly: boolean;
  emptyText: React.ReactNode;
}

export const ReadOnlyFormContext = createContext<ReadOnlyFormContextValue>({
  readonly: false,
  emptyText: "-",
});

export interface GridFormContextValue {
  grid: boolean;
  rowProps?: RowProps;
  colProps?: ColProps;
}

export const GridFormContext = createContext<GridFormContextValue>({ grid: false });
