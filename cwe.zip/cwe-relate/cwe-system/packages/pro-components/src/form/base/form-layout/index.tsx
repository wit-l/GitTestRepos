import { merge, toArray } from "@rc-component/util";
import { Col, Form, Row } from "antd";
import type { ColProps } from "antd";

import { isCweProFormItem, isCweProFormItemUnwrap } from "../../../_common/is";
import FormLayoutItem from "../form-item";
import FormLayoutUnwrap from "../form-unwrap";
import { GridFormContext, ReadOnlyFormContext } from "./context";
import type { FormLayoutProps } from "./interface";

function InternalBaseFormLayout(props: FormLayoutProps & { labelCol?: ColProps }) {
  const {
    children,
    readonly = false,
    emptyText = "-",
    grid = false,
    rowProps,
    colProps,
    footerNode,
    footerInline = true,
    labelCol,
  } = props;

  const renderGridChildren = (nodes: React.ReactNode) => (
    <Row {...rowProps}>
      {toArray(nodes).map((child, index) => {
        // 为了解决 grid 布局下，无法指定非 ProField 组件 colProps 的问题
        // 比如 Table 需要 col 24，但是非 ProField 组件会自动包裹 Col 且不接受 colProps
        const isUnwrap = isCweProFormItemUnwrap(child);
        if (isUnwrap) {
          return child;
        }

        // 仅从带 flag 标记的 Pro 组件中提取 colProps
        const itemColProps = isCweProFormItem(child) ? child.props.colProps : undefined;
        const mergedColProps = merge(colProps || {}, itemColProps || {});

        return (
          <Col key={child?.key ?? `base-form-grid-item-${index}`} {...mergedColProps}>
            {child}
          </Col>
        );
      })}
    </Row>
  );

  const renderChildren = () => {
    // 无 footer：仅渲染 包装 Grid 的 children
    if (!footerNode) {
      return grid ? renderGridChildren(children) : children;
    }

    // inline：footer 受 form 布局控制，包一层 Form.Item（label 占位保证对齐）
    const wrapperFooterNode = footerInline ? (
      <Form.Item label={labelCol ? " " : undefined} colon={false}>
        {footerNode}
      </Form.Item>
    ) : (
      footerNode
    );

    // 非 grid：children + footer 顺序渲染
    if (!grid) {
      return (
        <>
          {children}
          {wrapperFooterNode}
        </>
      );
    }

    // grid + inline：footer 作为 Col 参与 Row
    if (footerInline) {
      return renderGridChildren([children, wrapperFooterNode]);
    }

    // grid + 自定义：footer 另起一行置于 Row 外
    return (
      <>
        {renderGridChildren(children)}
        {footerNode}
      </>
    );
  };

  return (
    <ReadOnlyFormContext.Provider value={{ readonly, emptyText }}>
      <GridFormContext.Provider value={{ grid, rowProps, colProps }}>{renderChildren()}</GridFormContext.Provider>
    </ReadOnlyFormContext.Provider>
  );
}

type CompoundedComponent = typeof InternalBaseFormLayout & {
  useForm: typeof Form.useForm;
  Item: typeof FormLayoutItem;
  Unwrap: typeof FormLayoutUnwrap;
  displayName?: string;
};

const BaseFormLayout = InternalBaseFormLayout as CompoundedComponent;

BaseFormLayout.useForm = Form.useForm;
BaseFormLayout.Item = FormLayoutItem;
BaseFormLayout.Unwrap = FormLayoutUnwrap;

if (process.env.NODE_ENV !== "production") {
  BaseFormLayout.displayName = "BaseFormLayout";
}

export default BaseFormLayout;
