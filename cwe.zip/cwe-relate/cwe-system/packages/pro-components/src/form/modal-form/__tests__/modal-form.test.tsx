import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Button, Input } from "antd";
import { describe, expect, it, vi } from "vitest";

import ModalForm from "../index";

function renderModal(props?: any) {
  return render(
    <ModalForm title="编辑" trigger={<Button data-testid="trigger-btn">打开</Button>} {...props}>
      <ModalForm.Item name="name" label="姓名">
        <Input data-testid="form-input" />
      </ModalForm.Item>
    </ModalForm>
  );
}

describe("ModalForm", () => {
  it("点击 trigger 打开弹窗", async () => {
    renderModal();

    expect(screen.queryByText("编辑")).not.toBeInTheDocument();

    fireEvent.click(screen.getByTestId("trigger-btn"));

    await waitFor(() => {
      expect(screen.getByText("编辑")).toBeInTheDocument();
    });
    expect(screen.getByTestId("form-input")).toBeInTheDocument();
  });

  it("受控 open 直接显示弹窗", () => {
    const onOpenChange = vi.fn();
    render(
      <ModalForm title="编辑" open onOpenChange={onOpenChange}>
        <ModalForm.Item name="name" label="姓名">
          <Input data-testid="form-input" />
        </ModalForm.Item>
      </ModalForm>
    );

    expect(screen.getByText("编辑")).toBeInTheDocument();
  });

  it("点击确定提交表单并调用 onFinish", async () => {
    const onFinish = vi.fn().mockResolvedValue(true);

    renderModal({ onFinish });

    fireEvent.click(screen.getByTestId("trigger-btn"));

    await waitFor(() => {
      expect(screen.getByText("编辑")).toBeInTheDocument();
    });

    // 确定按钮默认文本为 OK（antd locale 默认为英文）
    fireEvent.click(screen.getByText("OK"));

    await waitFor(() => {
      expect(onFinish).toHaveBeenCalled();
    });
  });

  it("loading 时不渲染表单内容", () => {
    render(
      <ModalForm title="编辑" loading>
        <ModalForm.Item name="name" label="姓名">
          <Input data-testid="form-input" />
        </ModalForm.Item>
      </ModalForm>
    );

    expect(screen.queryByTestId("form-input")).not.toBeInTheDocument();
  });
});
