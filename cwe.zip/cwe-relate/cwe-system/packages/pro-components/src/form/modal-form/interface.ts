import type { ModalProps } from "antd";

import type { IAnyObject } from "../../_common/type";
import type { BaseFormLayoutProps, FormRequestProps } from "../base/form-layout/interface";

export interface ModalFormProps<Values = any, Params = IAnyObject>
  extends
    Omit<BaseFormLayoutProps<Values>, "footerNode" | "footerInline" | "title" | "onFinish">,
    FormRequestProps<Values, Params> {
  title?: React.ReactNode;
  /**
   * @description 受控的弹层显示状态
   */
  open?: boolean;
  /**
   * @description 弹层显隐变化的回调
   */
  onOpenChange?: (open: boolean) => void;
  /**
   * @description 触发打开弹层的元素
   */
  trigger?: React.JSX.Element;
  /**
   * @description 提交按钮 loading 状态，不传则内部受控
   */
  loading?: boolean;
  /**
   * @description Modal 透传 prop
   */
  modalProps?: Omit<ModalProps, "open">;
  /**
   * @description Modal 宽度，等价于 modalProps.width 的快捷写法
   */
  width?: ModalProps["width"];
  /**
   * @description 提交回调执行完毕后，是否自动关闭弹层。 返回 true 自动关闭，false 或假值则不关闭
   */
  onFinish?: (values: Values) => Promise<boolean | undefined>;
}
