import { useControlledState } from "@rc-component/util";
import { Form, Modal } from "antd";
import type { Store } from "antd/es/form/interface";
import { isPromise } from "es-toolkit";

import useFormRequest from "../_hooks/useFormRequest";
import useOverlay from "../_hooks/useOverlay";
import BaseFormLayout from "../base/form-layout";
import type { ModalFormProps } from "./interface";

function InternalModalForm<Values extends Store = any>(props: ModalFormProps<Values>) {
  const {
    // Modal prop
    open: propOpen,
    onOpenChange,
    trigger,
    title,
    width,
    modalProps,

    // Form props
    loading: propLoading,
    form,
    onFinish,
    initialValues,

    // form request
    request,
    params,
    requestDeps,

    // form layout
    readonly,
    grid,
    rowProps,
    colProps,
    children,

    ...formProps
  } = props;

  const [baseForm] = Form.useForm<Values>(form);
  const [submitLoading, setSubmitLoading] = useControlledState(false, propLoading);

  const { triggerDom, open, setOpen } = useOverlay({
    open: propOpen,
    onOpenChange,
    trigger,
  });

  const onFinishWithPromise = async (values: Values) => {
    if (!onFinish) {
      return;
    }
    if (submitLoading) {
      return;
    }

    const maybePromiseFn = onFinish(values);
    if (!isPromise(maybePromiseFn)) {
      return;
    }

    setSubmitLoading(true);
    try {
      const result = await maybePromiseFn;
      if (result) {
        setOpen(false);
      }
    } finally {
      setSubmitLoading(false);
    }
  };

  const { destroyOnHidden = true, okButtonProps, onCancel, afterClose, ...restModalProps } = modalProps || {};
  const { loading, data } = useFormRequest<Values>({
    request,
    params,
    requestDeps,
    ready: open,
  });

  return (
    <>
      {triggerDom}
      <Modal
        title={title}
        width={width}
        open={open}
        destroyOnHidden={destroyOnHidden}
        loading={loading}
        {...restModalProps}
        okButtonProps={{ htmlType: "submit", loading: submitLoading, ...okButtonProps }}
        onCancel={(e) => {
          onCancel?.(e);
          setOpen(false);
        }}
        modalRender={(node) => {
          if (loading) {
            return node;
          }
          return (
            <Form<Values>
              autoComplete="off"
              {...formProps}
              form={baseForm}
              initialValues={data ?? initialValues}
              onFinish={onFinishWithPromise}
            >
              {node}
            </Form>
          );
        }}
        afterClose={() => {
          afterClose?.();
          // 在关闭动画结束后重置，避免在关闭过程中闪烁
          if (destroyOnHidden) {
            baseForm.resetFields();
          }
        }}
      >
        <BaseFormLayout readonly={readonly} grid={grid} rowProps={rowProps} colProps={colProps}>
          {children}
        </BaseFormLayout>
      </Modal>
    </>
  );
}

type CompoundedComponent = typeof InternalModalForm & {
  useForm: typeof BaseFormLayout.useForm;
  Item: typeof BaseFormLayout.Item;
  Unwrap: typeof BaseFormLayout.Unwrap;
  displayName?: string;
};

const ModalForm = InternalModalForm as CompoundedComponent;

ModalForm.useForm = BaseFormLayout.useForm;
ModalForm.Item = BaseFormLayout.Item;
ModalForm.Unwrap = BaseFormLayout.Unwrap;

if (process.env.NODE_ENV !== "production") {
  ModalForm.displayName = "ModalForm";
}

export default ModalForm;
