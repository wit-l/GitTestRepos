import type { FormProps, RowProps } from "antd";

import type { SubmitterProps } from "../_common/Submitter";

export interface ResizeBreakpoint {
  xs?: boolean;
  sm?: boolean;
  md?: boolean;
  lg?: boolean;
  xl?: boolean;
  xxl?: boolean;
  xxxl?: boolean;
}

export interface QueryFilterProps<Values = any> extends FormProps<Values> {
  children?: React.ReactNode;
  // Action
  collapsed?: boolean;
  defaultCollapsed?: boolean;

  // Layout
  /**
   * @default [24,24]
   */
  gutter?: RowProps["gutter"];
  /**
   * @description 此 span 的响应式断点是基于 QueryFilter 的宽度而非 window
   * @default { xs: 24, sm: 12, md: 8, lg: 8, xl: 8, xxl: 6, xxxl: 4 }
   */
  span?: number | { [key in keyof ResizeBreakpoint]?: number };
  /**
   * @default 80
   */
  labelWidth?: number | "auto";
  /**
   * @description 搜索提交按钮配置
   */
  submitter?: false | SubmitterProps;
}
