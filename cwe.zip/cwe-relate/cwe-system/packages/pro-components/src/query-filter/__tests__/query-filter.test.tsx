import { fireEvent, render, screen } from "@testing-library/react";
import { Form, Input } from "antd";
import { describe, expect, it } from "vitest";

import QueryFilter from "../query-filter";

/** antd Button 在 cssVar 模式下会在 CJK 字符间插入空格，去空白后匹配 */
function textMatcher(target: string) {
  return (content: string) => content.replaceAll(/\s/g, "") === target;
}

/** 获取包裹 Form.Item 的外部 Col 的 style.display */
function getColDisplay(testid: string) {
  const formItem = screen.getByTestId(testid).closest(".ant-form-item") as HTMLElement;
  const outerCol = formItem?.parentElement as HTMLElement;
  return outerCol?.style?.display || "";
}

function createFormItems(count: number) {
  return Array.from({ length: count }, (_, i) => (
    <Form.Item key={i} name={`field${i}`} label={`字段${i}`}>
      <Input data-testid={`input-${i}`} />
    </Form.Item>
  ));
}

describe("QueryFilter", () => {
  it("渲染子元素和提交/重置按钮", () => {
    const { getByTestId, getByText } = render(<QueryFilter>{createFormItems(2)}</QueryFilter>);

    expect(getByTestId("input-0")).toBeInTheDocument();
    expect(getByTestId("input-1")).toBeInTheDocument();
    expect(getByText(textMatcher("查询"))).toBeInTheDocument();
    expect(getByText(textMatcher("重置"))).toBeInTheDocument();
  });

  it("默认收起，隐藏超出第一行的项", () => {
    // span=8 → 一行 3 列，action 占 1 列，可见项 = max(1, 3-1) = 2
    const { getByTestId } = render(<QueryFilter>{createFormItems(5)}</QueryFilter>);

    expect(getByTestId("input-0")).toBeVisible();
    expect(getByTestId("input-1")).toBeVisible();
    expect(getColDisplay("input-2")).toBe("none");
  });

  it("点击展开/收起切换", () => {
    const { getByText } = render(<QueryFilter defaultCollapsed>{createFormItems(5)}</QueryFilter>);
    // 初始收起
    expect(getColDisplay("input-2")).toBe("none");
    // 展开
    fireEvent.click(getByText("展开"));
    expect(getColDisplay("input-2")).not.toBe("none");
    // 收起
    fireEvent.click(getByText("收起"));
    expect(getColDisplay("input-2")).toBe("none");
  });

  it("项数不超一行时不显示展开/收起按钮", () => {
    const { container, queryByText } = render(<QueryFilter collapsed>{createFormItems(2)}</QueryFilter>);

    expect(queryByText("展开")).not.toBeInTheDocument();
    expect(container.querySelector(".pro-query-filter-action")).not.toBeInTheDocument();
  });

  it("collapsed 受控模式", () => {
    const { rerender } = render(<QueryFilter collapsed>{createFormItems(5)}</QueryFilter>);

    expect(getColDisplay("input-2")).toBe("none");

    rerender(<QueryFilter collapsed={false}>{createFormItems(5)}</QueryFilter>);
    expect(getColDisplay("input-2")).not.toBe("none");
  });

  it("submitter=false 隐藏操作按钮", () => {
    const { queryByText } = render(<QueryFilter submitter={false}>{createFormItems(3)}</QueryFilter>);

    expect(queryByText(textMatcher("查询"))).not.toBeInTheDocument();
    expect(queryByText(textMatcher("重置"))).not.toBeInTheDocument();
  });

  it("自定义提交按钮文本", () => {
    const { queryByText, getByText } = render(
      <QueryFilter submitter={{ submitText: "搜索" }}>{createFormItems(2)}</QueryFilter>
    );

    expect(getByText(textMatcher("搜索"))).toBeInTheDocument();
    expect(queryByText(textMatcher("查询"))).not.toBeInTheDocument();
  });

  it("空子元素时正常渲染", () => {
    const { container, getByText } = render(<QueryFilter />);

    expect(container.querySelector("form")).toBeInTheDocument();
    expect(getByText(textMatcher("查询"))).toBeInTheDocument();
  });
});
