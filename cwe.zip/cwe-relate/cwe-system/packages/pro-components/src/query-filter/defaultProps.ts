import type { QueryFilterProps, ResizeBreakpoint } from "./interface";

export const defaultSpan: Record<keyof ResizeBreakpoint, number> = {
  xs: 24,
  sm: 12,
  md: 8,
  lg: 8,
  xl: 8,
  xxl: 6,
  xxxl: 4,
};
export const defaultWidth = document?.body?.clientWidth || 1024;

export const queryFilterDefaultProps: QueryFilterProps = {
  defaultCollapsed: true,
  gutter: [24, 24],
  labelWidth: 80,
};
