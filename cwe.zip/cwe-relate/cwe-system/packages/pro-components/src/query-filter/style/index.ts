import useAntdStyle from "../../theme/useAntdStyle";

export default function useStyle(prefixCls: string) {
  return useAntdStyle("QueryFilter", (token) => {
    const componentCls = `.${prefixCls}`;

    return {
      [`${componentCls}-form-wrapper`]: {
        [`${token.antCls}-form-item`]: {
          marginBlock: 0,
        },
      },

      [`${componentCls}-action`]: {
        // color: token.colorText,
        color: token.colorPrimary,
        "&:hover": {
          color: token.colorPrimaryHover,
        },
      },
    };
  });
}
