import { DownOutlined, UpOutlined } from "@ant-design/icons";
import RcResizeObserver from "@rc-component/resize-observer";
import { toArray, useControlledState } from "@rc-component/util";
import type { FormItemProps } from "antd";
import { Col, ConfigProvider, Form, Row, Space, theme } from "antd";
import type { FormProps } from "antd/es/form/Form";
import clsx from "clsx";
import { useContext, useMemo, useState } from "react";

import Submitter from "../_common/Submitter";
import useDefaultProps from "../_hook/useDefaultProps";
import useSemanticProps from "../_hook/useSemanticProps";
import { defaultSpan, defaultWidth, queryFilterDefaultProps } from "./defaultProps";
import type { QueryFilterProps, ResizeBreakpoint } from "./interface";
import useStyle from "./style";

const { screenSM, screenMD, screenLG, screenXL, screenXXL, screenXXXL } = theme.getDesignToken();
function matchWidthBreakpoint(width: number): ResizeBreakpoint {
  return {
    xs: width < screenSM, // 576
    sm: width >= screenSM,
    md: width >= screenMD, // 768
    lg: width >= screenLG, // 992
    xl: width >= screenXL, // 1200
    xxl: width >= screenXXL, // 1600
    xxxl: width >= screenXXXL, // 1920
  };
}

function formatBreakpointColSpan(bp: ResizeBreakpoint, span: QueryFilterProps["span"]) {
  if (typeof span === "number") {
    return span;
  }

  const { xs, sm, md, lg, xl, xxl } = span || defaultSpan;

  if (bp.xxl) {
    return xxl;
  } // >=1600px 4 行
  if (bp.xl) {
    return xl;
  } // 1200px<= media <=1600px 3 行
  if (bp.lg) {
    return lg;
  } // 992px<= media <=1200px 3 行
  if (bp.md) {
    return md;
  } // 768px<= media <=992px 3 行
  if (bp.sm) {
    return sm;
  } // 576px<= media <=768px 2 行
  return xs; // <576px 1 行
}

function InternalQueryFilter<Values = any>(props: QueryFilterProps<Values>) {
  const mergedProps = useDefaultProps(props, queryFilterDefaultProps);
  const { children, defaultCollapsed, collapsed, gutter, span, labelWidth, submitter, ...formProps } = mergedProps;

  const { getPrefixCls } = useContext(ConfigProvider.ConfigContext);
  const prefixCls = getPrefixCls("pro-query-filter");
  const hashId = useStyle(prefixCls);

  const [internalCollapsed, setInternalCollapsed] = useControlledState(defaultCollapsed, collapsed);

  // ============================= Breakpoint =============================、
  // 初始化一个基础宽度确保页面加载时不会出现布局闪烁
  // see: https://github.com/ant-design/pro-components/blob/master/src/form/layouts/QueryFilter/index.tsx#L591-L593
  const [breakpoint, setBreakpoint] = useState(() => matchWidthBreakpoint(defaultWidth));

  // ============================= FormItem Layout =============================
  const toArrayChildren = toArray(children);
  const formItemColSpan = useMemo(() => formatBreakpointColSpan(breakpoint, span)!, [breakpoint, span]);

  const childrenCount = toArrayChildren.length;
  const displayCount = 24 / formItemColSpan; // 一行几个
  const gridChildren = toArrayChildren.map((item, index) => {
    // 收缩的状态下，-1 是因为 Action 占一个 col，然后最多显示的 FormItem 是 列数 - 1 个
    const shouldHiddenIndex = internalCollapsed ? Math.max(1, displayCount - 1) : childrenCount;
    const hiddenStyle = index >= shouldHiddenIndex ? { display: "none" } : undefined;

    return (
      <Col key={`query-filter-col-${index}`} span={formItemColSpan} style={hiddenStyle}>
        {item}
      </Col>
    );
  });

  const formLayout = useMemo(() => {
    if (formProps.layout) {
      return formProps.layout;
    }

    if (breakpoint.md) {
      return "horizontal";
    }
    return "vertical";
  }, [formProps.layout, breakpoint.md]);

  // ============================= Action =============================
  const toggleCollapsed = () => setInternalCollapsed(!internalCollapsed);
  const renderAction = () => {
    // 当输入框能一行放下的时候，不展示 action
    if (childrenCount <= displayCount - 1) {
      return null;
    }

    return (
      <a className={clsx(hashId, `${prefixCls}-action`)} onClick={toggleCollapsed}>
        {internalCollapsed ? "展开" : "收起"}
        {internalCollapsed ? (
          <DownOutlined style={{ marginInlineStart: "0.5em" }} />
        ) : (
          <UpOutlined style={{ marginInlineStart: "0.5em" }} />
        )}
      </a>
    );
  };

  const actionColSpan = useMemo(() => {
    // 收起状态下，占据一行除展示的 FormItem 数量之外的剩余栅格
    if (internalCollapsed) {
      return 24 - (displayCount - 1) * formItemColSpan;
    }

    // 展开状态下，剩余的栅格，若 FormItem 刚好占满整行，则 Action 另起一行
    const remainder = (childrenCount * formItemColSpan) % 24;
    return remainder === 0 ? 24 : remainder;
  }, [internalCollapsed, displayCount, formItemColSpan, childrenCount]);

  // ============================= FormItem Label =============================
  // 计算最大宽度防止溢出换行
  const formItemFixStyle = useMemo(() => {
    if (labelWidth && formLayout !== "vertical" && labelWidth !== "auto") {
      return {
        labelCol: { flex: `0 0 ${labelWidth}px` },
        wrapperCol: {
          style: { maxWidth: `calc(100% - ${labelWidth}px)` },
        },
      } satisfies FormItemProps<Values>;
    }
    return undefined;
  }, [formLayout, labelWidth]);

  const formClassNames = {
    root: clsx(hashId, `${prefixCls}-form-wrapper`),
  };

  const [mergedClassNames, mergedStyles] = useSemanticProps<
    NonNullable<FormProps["classNames"]>,
    NonNullable<FormProps["styles"]>,
    FormProps<Values>
  >([formClassNames, formProps.classNames], [formProps.styles], { props: mergedProps });

  return (
    <Form<Values>
      autoComplete="off"
      layout={formLayout}
      {...formProps}
      {...formItemFixStyle}
      classNames={mergedClassNames}
      styles={mergedStyles}
    >
      <RcResizeObserver
        onResize={({ width }) => {
          setBreakpoint(matchWidthBreakpoint(width));
        }}
      >
        {(ref) => (
          <Row ref={ref} gutter={gutter}>
            {gridChildren}

            <Col span={actionColSpan} style={{ textAlign: "end" }}>
              <Form.Item label=" " colon={false} shouldUpdate={false}>
                <Space>
                  {/* <Space>{renderSubmitter()}</Space> */}
                  {submitter !== false && <Submitter submitText="查询" {...submitter} />}
                  {renderAction()}
                </Space>
              </Form.Item>
            </Col>
          </Row>
        )}
      </RcResizeObserver>
    </Form>
  );
}

type CompoundedComponent = typeof InternalQueryFilter & {
  displayName?: string;
};

const QueryFilter = InternalQueryFilter as CompoundedComponent;

if (process.env.NODE_ENV !== "production") {
  QueryFilter.displayName = "QueryFilter";
}

export default QueryFilter;
