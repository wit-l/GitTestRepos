import type { CSSInterpolation } from "@ant-design/cssinjs";
import { createTheme, useStyleRegister } from "@ant-design/cssinjs";
import type { GlobalToken } from "antd";
import { ConfigProvider as AntdConfigProvider, theme } from "antd";
import { useContext } from "react";

const DEFAULT_THEME = createTheme((token) => token);

type InternalToken = GlobalToken & {
  antCls: string;
};

// https://github.com/ant-design/happy-work-theme/blob/master/src/DotEffect/style.ts
// https://github.com/ant-design/pro-components/blob/master/src/provider/useStyle/index.ts
// https://github.com/ant-design/pro-components/blob/master/src/provider/index.tsx#L233-L249
// https://github.com/ant-design/pro-components/pull/9538 此 PR 导致每次切换主题无法命中缓存，始终插入新 style
const useAntdStyle = (componentName: string, styleFn: (token: InternalToken) => CSSInterpolation) => {
  const { cssVar, hashId } = theme.useToken();
  const { getPrefixCls } = useContext(AntdConfigProvider.ConfigContext);
  const antCls = `.${getPrefixCls()}`;

  const sharedConfig = { theme: DEFAULT_THEME, token: { ...cssVar, antCls } };

  useStyleRegister(
    {
      ...sharedConfig,
      hashId,
      path: [componentName],
      layer: {
        name: "cwe-pro",
      },
    },
    () => styleFn(sharedConfig.token)
  );

  return hashId;
};

export default useAntdStyle;
