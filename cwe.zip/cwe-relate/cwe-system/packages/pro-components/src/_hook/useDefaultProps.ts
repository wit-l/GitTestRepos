import { useMemo } from "react";

import type { IAnyObject } from "../_common/type";

// fork by: https://github.com/Tencent/tdesign-react/blob/develop/packages/components/hooks/useDefaultProps.ts
export default function useDefaultProps<T>(originalProps: T, defaultProps: IAnyObject): T {
  return useMemo<T>(() => {
    const props = { ...originalProps };
    Object.keys(defaultProps).forEach((key) => {
      // https://github.com/facebook/react/blob/main/packages/react/src/jsx/ReactJSXElement.js#L704-L711
      // @ts-expect-error
      if (props[key] === undefined) {
        // @ts-expect-error
        props[key] = defaultProps[key];
      }
    });
    return props;
  }, [originalProps, defaultProps]);
}
