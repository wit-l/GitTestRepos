import { useEffect } from "react";

/**
 * @description 仅在挂载时执行一次
 */
const useEffectOnce = (fn: React.EffectCallback) => {
  useEffect(() => {
    const result = fn?.();
    // cleanup
    return result;
    // oxlint-disable-next-line react-hooks/exhaustive-deps
  }, []);
};

export default useEffectOnce;
