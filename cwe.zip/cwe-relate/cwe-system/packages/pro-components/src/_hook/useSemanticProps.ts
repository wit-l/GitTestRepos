import clsx from "clsx";
import { isFunction } from "es-toolkit";

import type { IAnyObject } from "../_common/type";

type MaybeFn<T, P> = T | ((info: { props: P }) => T) | undefined;

const resolve = <T, P>(v: T | ((info: { props: P }) => T), info: { props: P }) => (isFunction(v) ? v(info) : v);

/**
 * @description 合并内部自定义样式和外部传入的 props 思路 https://github.com/ant-design/ant-design/blob/master/components/_util/hooks/useMergeSemantic/index.ts
 */
const useSemanticProps = <C extends IAnyObject, S extends IAnyObject, P = any>(
  classNamesList: MaybeFn<C | undefined, P>[],
  stylesList: MaybeFn<S | undefined, P>[],
  info: { props: P }
) => {
  const mergedClassNames: Record<string, string> = {};
  for (const item of classNamesList) {
    if (!item) {
      continue;
    }
    const obj = resolve(item, info) as Record<string, any>;
    for (const key in obj) {
      if (obj[key]) {
        mergedClassNames[key] = clsx(mergedClassNames[key], obj[key]);
      }
    }
  }

  const mergedStyles: Record<string, React.CSSProperties> = {};
  for (const item of stylesList) {
    if (!item) {
      continue;
    }
    const obj = resolve(item, info) as Record<string, React.CSSProperties>;
    for (const key in obj) {
      if (Object.hasOwn(obj, key)) {
        mergedStyles[key] = { ...mergedStyles[key], ...obj[key] };
      }
    }
  }

  return [mergedClassNames as Required<C>, mergedStyles as Required<S>] as const;
};

export default useSemanticProps;
