import { useEvent } from "@rc-component/util";
import { useRef, useState } from "react";

import useFocusWindow from "../table/hooks/_internal/useFocusWindow";
import useEffectOnce from "./useEffectOnce";
import useLatest from "./useLatest";
import useUnmountedRef from "./useUnmountedRef";
import useUpdateEffect from "./useUpdateEffect";

export interface UseAsyncOptions<D, P extends any[]> {
  /**
   * @description 是否手动调用执行，设为 true，则需要手动调用 run
   * @default false
   */
  manual?: boolean;
  /**
   * @description 控制当前请求是否可以发出，当为 false 时，请求永远不会发出
   *
   * 每次 ready 从 false 变为 true 时，都会自动发起请求，会带上参数 `options.defaultParams`
   *
   * @default true
   */
  ready?: boolean;
  /**
   * @description 默认参数 仅首次执行生效
   * @default []
   */
  defaultParams?: P;
  /**
   * @description 是否在窗口重新获得焦点时自动刷新
   * @default false
   */
  refreshOnWindowFocus?: boolean;
  /**
   * @description 聚焦时重新请求的间隔时间
   * @default 5000ms
   */
  focusTimespan?: number;
  /**
   * @description 刷新依赖项，跟 useEffect dependency 类似，当值变化时，会重新执行上一次请求 refresh
   */
  refreshDeps?: React.DependencyList;
  /**
   * @description 自定义依赖数组变化时的请求行为
   */
  refreshDepsAction?: () => void;
  onSuccess?: (data: D, params: P) => void;
  onError?: (error: Error, params: P) => void;
}

export interface UseAsyncResult<D, P extends any[]> {
  loading: boolean;
  data?: D;
  error?: Error;
  params: P;
  run: (...args: P) => Promise<void>;
  refresh: () => Promise<void>;
}

/**
 * 此 hook 是 ahooks [useRequest](https://ahooks.js.org/zh-CN/hooks/use-request/index) 的简化版
 *
 * 不直接使用 ahooks useRequest 是因为不需要 useRequest 的大部分功能，可以更好的结合组件进行魔改定制
 *
 * API 的使用与 ahooks 基本一致
 */
function useAsync<D, P extends any[] = []>(
  service?: (...args: P) => Promise<D>,
  options: UseAsyncOptions<D, P> = {}
): UseAsyncResult<D, P> {
  const {
    manual = false,
    ready = true,
    defaultParams = [] as unknown as P,
    refreshOnWindowFocus = false,
    focusTimespan = 5000,
    refreshDeps = [],
    refreshDepsAction,
    onSuccess,
    onError,
  } = options;

  const [data, setData] = useState<D>();
  const [error, setError] = useState<Error>();
  const [loading, setLoading] = useState(() => !manual && ready);
  const [params, setParams] = useState<P>(() => defaultParams);

  const unmountedRef = useUnmountedRef();
  const requestIdRef = useRef(0); // 防止竞态请求的唯一标识

  const onSuccessRef = useLatest(onSuccess);
  const onErrorRef = useLatest(onError);

  const run = useEvent(async (...args: P): Promise<void> => {
    if (!service) {
      setData(undefined);
      setError(undefined);
      setLoading(false);
      return;
    }

    // 生成新请求 ID
    const currentRequestId = (requestIdRef.current += 1);
    setLoading(true);
    setError(undefined);
    setParams(args);

    try {
      const result = await service(...args);

      // 只处理最新请求的结果
      if (!unmountedRef.current && currentRequestId === requestIdRef.current) {
        setData(result);
        setLoading(false);
        onSuccessRef.current?.(result, args);
      }
      //   return result;
    } catch (error) {
      console.error(error);
      if (!unmountedRef.current && currentRequestId === requestIdRef.current) {
        setError(error as Error);
        setLoading(false);
        onErrorRef.current?.(error as Error, args);
      }
    }
  });

  const refresh = useEvent(() => run(...params));

  useFocusWindow(refresh, {
    refreshOnWindowFocus,
    focusTimespan,
  });

  useEffectOnce(() => {
    if (!manual && ready) {
      run(...params);
    }
  });

  useUpdateEffect(() => {
    if (!manual && ready) {
      run(...defaultParams);
    }
  }, [ready]);

  useUpdateEffect(() => {
    if (!manual) {
      if (refreshDepsAction) {
        refreshDepsAction();
      } else {
        refresh();
      }
    }
  }, [...refreshDeps]);

  return {
    data,
    error,
    loading,
    params,
    run,
    refresh,
  };
}

export default useAsync;
