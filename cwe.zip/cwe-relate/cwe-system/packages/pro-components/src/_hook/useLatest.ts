import { useEffect, useRef } from "react";

/**
 * @description 始终获取最新值
 */
function useLatest<T>(value: T) {
  const ref = useRef(value);

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref;
}

export default useLatest;
