import { useEffect, useRef } from "react";

/**
 * @description 与 useEffect 类似，但会跳过首次执行
 */
const useUpdateEffect = (effect: React.EffectCallback, deps?: React.DependencyList) => {
  const isMounted = useRef(false);

  // for React Fast Refresh
  useEffect(
    () => () => {
      isMounted.current = false;
    },
    []
  );

  useEffect(() => {
    if (isMounted.current) {
      return effect();
    }
    isMounted.current = true;
    // oxlint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
};

export default useUpdateEffect;
