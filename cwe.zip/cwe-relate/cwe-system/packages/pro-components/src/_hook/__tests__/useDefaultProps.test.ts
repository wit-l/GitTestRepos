import { renderHook } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import useDefaultProps from "../useDefaultProps";

interface TestProps {
  name?: string;
  age?: number;
  visible?: boolean;
  emails?: {
    qq?: string;
    x?: string;
  };
  others?: any;
}

const defaultProps: TestProps = {
  name: "default",
  age: 18,
  visible: true,
  emails: {
    qq: "123@qq.com",
    x: "123@x.com",
  },
};

describe("useDefaultProps", () => {
  describe("核心使用", () => {
    it("应正确合并 props", () => {
      const { result } = renderHook(() => useDefaultProps<TestProps>({ name: "custom", others: {} }, defaultProps));

      expect(result.current).toEqual({
        name: "custom",
        age: 18,
        visible: true,
        emails: {
          qq: "123@qq.com",
          x: "123@x.com",
        },
        others: {},
      });
    });

    it("应为浅合并 props", () => {
      const { result } = renderHook(() => useDefaultProps<TestProps>({ name: "custom", emails: {} }, defaultProps));

      expect(result.current).toEqual({
        name: "custom",
        age: 18,
        visible: true,
        emails: {},
      });
    });
  });

  describe("原始数据应为不变值", () => {
    it("不应修改原始 props 和默认 props", () => {
      const originalProps: TestProps = {
        name: "custom",
      };
      renderHook(() => useDefaultProps<TestProps>(originalProps, defaultProps));

      expect(originalProps).toEqual({
        name: "custom",
      });
      expect(defaultProps).toEqual({
        name: "default",
        age: 18,
        visible: true,
        emails: {
          qq: "123@qq.com",
          x: "123@x.com",
        },
      });
    });

    it("当原始 props 改变时应返回新的引用", () => {
      const { result, rerender } = renderHook((props) => useDefaultProps<TestProps>(props, defaultProps), {
        initialProps: { name: "first" } as TestProps,
      });

      const firstResult = result.current;

      rerender({ name: "second" });

      expect(result.current).not.toBe(firstResult);
      expect(result.current.name).toBe("second");
    });
  });

  describe("值类型规则处理", () => {
    it("应忽略值为 undefined 的 props", () => {
      const { result } = renderHook(() =>
        useDefaultProps<TestProps>({ name: "custom", age: undefined, emails: undefined }, defaultProps)
      );

      expect(result.current).toEqual({
        name: "custom",
        age: 18,
        visible: true,
        emails: {
          qq: "123@qq.com",
          x: "123@x.com",
        },
      });
    });

    it("不应忽略值为 null 0 boolean 等可能被作为假值的 props", () => {
      const { result } = renderHook(() =>
        // @ts-expect-error
        useDefaultProps<TestProps>({ name: "custom", age: null, emails: 0, visible: false }, defaultProps)
      );

      expect(result.current).toEqual({
        name: "custom",
        age: null,
        visible: false,
        emails: 0,
      });
    });
  });
});
