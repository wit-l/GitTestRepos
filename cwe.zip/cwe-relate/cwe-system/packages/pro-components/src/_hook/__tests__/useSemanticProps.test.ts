import { renderHook } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import useSemanticProps from "../useSemanticProps";

interface TestClassNames {
  root?: string;
  header?: string;
  content?: string;
}

interface TestStyles {
  root?: React.CSSProperties;
  header?: React.CSSProperties;
  content?: React.CSSProperties;
}

interface TestProps {
  theme?: string;
}

describe("useSemanticProps", () => {
  describe("核心使用", () => {
    it("应正确合并对象形式的 classNames styles", () => {
      const classNames1: TestClassNames = { root: "class1", header: "header1" };
      const classNames2: TestClassNames = { root: "class2", content: "content1" };
      const classNames3: TestClassNames = { header: "header3" };
      const styles1: TestStyles = {
        root: { color: "red", fontSize: 14 },
        header: { padding: 10 },
      };
      const styles2: TestStyles = {
        root: { backgroundColor: "blue" },
        content: { margin: 20 },
      };

      const { result } = renderHook(() =>
        useSemanticProps<TestClassNames, TestStyles, TestProps>(
          [classNames1, classNames2, classNames3],
          [styles1, styles2],
          {
            props: {},
          }
        )
      );

      const [mergedClassNames, mergedStyles] = result.current;

      expect(mergedClassNames).toEqual({
        root: "class1 class2",
        header: "header1 header3",
        content: "content1",
      });
      expect(mergedStyles.root).toEqual({ color: "red", fontSize: 14, backgroundColor: "blue" });
      expect(mergedStyles.header).toEqual({ padding: 10 });
      expect(mergedStyles.content).toEqual({ margin: 20 });
    });

    it("应正确合并函数形式的 classNames styles", () => {
      const classNamesFn1 = ({ props }: { props: TestProps }) => ({
        root: props.theme === "dark" ? "dark1" : "light1",
      });
      const classNamesFn2 = ({ props }: { props: TestProps }) => ({
        root: props.theme === "dark" ? "dark2" : "light2",
      });
      const stylesFn1 = ({ props }: { props: TestProps }) => ({
        root: { color: props.theme === "dark" ? "red" : "blue" },
      });
      const stylesFn2 = ({ props }: { props: TestProps }) => ({
        root: { backgroundColor: props.theme === "dark" ? "white" : "black" },
      });

      const { result, rerender } = renderHook(
        (props) =>
          useSemanticProps<TestClassNames, TestStyles, TestProps>(
            [classNamesFn1, classNamesFn2],
            [stylesFn1, stylesFn2],
            { props }
          ),
        { initialProps: { theme: "dark" } as TestProps }
      );

      const [mergedClassNames1, mergedStyles1] = result.current;
      expect(mergedClassNames1).toEqual({ root: "dark1 dark2" });
      expect(mergedStyles1.root).toEqual({ color: "red", backgroundColor: "white" });

      rerender({ theme: "light" });
      const [mergedClassNames2, mergedStyles2] = result.current;
      expect(mergedClassNames2).toEqual({ root: "light1 light2" });
      expect(mergedStyles2.root).toEqual({ color: "blue", backgroundColor: "black" });
    });

    it("应正确处理对象和函数形式的混合 props", () => {
      const classNames1: TestClassNames = {
        root: "objCls",
      };
      const classNamesFn = ({ props }: { props: TestProps }) => ({
        root: props.theme === "dark" ? "dark-fnCls" : "light-fnCls",
      });
      const styles1: TestStyles = {
        root: { padding: 10 },
      };
      const stylesFn = ({ props }: { props: TestProps }) => ({
        root: { color: props.theme === "dark" ? "white" : "black" },
      });

      const { result } = renderHook(() =>
        useSemanticProps<TestClassNames, TestStyles, TestProps>([classNames1, classNamesFn], [styles1, stylesFn], {
          props: { theme: "dark" },
        })
      );

      const [mergedClassNames, mergedStyles] = result.current;

      expect(mergedClassNames.root).toBe("objCls dark-fnCls");
      expect(mergedStyles.root).toEqual({ padding: 10, color: "white" });
    });

    it("原始 classNames 和 styles 变化时更新处理的 classNames 和 styles 状态", () => {
      const classNames1: TestClassNames = { root: "class1" };
      const styles1: TestStyles = {
        root: { color: "red" },
      };

      interface MockProps {
        classNames?: TestClassNames;
        styles?: TestStyles;
      }
      const mackProps: MockProps = {
        classNames: { root: "firstCls" },
        styles: { root: { textAlign: "center" } },
      };

      const { result, rerender } = renderHook(
        (props) =>
          useSemanticProps<TestClassNames, TestStyles, TestProps>(
            [classNames1, props.classNames],
            [styles1, props.styles],
            { props: {} }
          ),
        {
          initialProps: mackProps as MockProps,
        }
      );

      const [mergedClassNames1, mergedStyles1] = result.current;
      expect(mergedClassNames1).toEqual({ root: "class1 firstCls" });
      expect(mergedStyles1.root).toEqual({ color: "red", textAlign: "center" });

      rerender({ classNames: { root: "secondCls" }, styles: { root: { fontSize: 14 } } });

      const [mergedClassNames2, mergedStyles2] = result.current;
      expect(mergedClassNames2).toEqual({ root: "class1 secondCls" });
      expect(mergedStyles2.root).toEqual({ color: "red", fontSize: 14 });
    });
  });

  describe("值类型规则处理", () => {
    it("应正确处理不规范值 null undefined number boolean 等", () => {
      const classNames1: TestClassNames = {
        root: "class1",
      };
      const exceptionClassNames: any = {
        root: null,
        header: undefined,
        content: 1,
        footer: true,
      };
      const styles1: TestStyles = {
        root: { color: "red" },
      };

      const { result } = renderHook(() =>
        useSemanticProps<TestClassNames, TestStyles, TestProps>(
          [classNames1, exceptionClassNames],
          [styles1, undefined],
          { props: {} }
        )
      );

      const [mergedClassNames, mergedStyles] = result.current;

      expect(mergedClassNames.root).toBe("class1");
      expect(mergedClassNames.content).toBe("1");
      // @ts-expect-error
      expect(mergedClassNames.footer).toBe(""); // true 会被转换成 ''
      expect(mergedClassNames.header).toBe(undefined); // undefined 会被忽略不存在这个 key
      expect(mergedStyles.root).toEqual({ color: "red" });
    });

    it("应正确处理空数组", () => {
      const { result } = renderHook(() =>
        useSemanticProps<TestClassNames, TestStyles, TestProps>([], [], { props: {} })
      );
      const [mergedClassNames, mergedStyles] = result.current;
      expect(mergedClassNames).toEqual({});
      expect(mergedStyles).toEqual({});
    });
  });
});
