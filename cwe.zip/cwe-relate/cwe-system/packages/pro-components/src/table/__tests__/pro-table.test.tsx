import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

import type { ProColumnsType } from "../interface";
import ProTable from "../pro-table";

interface TestData {
  id: number;
  name: string;
  age: number;
}

const columns: ProColumnsType<TestData>[] = [
  { title: "ID", dataIndex: "id", key: "id" },
  { title: "姓名", dataIndex: "name", key: "name" },
  { title: "年龄", dataIndex: "age", key: "age" },
];

const searchColumns: ProColumnsType<TestData>[] = [
  {
    title: "姓名",
    dataIndex: "name",
    key: "name",
    renderSearchFormItem: () => <input data-testid="search-name" />,
  },
  { title: "年龄", dataIndex: "age", key: "age" },
];

const dataSource: TestData[] = [
  { id: 1, name: "张三", age: 25 },
  { id: 2, name: "李四", age: 30 },
];

function renderTable(props?: any) {
  return render(<ProTable<TestData> columns={columns} dataSource={dataSource} rowKey="id" {...props} />);
}

/** antd Button 在 cssVar 模式下 CJK 字符间会插入空格 */
function textMatcher(target: string) {
  return (content: string) => content.replaceAll(/\s/g, "") === target;
}

describe("ProTable", () => {
  it("渲染数据行", () => {
    renderTable();

    expect(screen.getByText("张三")).toBeInTheDocument();
    expect(screen.getByText("李四")).toBeInTheDocument();
  });

  it("空数据时显示 empty 占位", () => {
    renderTable({ dataSource: [] });

    expect(document.querySelector(".ant-empty")).toBeInTheDocument();
  });

  it("columnEmptyText 替换空值显示", () => {
    renderTable({
      dataSource: [{ id: 1, name: undefined as any, age: 0 }],
      columnEmptyText: "N/A",
    });

    expect(screen.getByText("N/A")).toBeInTheDocument();
    expect(screen.getByText("0")).toBeInTheDocument();
  });

  it("toolbar=false 隐藏工具栏", () => {
    const { container } = renderTable({ toolbar: false });

    expect(container.querySelector(".pro-table-list-toolbar")).not.toBeInTheDocument();
  });

  it("search=false 隐藏搜索表单", () => {
    render(<ProTable<TestData> columns={searchColumns} dataSource={dataSource} search={false} rowKey="id" />);

    expect(screen.queryByTestId("search-name")).not.toBeInTheDocument();
  });

  it("rowSelection 多选模式显示复选框", () => {
    renderTable({ rowSelection: {} });

    const checkboxes = document.querySelectorAll(".ant-checkbox");
    expect(checkboxes.length).toBeGreaterThan(0);
  });

  // ========== 异步 request 测试 ==========

  it("request 异步加载远程数据", async () => {
    const request = vi.fn().mockResolvedValue({
      data: [{ id: 1, name: "远程张三", age: 28 }],
      total: 1,
    });

    render(<ProTable<TestData> columns={columns} request={request} rowKey="id" />);

    await waitFor(() => {
      expect(screen.getByText("远程张三")).toBeInTheDocument();
    });
    expect(request).toHaveBeenCalled();
  });

  it("点击搜索时发起异步请求并合并表单参数", async () => {
    const request = vi.fn().mockResolvedValue({
      data: [{ id: 1, name: "搜索结果", age: 20 }],
      total: 1,
    });

    render(<ProTable<TestData> columns={searchColumns} request={request} rowKey="id" />);

    // 等待初始请求完成
    await waitFor(() => {
      expect(screen.getByText("搜索结果")).toBeInTheDocument();
    });
    request.mockClear();

    // 输入搜索条件
    fireEvent.change(screen.getByTestId("search-name"), { target: { value: "关键词" } });

    // 点击"查询"
    fireEvent.click(screen.getByText(textMatcher("查询")));

    await waitFor(() => {
      expect(request).toHaveBeenCalledWith(
        expect.objectContaining({ name: "关键词", current: 1, pageSize: 10 }),
        expect.any(Object),
        expect.any(Object)
      );
    });
  });

  it("点击重置时恢复默认参数并重新请求", async () => {
    const request = vi.fn().mockResolvedValue({
      data: [{ id: 1, name: "搜索结果", age: 20 }],
      total: 1,
    });

    render(<ProTable<TestData> columns={searchColumns} request={request} rowKey="id" />);

    // 等待初始请求完成
    await waitFor(() => {
      expect(screen.getByText("搜索结果")).toBeInTheDocument();
    });
    request.mockClear();

    // 输入搜索条件
    fireEvent.change(screen.getByTestId("search-name"), { target: { value: "随便输" } });

    // 点击"重置"
    fireEvent.click(screen.getByText(textMatcher("重置")));

    await waitFor(() => {
      expect(request).toHaveBeenCalledWith(
        expect.objectContaining({ current: 1, pageSize: 10 }),
        expect.any(Object),
        expect.any(Object)
      );
    });

    // 验证搜索输入被清空
    expect(screen.getByTestId("search-name")).toHaveValue("");
  });

  it("切换分页时发起请求并传入新页码", async () => {
    const fullData = Array.from({ length: 25 }, (_, i) => ({
      id: i,
      name: `用户${i}`,
      age: 20 + i,
    }));

    const request = vi
      .fn()
      .mockResolvedValueOnce({ data: fullData.slice(0, 10), total: 25 })
      .mockResolvedValueOnce({ data: fullData.slice(10, 20), total: 25 });

    render(<ProTable<TestData> columns={columns} request={request} rowKey="id" />);

    // 等待初始加载
    await waitFor(() => {
      expect(screen.getByText("用户0")).toBeInTheDocument();
    });
    request.mockClear();

    // 点击第 2 页
    const page2Btn = document.querySelector(".ant-pagination-item-2");
    fireEvent.click(page2Btn!);

    await waitFor(() => {
      expect(request).toHaveBeenCalledWith(
        expect.objectContaining({ current: 2, pageSize: 10 }),
        expect.any(Object),
        expect.any(Object)
      );
    });
  });
});
