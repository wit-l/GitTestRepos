import { isFunction, isUndefined } from "es-toolkit";
import { isEmpty } from "es-toolkit/compat";

import type { AntdTableFilter, AntdTableSort, ProColumnsType, ProTableProps } from "../interface";

export const genColumnKey = (key?: React.Key, index?: number | string): string => {
  if (key) {
    return Array.isArray(key) ? key.join("-") : key.toString();
  }
  return `${index}`;
};

/**
 * @description 此函数只用于生成 columnMap 的 key
 */
export const genColumnKeyWithParentKey = (
  key?: React.Key,
  index?: number | string,
  parentKey?: string | number
): string =>
  genColumnKey(
    key,
    // key 和 dataIndex 都不存在时的兜底
    // 多 children 的情况下，使用 index 无法确保唯一，因此需要结合父 key 拼接
    [parentKey, index].filter(Boolean).join("-")
  );

export const genSearchColumns = <T>(columns: ProColumnsType<T>[] = []): ProColumnsType<T>[] => {
  const result: ProColumnsType<T>[] = [];
  const loopColumns = (cols: ProColumnsType<T>[]) => {
    cols.forEach((col) => {
      if (isFunction(col.renderSearchFormItem)) {
        result.push(col);
      }

      if (col.children) {
        loopColumns(col.children);
      }
    });
  };

  loopColumns(columns);

  return result.toSorted((a, b) => (a.searchOrder || 0) - (b.searchOrder || 0));
};

/**
 * 与 antd Table 内部 `getColumnKey` 行为对齐：filter map / sorter.columnKey 的查找键
 *
 * https://github.com/ant-design/ant-design/blob/master/components/table/util.ts#L5-L16
 *
 * 优先级：`column.key` > `column.dataIndex`（数组以 `.` 连接）
 */
const getColumnItemKey = <D>(col: ProColumnsType<D>): React.Key | undefined => {
  if (!isUndefined(col.key)) {
    return col.key;
  }
  if (isUndefined((col as any).dataIndex)) {
    return undefined;
  }

  return Array.isArray((col as any).dataIndex) ? (col as any).dataIndex.join(".") : (col as any).dataIndex;
};

const findSortOrder = <D>(
  sortState: AntdTableSort<D> | undefined,
  columnKey: React.Key | undefined
): "ascend" | "descend" | null => {
  if (!sortState || isUndefined(columnKey)) {
    return null;
  }

  const list = Array.isArray(sortState) ? sortState : [sortState];
  for (const s of list) {
    if (!s?.order) {
      continue;
    }
    const sortKey = s.columnKey ?? (Array.isArray(s.field) ? s.field.join(".") : s.field);
    if (sortKey === columnKey) {
      return s.order;
    }
  }
  return null;
};

interface GenProColumnsOptions<D> {
  columns?: ProColumnsType<D>[];
  emptyText: ProTableProps<D>["columnEmptyText"];
  /**
   * @description 由 ProTable 内部托管的 filter 状态，按列 key 注入到 `filteredValue`
   */
  filterState?: AntdTableFilter;
  /**
   * @description 由 ProTable 内部托管的 sort 状态，按列 key 注入到 `sortOrder`
   */
  sortState?: AntdTableSort<D>;
}

export const genProColumns = <D>(options: GenProColumnsOptions<D>): ProColumnsType<D>[] | undefined => {
  const { columns, emptyText, filterState, sortState } = options;

  return columns?.map((col) => {
    // 若有子列（多级表头），递归处理子列
    if (col.children) {
      return {
        ...col,
        children: genProColumns({ columns: col.children, emptyText, filterState, sortState }),
      };
    }

    const withRender: ProColumnsType<D> = col.render
      ? col
      : {
          ...col,
          render: (value) => (value === null || value === undefined || value === "" ? emptyText : value),
        };

    // 注入受控 filter / sort：开发者显式传 filteredValue / sortOrder 时不覆盖
    const filterKey = getColumnItemKey(col);
    const patches: Partial<ProColumnsType<D>> = {};

    const hasFilterUI = !isUndefined(col.filters) || !isUndefined(col.filterDropdown);
    if (hasFilterUI && isUndefined(col.filteredValue) && !isUndefined(filterState) && !isUndefined(filterKey)) {
      patches.filteredValue = filterState[String(filterKey)] ?? null;
    }

    if (!isUndefined(col.sorter) && isUndefined(col.sortOrder) && !isUndefined(sortState)) {
      patches.sortOrder = findSortOrder<D>(sortState, filterKey);
    }

    return isEmpty(patches) ? withRender : { ...withRender, ...patches };
  });
};

/**
 * @description 从 columns 的 `defaultFilteredValue` 派生初始 filter 状态
 */
export const buildInitialFilter = <D>(columns?: ProColumnsType<D>[]): AntdTableFilter => {
  const result: AntdTableFilter = {};
  const walk = (cols: ProColumnsType<D>[]) => {
    for (const col of cols) {
      if ((col as any).children) {
        walk((col as any).children);
        continue;
      }
      const key = getColumnItemKey(col);
      const dv = (col as { defaultFilteredValue?: AntdTableFilter[string] }).defaultFilteredValue;
      if (!isUndefined(key) && !isUndefined(dv)) {
        result[String(key)] = dv;
      }
    }
  };
  if (columns) {
    walk(columns);
  }
  return result;
};

/**
 * @description 从 columns 的 `defaultSortOrder` 派生初始 sort 状态。
 *
 * 单列默认时返回 SorterResult，多列默认时返回数组（多列排序场景）。无默认时返回空对象，
 * 与 antd `onChange` 在未排序时给出的形态保持一致。
 */
export const buildInitialSort = <D>(columns?: ProColumnsType<D>[]): AntdTableSort<D> => {
  const sorters: NonNullable<AntdTableSort<D>>[] = [];
  const walk = (cols: ProColumnsType<D>[]) => {
    for (const col of cols) {
      if (col.children) {
        walk(col.children);
        continue;
      }
      if (!col.defaultSortOrder) {
        continue;
      }
      sorters.push({
        columnKey: col.key,
        field: (col as any).dataIndex,
        order: col.defaultSortOrder,
      });
    }
  };
  if (columns) {
    walk(columns);
  }

  if (isEmpty(sorters)) {
    return {} as AntdTableSort<D>;
  }
  return (sorters.length === 1 ? sorters[0] : sorters) as AntdTableSort<D>;
};

export const flattenArray = (data: any[]) => {
  const _columns: any[] = [];

  for (const item of data) {
    if (item.children) {
      _columns.push(...flattenArray(item.children));
    } else {
      _columns.push(item);
    }
  }

  return _columns;
};
