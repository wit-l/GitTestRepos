export type {
  ProColumnsType,
  ProTableActionType,
  ProTableProps,
  RequestResult,
  RequestTableParams,
  SearchConfig,
} from "./interface";

export { default as ProTable } from "./pro-table";
