import useAntdStyle from "../../../../../theme/useAntdStyle";

export default function useStyle(prefixCls: string) {
  return useAntdStyle("ProTableColumnSetting", (token) => {
    const componentCls = `.${prefixCls}`;

    return {
      [`${componentCls}`]: {
        // boxSizing: 'border-box',
        // width: 'auto',
        "&-title": {
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: "32px",
        },
        "&-reset-btn": {
          color: token.colorPrimary,
        },
      },
    };
  });
}
