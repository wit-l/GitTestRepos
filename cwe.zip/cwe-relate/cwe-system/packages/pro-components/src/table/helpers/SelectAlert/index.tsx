import { ConfigProvider, Space } from "antd";
import clsx from "clsx";
import { useContext } from "react";

import type { IAnyObject } from "../../../_common/type";
import useStyle from "./style";

interface SelectAlertRenderTypeProps<T> {
  selectedRowKeys: React.Key[];
  selectedRows: T[];
  onClearSelected: () => void;
}

export type SelectAlertRenderType<T = IAnyObject> = ((props: SelectAlertRenderTypeProps<T>) => React.ReactNode) | false;

export interface SelectAlertProps<T = IAnyObject> {
  selectedRowKeys?: React.Key[];
  selectedRows: T[];
  onClearSelected: () => void;
  alwaysShowAlert?: boolean;

  alertInfoRender?: SelectAlertRenderType<T>;
  alertOptionRender?: SelectAlertRenderType<T>;
}

function SelectAlert<T>(props: SelectAlertProps<T>) {
  const {
    selectedRowKeys = [],
    selectedRows,
    onClearSelected,
    alwaysShowAlert,
    alertInfoRender = ({ selectedRowKeys }) => <Space>已选择 {selectedRowKeys.length}项 &nbsp;&nbsp;</Space>,
    alertOptionRender = () => <a onClick={onClearSelected}>取消选择</a>,
  } = props;

  const { getPrefixCls } = useContext(ConfigProvider.ConfigContext);
  const prefixCls = getPrefixCls("pro-table-alert");
  const hashId = useStyle(prefixCls);

  if (alertInfoRender === false) {
    return null;
  }
  const alertInfoDom = alertInfoRender?.({ selectedRowKeys, selectedRows, onClearSelected });
  if (alertInfoDom === false || (selectedRowKeys.length < 1 && !alwaysShowAlert)) {
    return null;
  }

  const alertOptionDom = alertOptionRender
    ? alertOptionRender({ selectedRowKeys, selectedRows, onClearSelected })
    : null;

  return (
    <div className={clsx(hashId, prefixCls)}>
      <div className={clsx(hashId, `${prefixCls}-wrapper`)}>
        <div className={clsx(hashId, `${prefixCls}-info`)}>{alertInfoDom}</div>
        {alertOptionDom && <div className={clsx(hashId, `${prefixCls}-option`)}>{alertOptionDom}</div>}
      </div>
    </div>
  );
}

export default SelectAlert;
