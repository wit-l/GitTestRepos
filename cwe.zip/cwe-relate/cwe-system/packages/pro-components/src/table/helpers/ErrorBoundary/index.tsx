import { Result } from "antd";
import { Component } from "react";

interface ErrorBoundaryProps {
  children?: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorInfo: string;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  override state = { hasError: false, errorInfo: "" };

  static getDerivedStateFromError(error: Error) {
    console.warn("ErrorBoundary caught an error", error);
    return { hasError: true, errorInfo: error.message };
  }

  override componentDidCatch(error: any, errorInfo: React.ErrorInfo) {
    // 这里可以添加错误上报逻辑
    console.warn("ErrorBoundary caught an error", error, errorInfo);
  }

  override render() {
    if (this.state.hasError) {
      return <Result status="error" title="Something went wrong." extra={this.state.errorInfo} />;
    }
    return this.props.children;
  }
}

export { ErrorBoundary };
