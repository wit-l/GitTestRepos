import { ColumnHeightOutlined } from "@ant-design/icons";
import { Dropdown, Tooltip } from "antd";
import { useContext } from "react";

import { ProTableContext } from "../../../../context";
import type { DensitySize } from "../../../../interface";

export default function DensityIcon() {
  const { size, changeTableSize } = useContext(ProTableContext);
  const compatSize = size === "middle" ? "medium" : size;

  return (
    <Dropdown
      styles={{ root: { width: 80 } }}
      menu={{
        selectedKeys: [compatSize],
        onClick: ({ key }) => {
          changeTableSize?.(key as DensitySize);
        },
        items: [
          { key: "large", label: "宽松" },
          { key: "medium", label: "中等" },
          { key: "small", label: "紧凑" },
        ],
      }}
      trigger={["click"]}
    >
      <Tooltip title="表格密度">
        <ColumnHeightOutlined />
      </Tooltip>
    </Dropdown>
  );
}
