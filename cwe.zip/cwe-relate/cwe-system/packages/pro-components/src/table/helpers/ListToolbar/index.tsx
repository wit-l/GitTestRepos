import { ConfigProvider } from "antd";
import clsx from "clsx";
import { useContext } from "react";

import type { ListToolbarProps } from "../../interface";
import useStyle from "./style";
import ColumnSetting from "./tools/ColumnSetting";
import DensityIcon from "./tools/DensityIcon";
import ReloadIcon from "./tools/ReloadIcon";

function ListToolbar(props: ListToolbarProps) {
  const { action: renderAction, setting: renderSetting, headerTitle } = props;

  const { getPrefixCls } = useContext(ConfigProvider.ConfigContext);
  const prefixCls = getPrefixCls("pro-table-list-toolbar");
  const hashId = useStyle(prefixCls);

  const toolbarSettingConfig = [
    <ReloadIcon key="reload" />,
    <DensityIcon key="density" />,
    <ColumnSetting key="setting" />,
  ];

  const renderSettingNode = () => {
    if (renderSetting) {
      return renderSetting(toolbarSettingConfig);
    }
    return toolbarSettingConfig?.map((item) => (
      <div key={item.key} className={clsx(hashId, `${prefixCls}-setting-items`)}>
        <div className={clsx(hashId, `${prefixCls}-setting-item`)}>
          <span>{item}</span>
        </div>
      </div>
    ));
  };

  return (
    <div className={clsx(hashId, prefixCls)}>
      <div className={clsx(hashId, `${prefixCls}-left`)}>
        {headerTitle && <div className={clsx(hashId, `${prefixCls}-title`)}>{headerTitle}</div>}
      </div>
      <div className={clsx(hashId, `${prefixCls}-right`)}>
        {renderAction?.()}
        {renderSettingNode()}
      </div>
    </div>
  );
}

export default ListToolbar;
