import { ReloadOutlined } from "@ant-design/icons";
import { Tooltip } from "antd";
import { useContext } from "react";

import { ProTableContext } from "../../../../context";

export default function ReloadIcon() {
  const { actionRef } = useContext(ProTableContext);

  return (
    <Tooltip title="刷新">
      <ReloadOutlined onClick={() => actionRef.current?.reload()} />
    </Tooltip>
  );
}
