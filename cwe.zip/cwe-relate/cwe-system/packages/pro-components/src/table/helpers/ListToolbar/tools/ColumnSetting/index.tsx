import { SettingOutlined } from "@ant-design/icons";
import { useEvent } from "@rc-component/util";
import type { CheckboxChangeEvent, TreeDataNode } from "antd";
import { Checkbox, ConfigProvider, Popover, Tooltip, Tree, Typography } from "antd";
import clsx from "clsx";
import { useContext, useMemo, useRef } from "react";

import useEffectOnce from "../../../../../_hook/useEffectOnce";
import { ProTableContext } from "../../../../context";
import type { ProColumnsState, ProTableProps } from "../../../../interface";
import { genColumnKeyWithParentKey } from "../../../../utils";
import useStyle from "./style";

type ColumnTreeData = TreeDataNode & {
  title?: React.ReactNode;
  hidden?: boolean;
};

export default function ColumnSetting() {
  const { getPrefixCls } = useContext(ConfigProvider.ConfigContext);
  const {
    columns = [],
    columnsSettingMap,
    initialColumnSettingConfig,
    defaultColumnsSettingMap,
    setColumnsSettingMap,
    clearPersistenceStorage,
  } = useContext(ProTableContext);
  const prefixCls = getPrefixCls("pro-table-column-setting");
  const hashId = useStyle(prefixCls);

  const treeConfig = useMemo(() => {
    const checkedKeys: string[] = [];
    const flatMapColumns = new Map<string | number, ColumnTreeData & { parentKey?: string }>();
    function loopData(data: ProTableProps["columns"], pColumnKey?: string): ColumnTreeData[] {
      return data
        ?.map((item, index) => {
          if (item.hideInSetting) {
            return undefined;
          } // 忽略隐藏列

          const columnKey = genColumnKeyWithParentKey(item.key ?? (item as any).dataIndex, index, pColumnKey);

          const config = columnsSettingMap[columnKey] || {};
          const treeItem: ColumnTreeData = {
            title: item.title,
            key: columnKey,
            disabled: config.disableColumnSetting,
            hidden: config.hidden,
            selectable: false,
          };

          const { children } = item as any;

          // 无 children 且当前项展示，则直接勾选
          if (config.hidden !== true && !children) {
            checkedKeys.push(columnKey);
          }

          // 有 children
          if (children) {
            treeItem.children = loopData(children, columnKey);
            // 如果 children 已经全部展示，把自己也设置选中
            if (treeItem.children?.every((child) => checkedKeys?.includes(child.key as string))) {
              checkedKeys.push(columnKey);
            }
          }

          flatMapColumns.set(columnKey, { ...treeItem, parentKey: pColumnKey });
          return treeItem;
        })
        .filter(Boolean) as ColumnTreeData[];
    }

    return { checkedKeys, treeList: loopData(columns), flatMapColumns };
  }, [columns, columnsSettingMap]);

  // 未选中的 key 列表
  const unCheckedKeys = Object.values(columnsSettingMap).filter((value) => !value || value.hidden === true);
  const indeterminate = unCheckedKeys.length > 0 && unCheckedKeys.length !== columns.length;

  /** 全选 */
  const checkAll = useEvent((e: CheckboxChangeEvent) => {
    const newColumnMap = { ...columnsSettingMap };

    // 递归处理列及其子列
    const loopColumns = (cols: ProTableProps["columns"], pColumnKey?: string) => {
      cols?.forEach((item, index) => {
        if (item.hideInSetting) {
          return;
        }

        const columnKey = genColumnKeyWithParentKey(item.key ?? (item as any).dataIndex, index, pColumnKey);
        const newSetting = { ...newColumnMap[columnKey] };
        // 忽略禁用列，其他所有列都设置为 checked 状态
        if (!newSetting?.disableColumnSetting) {
          newSetting.hidden = !e.target.checked;
        }
        newColumnMap[columnKey] = newSetting;

        const { children } = item as any;
        if (children) {
          loopColumns(children, columnKey);
        }
      });
    };

    loopColumns(columns);
    setColumnsSettingMap(newColumnMap);
  });

  /** 反选 */
  const onCheckTree = useEvent((e) => {
    const newColumnMap = { ...columnsSettingMap };

    const loopSetNewState = (key: string | number) => {
      const newSetting = { ...newColumnMap[key], hidden: e.checked === false };
      // 如果含有子节点，也要选中
      if (treeConfig.flatMapColumns.get(key)?.children) {
        treeConfig.flatMapColumns.get(key)?.children?.forEach((item) => {
          loopSetNewState(item.key as string);
        });
      }
      newColumnMap[key] = newSetting;

      // 如果是子节点选择，那父节点也应该变化
      const parentKey = treeConfig.flatMapColumns.get(key)?.parentKey;
      if (parentKey) {
        const siblings = treeConfig.flatMapColumns.get(parentKey)?.children;
        // 检查父节点对应的子节点是否全部隐藏，如果全部隐藏，则隐藏父节点
        const allSiblingsHidden = siblings?.every((sibling) => newColumnMap[sibling.key as string]?.hidden === true);
        newColumnMap[parentKey] = { ...newColumnMap[parentKey], hidden: !!allSiblingsHidden };
      }
    };

    loopSetNewState(e.node.key);
    setColumnsSettingMap({ ...newColumnMap });
  });

  // 记录受控状态的默认值
  const defaultColumnControlSettingMap = useRef<Record<string, ProColumnsState>>(null);
  useEffectOnce(() => {
    if (initialColumnSettingConfig?.value) {
      defaultColumnControlSettingMap.current = structuredClone(initialColumnSettingConfig.value);
    }
  });

  /** 重置项目 */
  const onResetConfig = useEvent(() => {
    clearPersistenceStorage();
    setColumnsSettingMap(
      initialColumnSettingConfig?.defaultValue || defaultColumnControlSettingMap.current || defaultColumnsSettingMap
    );
  });

  return (
    <Popover
      arrow={false}
      trigger="click"
      placement="bottomRight"
      title={
        <div className={clsx(hashId, `${prefixCls}-title`)}>
          <Checkbox
            indeterminate={indeterminate}
            checked={unCheckedKeys.length === 0 && unCheckedKeys.length !== columns.length}
            onChange={checkAll}
          >
            列展示
          </Checkbox>
          <a className={clsx(hashId, `${prefixCls}-reset-btn`)} onClick={onResetConfig}>
            重置
          </a>
        </div>
      }
      content={
        <Tree<ColumnTreeData>
          itemHeight={24}
          checkable
          blockNode
          onCheck={(_, e) => onCheckTree(e)}
          titleRender={(node) => {
            const wrappedTitle = (
              <Typography.Text style={{ width: 80 }} ellipsis={{ tooltip: node.title }}>
                {node.title}
              </Typography.Text>
            );
            return wrappedTitle;
          }}
          checkedKeys={treeConfig.checkedKeys}
          treeData={treeConfig.treeList}
        />
      }
    >
      <Tooltip title="列设置">
        <SettingOutlined />
      </Tooltip>
    </Popover>
  );
}
