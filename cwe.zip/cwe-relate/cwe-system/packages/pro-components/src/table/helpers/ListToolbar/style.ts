import useAntdStyle from "../../../theme/useAntdStyle";

export default function useStyle(prefixCls: string) {
  return useAntdStyle("ProTableListToolbar", (token) => {
    const componentCls = `.${prefixCls}`;

    return {
      [`${componentCls}`]: {
        display: "flex",
        justifyContent: "space-between",
        paddingBlock: token.padding,
        paddingInline: token.paddingXS,

        "&-left": {
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "flex-start",
          alignItems: "center",
          gap: token.marginXS,
          maxWidth: "calc(100% - 200px)",
        },
        "&-title": {
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-start",
          color: token.colorText,
          fontSize: token.fontSizeLG,
          fontWeight: token.fontWeightStrong,
        },

        "&-right": {
          flex: 1,
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "flex-end",
          alignItems: "center",
          gap: token.marginXS,
        },

        "&-setting-items": {
          display: "flex",
          gap: token.marginXS,
          lineHeight: "32px",
          alignItems: "center",
        },
        "&-setting-item": {
          marginInline: 4,
          color: token.colorIconHover,
          fontSize: token.fontSizeLG,
          cursor: "pointer",
          "> span": { display: "block", width: "100%", height: "100%" },
          "&:hover": {
            color: token.colorPrimary,
          },
        },
      },
    };
  });
}
