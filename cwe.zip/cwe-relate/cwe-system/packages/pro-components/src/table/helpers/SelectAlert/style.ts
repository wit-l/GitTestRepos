import useAntdStyle from "../../../theme/useAntdStyle";

export default function useStyle(prefixCls: string) {
  return useAntdStyle("ProTableAlert", (token) => {
    const componentCls = `.${prefixCls}`;

    return {
      [`${componentCls}`]: {
        marginBlockEnd: token.margin,
        backgroundColor: token.colorFillQuaternary,
        border: "none",
        borderRadius: token.borderRadius,
        paddingBlock: token.paddingSM,
        paddingInline: token.paddingLG,

        "&-wrapper": {
          display: "flex",
          alignItems: "center",
          // transition: 'all 0.3s',
          color: token.colorTextTertiary,
        },
        "&-info": {
          flex: 1,
        },
        "&-option": {
          minWidth: 48,
          paddingInlineStart: token.padding,
        },
      },
    };
  });
}
