import useAntdStyle from "../../theme/useAntdStyle";

export default function useStyle(prefixCls: string) {
  return useAntdStyle("ProTable", (token) => {
    const componentCls = `.${prefixCls}`;

    return {
      [`${componentCls}-search-card`]: {
        marginBlockEnd: token.margin,
      },
      // 不直接使用 sematic 的 body 语义，是因为样式的权重不够
      // card-body 样式权重为 2，而 sematic body 的权重是 1
      [`${componentCls}-card`]: {
        [`${token.antCls}-card-body`]: {
          paddingBlockStart: 0,
          paddingBlockEnd: token.padding,
        },
      },
    };
  });
}
