import { DownloadOutlined, EllipsisOutlined, PlusOutlined } from "@ant-design/icons";
import { Button, Dropdown, Image, Input, Space, Tooltip } from "antd";
import qs from "query-string";

import type { ProColumnsType } from "../interface";
import ProTable from "../pro-table";
import parseRequestParams from "./_utils/parseParams";
import type { DataType } from "./_utils/type";

export default function Demo() {
  const columns: ProColumnsType<DataType>[] = [
    {
      title: "Name",
      dataIndex: "name",
      sorter: true,
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Gender",
      dataIndex: "gender",
      filters: [
        { text: "Male", value: "male" },
        { text: "Female", value: "female" },
      ],
    },
    {
      title: "Birthday",
      dataIndex: "birthdate",
      sorter: true,
    },
    {
      title: "City",
      dataIndex: "city",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Address",
      dataIndex: "address",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Avatar",
      dataIndex: "avatar",
      render: (_, record) => record.avatar && <Image src={record.avatar} alt={record.name} width={30} />,
    },
    {
      title: "Email",
      dataIndex: "email",
    },
  ];

  return (
    <ProTable<DataType>
      columns={columns}
      rowKey="id"
      toolbar={{
        headerTitle: "测试标题",
        setting: (defaultSetting) => [
          ...defaultSetting,
          <Tooltip key="download" title="下载">
            <DownloadOutlined />
          </Tooltip>,
        ],
        action: () => [
          <Space key="extra">
            <Button key="button" icon={<PlusOutlined />} type="primary">
              新建
            </Button>
            <Dropdown
              key="menu"
              menu={{
                items: [
                  { label: "导入数据", key: "import" },
                  { label: "导出数据", key: "export" },
                  { label: "批量分配", key: "assign" },
                ],
              }}
            >
              <Button>
                <EllipsisOutlined />
              </Button>
            </Dropdown>
          </Space>,
        ],
      }}
      request={async (params, filter, sort) => {
        const parseParams = parseRequestParams(params, filter, sort);

        const response = await fetch(
          `https://660d2bd96ddfa2943b33731c.mockapi.io/api/users?${qs.stringify(parseParams)}`
        );

        const data = await response.json();
        return {
          data,
          total: 100,
        };
      }}
    />
  );
}
