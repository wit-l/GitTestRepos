import { Image, Input, Space, Table } from "antd";
import qs from "query-string";

import type { ProColumnsType } from "../interface";
import ProTable from "../pro-table";
import parseRequestParams from "./_utils/parseParams";
import type { DataType } from "./_utils/type";

export default function Demo() {
  const columns: ProColumnsType<DataType>[] = [
    {
      title: "Name",
      dataIndex: "name",
      sorter: true,
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Gender",
      dataIndex: "gender",
      filters: [
        { text: "Male", value: "male" },
        { text: "Female", value: "female" },
      ],
    },
    {
      title: "Birthday",
      dataIndex: "birthdate",
      sorter: true,
    },
    {
      title: "City",
      dataIndex: "city",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Address",
      dataIndex: "address",
      renderSearchFormItem: () => <Input placeholder="Please input" />,
    },
    {
      title: "Avatar",
      dataIndex: "avatar",
      render: (_, record) => record.avatar && <Image src={record.avatar} alt={record.name} width={30} />,
    },
    {
      title: "Email",
      dataIndex: "email",
    },
  ];

  return (
    <ProTable<DataType>
      columns={columns}
      rowKey="id"
      rowSelection={{
        selections: [Table.SELECTION_ALL, Table.SELECTION_INVERT],
        preserveSelectedRowKeys: true,
      }}
      rowSelectionAlert={{
        infoRender: ({ selectedRowKeys, selectedRows, onClearSelected }) => (
          <Space size={24}>
            <span>
              已选 {selectedRowKeys.length} 项
              <a style={{ marginInlineStart: 8 }} onClick={onClearSelected}>
                取消选择
              </a>
            </span>
            <span>{`选中 ids: ${selectedRows.map((item) => item.id).join(",")}`}</span>
          </Space>
        ),
        optionRender: (_props) => (
          <Space size={16}>
            <a>批量删除</a>
            <a>批量下载</a>
            <a>批量导出</a>
          </Space>
        ),
      }}
      request={async (params, filter, sort) => {
        const parseParams = parseRequestParams(params, filter, sort);

        const response = await fetch(
          `https://660d2bd96ddfa2943b33731c.mockapi.io/api/users?${qs.stringify(parseParams)}`
        );

        const data = await response.json();
        return {
          data,
          total: 100,
        };
      }}
    />
  );
}
