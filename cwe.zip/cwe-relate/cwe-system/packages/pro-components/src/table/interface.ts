import type { CardProps, FormInstance, FormItemProps, TableProps } from "antd";
import type { ColumnGroupType, ColumnType } from "antd/es/table";

import type { SubmitterProps } from "../_common/Submitter";
import type { IAnyObject } from "../_common/type";
import type { QueryFilterProps } from "../query-filter";
import type { SelectAlertRenderType } from "./helpers/SelectAlert";

// 无法直接抽取 antd columns 的类型使用，此处引用其内部类型进行重写
export type AntdColumnsType<DataType> = ColumnGroupType<DataType> | ColumnType<DataType>;

export type AntdTableFilter = Parameters<NonNullable<TableProps["onChange"]>>[1];
export type AntdTableSort<RecordType = IAnyObject> = Parameters<NonNullable<TableProps<RecordType>["onChange"]>>[2];
export type AntdTableExtra<RecordType = IAnyObject> = Parameters<NonNullable<TableProps<RecordType>["onChange"]>>[3];

export type DensitySize = "small" | "medium" | "middle" | "large"; // for antd SizeType

// ========================== Internal ==========================

export type ProColumnsType<DataType = any> = AntdColumnsType<DataType> & {
  children?: ProColumnsType<DataType>[];
  /**
   * @description 列标题
   *
   * title 需生成 FormItem，但 antd title 支持回调渲染，FormItem 无法正确处理，因此不再支持回调函数
   */
  title?: React.ReactNode;
  /**
   * @description 搜索表单内容
   *
   * 无需传递 `Form.Item`，底层会自动包装并填充 `label` `name`。如需更改默认行为，请使用 `searchFormItemProps`
   *
   * 当使用 `ProFields` 类的组件时，不传递 name 和 label 也会根据当前的 `title` `dataIndex` 生成 Form.Item `label` `name`
   */
  renderSearchFormItem?: () => React.ReactNode;
  searchFormItemProps?: FormItemProps<DataType>;
  /**
   * @description 对 columns 自动生成的搜索表单排序，数字越小越靠前
   */
  searchOrder?: number;
  /**
   * @description 禁用当前列设置状态控制（Toolbar 列调整使用）
   */
  disableColumnSetting?: boolean;
  /**
   * @description 列在设置面板中隐藏
   *
   * 设置 `hidden` 是在表格中默认不展示，是 antd 的 API，但是列设置中依然可以切换显隐
   *
   * 设置 `hidden` 不出现在表格中，同时设置 `hiddenInSetting` 不出现在列设置中，可以应用于权限列控制
   */
  hideInSetting?: boolean;
};

export interface RequestResult<DataType> {
  data: DataType[] | undefined;
  total: number;
}

export type RequestTableParams<P = IAnyObject> = P & {
  pageSize?: number;
  current?: number;
};

export interface SearchConfig extends SubmitterProps {}

export interface ProColumnsState {
  hidden?: boolean;
  // fixed?: 'start' | 'end' | boolean; // TODO
  // order?: number; // TODO
  disableColumnSetting?: boolean;
}

export interface ProColumnSettingConfigType {
  /**
   * @description 持久化的类型，支持 localStorage 和 sessionStorage
   */
  persistenceType?: "localStorage" | "sessionStorage";
  /**
   * @description 持久化 key，用于存储到 storage 中
   */
  persistenceKey?: string;
  /**
   * @description ColumnsState 默认值，key 通常对应 column item 的 dataIndex 或 key
   */
  defaultValue?: Record<string, ProColumnsState>;
  /**
   * @description ProColumnsState 值
   */
  value?: Record<string, ProColumnsState>;
  onChange?: (map: Record<string, ProColumnsState>) => void;
}

export interface ListToolbarProps {
  /**
   * @description 自定义工具栏区域（最右侧功能图标区域的左边）
   */
  action?: () => React.ReactNode[];
  /**
   * @description 自定义列设置区域（最右侧功能图标）。若不想显示，返回 null 等空 DOM 即可
   *
   * 自定义渲染时，默认预设样式将会失效
   */
  setting?: (defaultSetting: React.ReactNode[]) => React.ReactNode;
  /**
   * @description 列表标题（最左侧区域）
   */
  headerTitle?: React.ReactNode;
}

export interface RowSelectionAlert<DataType> {
  /**
   * @description 选择列时，自定义渲染选择区域左侧提示信息
   */
  infoRender?: SelectAlertRenderType<DataType>;
  /**
   * @description 选择列时，自定义渲染选择区域右侧操作信息
   */
  optionRender?: SelectAlertRenderType<DataType>;
}

export interface ProTableProps<DataType = IAnyObject, Params = IAnyObject> extends Omit<
  TableProps<DataType>,
  "columns" | "rowSelection"
> {
  /**
   * @description antd table columns 并对其进行扩展
   */
  columns?: ProColumnsType<DataType>[];
  /**
   * @default 80
   */
  labelWidth?: QueryFilterProps["labelWidth"];
  /**
   * @description 是否手动触发请求
   * @default false
   */
  manual?: boolean;
  /**
   * @description 是否请求
   * @default true
   */
  ready?: boolean;
  /**
   * @description 对 table 从数据加载到回显进行底层抽象，减少业务侧重复代码，推荐使用 `request` 而非 `dataSource`
   *
   * 搜索内容、页码、分页、筛选、排序、重置时都会触发
   *
   * 第一个参数 params 回传搜索参数和 `pageSize` `current` ，这两个字段属于 antd 规范，`filter` 与 `sort` 由 ProTable 内部管理
   */
  request?: (
    params: RequestTableParams<Params>,
    filter: AntdTableFilter,
    sort: AntdTableSort<DataType>
  ) => Promise<RequestResult<DataType>>;
  /**
   * @description 重置时触发
   */
  onReset?: () => void;
  /**
   * @description 搜索时触发
   *
   * 当处于本地搜索的情况下，不会透出 current pageSize
   */
  onSearch?: (params: RequestTableParams<Params>, filter: AntdTableFilter, sort: AntdTableSort<DataType>) => void;
  /**
   * @description 搜素区域和表格区域的 card props
   */
  cardProps?: {
    search?: CardProps;
    table?: CardProps;
  };
  /**
   * @description 窗口重新获得焦点时是否自动刷新
   * @default true
   */
  refreshOnWindowFocus?: boolean;
  /**
   * @description 窗口重新获得焦点时刷新的最小时间间隔（毫秒）
   * @default 5000
   */
  focusTimespan?: number;
  /**
   * @description 是否使用 ErrorBoundary 捕获错误
   * @default true
   */
  errorBoundary?: boolean;
  /**
   * @description 列无数据时显示
   * @default '-'
   */
  columnEmptyText?: string | number | React.ReactElement | false;
  /**
   * @description 获取 ProTable 的部分快捷操作函数
   */
  actionRef?: React.Ref<ProTableActionType>;
  /**
   * @description 搜索区域 / Action 配置，false 则不显示
   */
  search?: false | SearchConfig;
  /**
   * @description Toolbar 区域配置，false 则不显示
   */
  toolbar?: false | ListToolbarProps;
  /**
   * @description 选择列时，自定义渲染选择区域，仅 `rowSelection` 存在时有效
   */
  rowSelectionAlert?: RowSelectionAlert<DataType>;
  /**
   *  @description 对 antd rowSelection 的扩展
   *
   * 若要实现跨页选中，使用 antd 提供的 `rowSelection.preserveSelectedRowKeys` 即可
   *
   * @default false
   */
  rowSelection?: false | (TableProps<DataType>["rowSelection"] & { alwaysShowAlert?: boolean });
  /**
   * @description 表格默认大小
   * @default 'medium'
   */
  defaultSize?: DensitySize;
  /**
   * @description 列状态管理的配置，比如设置持久化缓存，默认列配置，监听列状态变化
   */
  columnsSettingConfig?: ProColumnSettingConfigType;
  /**
   * @description table size 改变时触发
   */
  onSizeChange?: (size: DensitySize) => void;
  /**
   * @description 获取搜索表单实例，同 antd Form 实例
   */
  form?: FormInstance<Params>;
}

export interface ProTableActionType {
  /**
   * @description 重新加载数据
   */
  reload: () => void;
  /**
   * @description 重置表格所有筛选、排序、分页
   */
  reset: () => void;
  /**
   * @description 清空表格选中项
   */
  clearSelected: () => void;
}
