import { createContext } from "react";

import type { Updater } from "../_common/type";
import type {
  DensitySize,
  ProColumnSettingConfigType,
  ProColumnsState,
  ProTableActionType,
  ProTableProps,
} from "./interface";

export interface ProTableContextValue {
  /**
   * @description table size 在 ProTableProvider 中设置默认值
   */
  size: DensitySize;
  changeTableSize: (size: DensitySize) => void;
  columns?: ProTableProps<any>["columns"];
  /**
   * @description 收集所有列进行状态管理，key 通常为 column 的 dataIndex 或 key，value 为列配置
   *
   * 主要用于管理列状态，例如：列隐藏，固定，是否可操作等
   */
  columnsSettingMap: Record<string, ProColumnsState>;
  defaultColumnsSettingMap: Record<string, ProColumnsState>;
  setColumnsSettingMap: Updater<Record<string, ProColumnsState>>;

  actionRef: React.RefObject<ProTableActionType | undefined>;

  clearPersistenceStorage: () => void;
  initialColumnSettingConfig?: ProColumnSettingConfigType;
}

export interface ProTableProviderProps<T = any> {
  defaultSize?: DensitySize;
  size?: DensitySize;
  columns?: ProTableProps<T>["columns"];
  columnsSettingConfig?: ProColumnSettingConfigType;
  onSizeChange?: (size: DensitySize) => void;
}

export const ProTableContext = createContext<ProTableContextValue>({} as ProTableContextValue);
