import { useEffect, useEffectEvent } from "react";

function usePersistenceStorage(storageType?: "localStorage" | "sessionStorage", storageKey?: string, value?: any) {
  const supportStorageSave = typeof window !== "undefined" && storageType && storageKey;

  const clearPersistenceStorage = useEffectEvent(() => {
    if (!supportStorageSave) {
      return;
    }

    const storage = window[storageType];
    try {
      storage?.removeItem(storageKey);
    } catch (error) {
      console.warn(error);
    }
  });

  useEffect(() => {
    if (!supportStorageSave) {
      return;
    }

    const storage = window[storageType];
    try {
      storage?.setItem(storageKey, JSON.stringify(value));
    } catch (error) {
      console.error(error);
      clearPersistenceStorage();
    }
  }, [storageType, storageKey, value, supportStorageSave]);

  return { clearPersistenceStorage };
}

export default usePersistenceStorage;
