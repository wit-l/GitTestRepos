import { merge, useControlledState, useEvent } from "@rc-component/util";
import { useMemo, useRef, useState } from "react";

import type { Updater } from "../../_common/type";
import type { ProTableContextValue, ProTableProviderProps } from "../context";
import { ProTableContext } from "../context";
import type {
  DensitySize,
  ProColumnSettingConfigType,
  ProColumnsState,
  ProColumnsType,
  ProTableActionType,
  ProTableProps,
} from "../interface";
import { genColumnKey, genColumnKeyWithParentKey } from "../utils";
import usePersistenceStorage from "./usePersistenceStorage";

// 参照思路实现 https://github.com/ant-design/pro-components/blob/master/src/table/Store/Provide.tsx
function useTableProvider(props: ProTableProviderProps): ProTableContextValue {
  // ========================== Table Size ======================
  const [size, setTableSize] = useControlledState<DensitySize>(
    () => props.size || props?.defaultSize || "medium",
    props.size
  );

  const changeTableSize = useEvent((size: DensitySize) => {
    setTableSize(size);
    props?.onSizeChange?.(size);
  });

  // ========================== Columns Setting ======================
  /** 默认全选中 */
  const defaultColumnsSettingMap = useMemo(() => {
    if (props.columnsSettingConfig?.defaultValue) {
      return props.columnsSettingConfig.defaultValue;
    }

    const columnKeyMap: Record<string, ProColumnsState> = {};

    function generateColumnKey(columns: ProColumnsType<any>[] = [], pKey?: string | number) {
      columns.forEach((col, index) => {
        if (col.hideInSetting) {
          return;
        } // 忽略隐藏列
        const columnKey = genColumnKeyWithParentKey(col.key ?? (col as any).dataIndex, index, pKey);
        columnKeyMap[columnKey] = {
          hidden: col.hidden,
          // fixed: (col as any).fixed, // left or right is deprecated by antd
          disableColumnSetting: col.disableColumnSetting,
        };
        if (col.children) {
          generateColumnKey(col.children, columnKey);
        }
      });
    }
    generateColumnKey(props.columns);

    return columnKeyMap;
    // effect 不应该对 default Columns 敏感
    // oxlint-disable-next-line react-hooks/exhaustive-deps
  }, [props.columns]);

  const genDefaultColumnsMapSettings = () => {
    const { persistenceType, persistenceKey } = props.columnsSettingConfig || {};

    if (persistenceKey && persistenceType && typeof window !== "undefined") {
      /** 从持久化中读取数据 */
      const storage = window[persistenceType];
      try {
        const storageValue = storage?.getItem(persistenceKey);
        if (storageValue) {
          if (props?.columnsSettingConfig?.defaultValue) {
            // 实际生产中，defaultValue往往作为系统方默认配置，则优先级不应高于用户配置的storageValue
            return merge({}, props?.columnsSettingConfig?.defaultValue, JSON.parse(storageValue));
          }
          return JSON.parse(storageValue);
        }
      } catch (error) {
        console.warn(error);
      }
    }
    return props.columnsSettingConfig?.value || props.columnsSettingConfig?.defaultValue || defaultColumnsSettingMap;
  };

  const [columnsSettingMap, setColumnsSettingMapInner] = useControlledState<Record<string, ProColumnsState>>(
    genDefaultColumnsMapSettings,
    props.columnsSettingConfig?.value
  );

  // ========================== Columns AutoUpdate ======================

  const columns = useMemo(() => {
    const genNewColumnsBySetting = (cols: ProTableProps["columns"]): ProTableProps["columns"] =>
      cols?.map((col, index) => {
        const columnKey = genColumnKey((col as any).dataIndex ?? col.key, index);
        const setting = columnsSettingMap[columnKey];
        // setting 存在时以列设置中的 hidden 为准（设置面板可控显隐）；
        // 不存在时（如 hideInSetting 列）保留 col 自身的 hidden，避免被覆写为 undefined
        const newCol = setting ? { ...col, hidden: setting.hidden ?? col.hidden } : { ...col };

        if (newCol.children) {
          newCol.children = genNewColumnsBySetting(newCol.children);
        }

        return newCol;
      });

    return genNewColumnsBySetting(props.columns);
  }, [props.columns, columnsSettingMap]);

  const { clearPersistenceStorage } = usePersistenceStorage(
    props.columnsSettingConfig?.persistenceType,
    props.columnsSettingConfig?.persistenceKey,
    columnsSettingMap
  );

  // ========================== Shared Utils ======================
  // 惰性值 仅作为初始化数据的状态记录。为什么不是 useRef？ useRef 返回的是可更改值，不安全
  const [initialColumnSettingConfig] = useState<ProColumnSettingConfigType | undefined>(
    () => props.columnsSettingConfig
  );

  const actionRef = useRef<ProTableActionType>(undefined);

  // 需要类型的不能直接用 useEvent 包，会丢失类型提示
  const setColumnsSettingMap: Updater<Record<string, ProColumnsState>> = (updater) => {
    setColumnsSettingMapInner((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      props.columnsSettingConfig?.onChange?.(next);
      return next;
    });
  };

  const contextValue = {
    actionRef,

    size,
    changeTableSize,

    columns,
    columnsSettingMap,
    defaultColumnsSettingMap,
    setColumnsSettingMap: useEvent(setColumnsSettingMap),
    initialColumnSettingConfig,

    clearPersistenceStorage,
  } satisfies ProTableContextValue;

  return contextValue;
}

interface ProTableContextProviderProps extends ProTableProviderProps {}
export const ProTableProvider = (props: React.PropsWithChildren<ProTableContextProviderProps>) => {
  const { children, ...providerProps } = props;
  const value = useTableProvider(providerProps);
  return <ProTableContext.Provider value={value}>{children}</ProTableContext.Provider>;
};
