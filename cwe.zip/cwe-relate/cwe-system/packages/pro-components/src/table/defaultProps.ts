import type { ProTableProps } from "./interface";

export const proTableDefaultProps: ProTableProps = {
  labelWidth: 80,
  manual: false,
  ready: true,
  refreshOnWindowFocus: true,
  focusTimespan: 5000,
  errorBoundary: true,
  columnEmptyText: "-",
  rowSelection: false,
  scroll: { x: true },
};
