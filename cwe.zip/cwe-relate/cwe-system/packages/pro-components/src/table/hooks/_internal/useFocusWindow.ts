import { isBrowser } from "es-toolkit";
import { useEffect, useEffectEvent, useRef } from "react";

interface useFocusWindowOptions {
  refreshOnWindowFocus?: boolean;
  focusTimespan?: number;
}

function useFocusWindow(cb: () => void, options: useFocusWindowOptions = {}) {
  const { refreshOnWindowFocus = false, focusTimespan = 5000 } = options;
  const lastTimeRef = useRef(0);
  const handleCb = useEffectEvent(cb);

  useEffect(() => {
    if (!refreshOnWindowFocus || !isBrowser()) {
      return;
    }

    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        const now = Date.now();
        if (now - lastTimeRef.current > focusTimespan) {
          handleCb();
        }
      } else {
        lastTimeRef.current = Date.now();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [refreshOnWindowFocus, focusTimespan]);
}

export default useFocusWindow;
