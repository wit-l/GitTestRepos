import { useMemo } from "react";

import type { ProTableProps } from "../../interface";

function useMergedPagination(pagination: ProTableProps["pagination"]): ProTableProps["pagination"] {
  return useMemo(() => {
    if (pagination === false) {
      return pagination;
    }

    return {
      showTotal(total, range) {
        return `第 ${range[0]}-${range[1]} 条/总共 ${total} 条`;
      },
      ...pagination,
    } satisfies ProTableProps["pagination"];
  }, [pagination]);
}

export default useMergedPagination;
