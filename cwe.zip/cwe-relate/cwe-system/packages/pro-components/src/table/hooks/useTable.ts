import { useEvent } from "@rc-component/util";
import type { FormInstance, TablePaginationConfig } from "antd";
import { isNumber, pick } from "es-toolkit";
import { useMemo, useState } from "react";

import useAsync from "../../_hook/useAsync";
import type { AntdTableFilter, AntdTableSort, ProColumnsType, ProTableProps, RequestTableParams } from "../interface";
import { buildInitialFilter, buildInitialSort } from "../utils";
import useFocusWindow from "./_internal/useFocusWindow";
import useMergedPagination from "./_internal/useMergedPagination";

interface UseTableOptions<D, P> {
  formInstance?: FormInstance<P>;
  pagination?: ProTableProps["pagination"];
  manual?: boolean;
  ready?: boolean;
  dataSource?: ProTableProps<D, P>["dataSource"];
  onChange?: ProTableProps<D, P>["onChange"];
  refreshOnWindowFocus?: ProTableProps<D, P>["refreshOnWindowFocus"];
  focusTimespan?: ProTableProps<D, P>["focusTimespan"];
  /**
   * @description 用于派生初始 filter / sort 状态（取 columns 上的 default 值）。仅在初始化时读取一次。
   */
  columns?: ProColumnsType<D>[];
}

const DEFAULT_PAGINATION = { current: 1, pageSize: 10 };

function genDefaultPagination(pagination: ProTableProps["pagination"]): ProTableProps["pagination"] {
  if (pagination === false) {
    return false;
  }

  const { current, pageSize, defaultCurrent, defaultPageSize, ...rest } = pagination || {};
  return {
    // 由于底层受控，外部传入 defaultCurrent 时视为想使用此默认值，在首次请求时使用
    current: current || defaultCurrent || DEFAULT_PAGINATION.current,
    pageSize: pageSize || defaultPageSize || DEFAULT_PAGINATION.pageSize,
    total: 0,
    ...rest,
  };
}

const useTable = <D, P>(service: ProTableProps<D, P>["request"], options: UseTableOptions<D, P>) => {
  const {
    formInstance,
    pagination: propPagination,
    manual,
    ready,
    dataSource: propDataSource,
    onChange,
    refreshOnWindowFocus,
    focusTimespan,
    columns,
  } = options;

  const isLocalData = !!propDataSource;
  const paginationDisabled = propPagination === false;

  // ============================== state ==============================
  const [paginationState, setPaginationState] = useState(() => genDefaultPagination(propPagination));
  const [internalDataSource, setInternalDataSource] = useState<D[]>([]);
  // ProTable 内部托管的 filter / sort，作为列的受控数据源，避免内外双状态不一致
  const [filterState, setFilterState] = useState<AntdTableFilter>(() => buildInitialFilter<D>(columns));
  const [sortState, setSortState] = useState<AntdTableSort<D>>(() => buildInitialSort<D>(columns));

  const initialRequestParams = (
    paginationDisabled
      ? {}
      : pick(genDefaultPagination(propPagination) as TablePaginationConfig, ["current", "pageSize"])
  ) as RequestTableParams<P>;

  // Fetch Data
  const result = useAsync(service, {
    manual,
    ready: ready && !isLocalData,
    defaultParams: [initialRequestParams, filterState, sortState], // 此参数只会在加载和 ready 变化时有效
    onSuccess(data) {
      setInternalDataSource(data.data || []);
      setPaginationState((prev) => (prev ? { ...prev, total: data.total } : prev));
    },
  });

  useFocusWindow(result.refresh, { refreshOnWindowFocus, focusTimespan });

  // ============================== handlers ==============================
  /**
   * 处理分页参数，防止搜索后总数变少时还停留在不存在的页码
   * 例：原 100 条（10页），搜索后仅 10 条，此时就不能在第 10 页了
   */
  function handleSafePagination(c?: number, p?: number) {
    if (!isNumber(c) || !isNumber(p)) {
      return {};
    }

    const total = result.data?.total || 0;
    const toSafePageSize = p <= 0 ? 1 : p;
    let toSafeCurrent = c <= 0 ? 1 : c;

    const tempTotalPage = Math.ceil(total / toSafePageSize);
    if (toSafeCurrent > tempTotalPage) {
      toSafeCurrent = Math.max(1, tempTotalPage);
    }

    return { current: toSafeCurrent, pageSize: toSafePageSize };
  }

  const onTableChange: ProTableProps<D, P>["onChange"] = (pagination, filters, sorter, extra) => {
    onChange?.(pagination, filters, sorter, extra);

    // filter / sort 受控：本地 / 远程 都需更新，否则受控值不会变更，UI 不一致
    setFilterState(filters);
    setSortState(sorter);

    // 本地数据：由 antd Table 原生处理，内部不再维护分页状态
    if (isLocalData) {
      return;
    }

    const safePagination = handleSafePagination(pagination.current, pagination.pageSize);
    setPaginationState((prev) => ({ ...prev, ...safePagination }));

    // https://ant-design.antgroup.com/components/table-cn#table-demo-ajax
    // https://github.com/ant-design/ant-design/issues/14557
    // 避免分页切换时的警告 `dataSource` length is less than `pagination.total` but large than `pagination.pageSize`.
    // 例：从页数每页 20 切换为每页 10，dataSource.length 也需要从 20 请求新数据变为 10
    // 但是 state 切换完成后才会重新请求，网络请求有滞后，而 state 更新很快，页码为 10 时，此时 dataSource.length 依然是 20 导致的警告，属于数据时序性问题
    const [oldRequestParams] = result.params;
    if (safePagination.pageSize !== oldRequestParams.pageSize) {
      setInternalDataSource([]);
    }

    result.run(
      { ...oldRequestParams, current: safePagination.current, pageSize: safePagination.pageSize },
      filters,
      sorter
    );
  };

  const reset = () => {
    // 重置表单
    formInstance?.resetFields();
    // 重置分页
    setPaginationState(genDefaultPagination(propPagination));
    // 重置 filter 和 sort
    const initialFilter = buildInitialFilter<D>(columns);
    const initialSort = buildInitialSort<D>(columns);
    setFilterState(initialFilter);
    setSortState(initialSort);

    // 跑请求并传递初始参数
    result.run(initialRequestParams, initialFilter, initialSort);
  };

  // ============================== Pagination ==============================
  // 关闭分页时直接返回 false
  // 本地数据时内部不再对 pagination 受控，交给 antd
  const tablePaginationVariant: ProTableProps["pagination"] = useMemo(() => {
    if (paginationDisabled) {
      return false;
    }
    if (isLocalData) {
      return propPagination;
    }
    return { ...paginationState, ...propPagination };
  }, [paginationDisabled, isLocalData, propPagination, paginationState]);
  const tablePagination = useMergedPagination(tablePaginationVariant);

  return {
    ...result,
    reset: useEvent(reset),
    filterState,
    sortState,
    tableProps: {
      loading: result.loading,
      onChange: useEvent(onTableChange),
      dataSource: propDataSource ?? internalDataSource, // 外部传入了，就以外部 dataSource 为准
      pagination: tablePagination,
    } satisfies ProTableProps<D, P>,
  };
};

export default useTable;
