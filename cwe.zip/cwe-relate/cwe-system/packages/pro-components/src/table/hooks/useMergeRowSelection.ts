import { useControlledState, useEvent } from "@rc-component/util";
import type { TableRowSelection } from "antd/es/table/interface";
import { useMemo, useState } from "react";

import type { IAnyObject } from "../../_common/type";
import type { ProTableProps } from "../interface";

interface UseMergeRowSelectionReturn<D = IAnyObject> {
  rowSelection?: TableRowSelection<D>;
  selectedRows: D[];
  selectedRowKeys?: React.Key[];
  onClearSelected: () => void;
}

function useMergeRowSelection<D = IAnyObject>(
  rowSelection: ProTableProps<D>["rowSelection"]
): UseMergeRowSelectionReturn<D> {
  const [selectedRows, setSelectedRows] = useState<D[]>([]);
  const [selectedRowKeys, setSelectedRowKeys] = useControlledState<React.Key[] | undefined>(
    rowSelection ? rowSelection?.defaultSelectedRowKeys || [] : undefined,
    rowSelection ? rowSelection.selectedRowKeys : undefined
  );

  const mergedRowSelection: ProTableProps<D>["rowSelection"] = useMemo(() => {
    if (rowSelection === false) {
      return undefined;
    }
    return {
      selectedRowKeys,
      ...rowSelection,
      onChange: (keys, rows, info) => {
        if (rowSelection) {
          rowSelection.onChange?.(keys, rows, info);
          setSelectedRows(rows);
        }
        setSelectedRowKeys(keys);
      },
    };
  }, [selectedRowKeys, rowSelection, setSelectedRowKeys]);

  const onClearSelected = useEvent(() => {
    if (rowSelection) {
      rowSelection.onChange?.([], [], { type: "none" });
    }
    setSelectedRows([]);
    setSelectedRowKeys([]);
  });

  return {
    rowSelection: mergedRowSelection,
    selectedRowKeys,
    selectedRows,
    onClearSelected,
  };
}

export default useMergeRowSelection;
