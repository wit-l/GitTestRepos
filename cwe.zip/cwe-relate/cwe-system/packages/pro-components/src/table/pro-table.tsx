import { Card, ConfigProvider, Form, Table } from "antd";
import type { CardProps } from "antd/es/card/Card";
import type { NamePath } from "antd/es/form/interface";
import type { ColumnType } from "antd/es/table";
import clsx from "clsx";
import { isUndefined } from "es-toolkit";
import { cloneElement, Fragment, useContext, useImperativeHandle, useMemo } from "react";

import { isCweProFormItem } from "../_common/is";
import type { IAnyObject } from "../_common/type";
import useDefaultProps from "../_hook/useDefaultProps";
import useSemanticProps from "../_hook/useSemanticProps";
import { QueryFilter } from "../query-filter";
import { ProTableContext } from "./context";
import { proTableDefaultProps } from "./defaultProps";
import { ErrorBoundary } from "./helpers/ErrorBoundary";
import ListToolbar from "./helpers/ListToolbar";
import SelectAlert from "./helpers/SelectAlert";
import useMergeRowSelection from "./hooks/useMergeRowSelection";
import useTable from "./hooks/useTable";
import type { DensitySize, ProTableActionType, ProTableProps } from "./interface";
import { ProTableProvider } from "./provider/ProTableProvider";
import useStyle from "./style";
import { genColumnKey, genProColumns, genSearchColumns } from "./utils";

function ProTableCore<D = IAnyObject, P = IAnyObject>(props: ProTableProps<D, P>) {
  const mergedProps = useDefaultProps(props, proTableDefaultProps);
  const {
    // feature props
    labelWidth,
    manual,
    ready,
    request,
    onSearch,
    onReset,
    refreshOnWindowFocus,
    focusTimespan,
    errorBoundary,
    columnEmptyText,
    actionRef,
    search,
    toolbar,
    rowSelectionAlert,
    form,

    // card props
    cardProps,

    // table props
    rowSelection: propRowSelection,
    loading: propLoading,
    dataSource,
    onChange,
    pagination,
    ...restProps
  } = mergedProps;

  const [searchForm] = Form.useForm<P>(form);
  const context = useContext(ProTableContext);

  const {
    tableProps,
    params,
    run,
    reset,
    refresh,
    loading: internalLoading,
    filterState,
    sortState,
  } = useTable(request, {
    manual: manual,
    ready: ready,
    formInstance: searchForm,
    pagination,
    onChange,
    dataSource,
    refreshOnWindowFocus,
    focusTimespan,
    columns: context.columns,
  });

  const { rowSelection, selectedRowKeys, selectedRows, onClearSelected } = useMergeRowSelection(propRowSelection);

  const forwardAction = useMemo(
    () =>
      ({
        reload: refresh,
        reset,
        clearSelected: onClearSelected,
      }) satisfies ProTableActionType,
    [refresh, reset, onClearSelected]
  );

  // actionRef 外部使用，context.actionRef 内部使用
  useImperativeHandle(actionRef, () => forwardAction);
  useImperativeHandle(context.actionRef, () => forwardAction);

  // ================================== Search Form ==================================
  const loading = isUndefined(propLoading) ? internalLoading : propLoading;
  const searchColumns = genSearchColumns<D>(context.columns);

  const { getPrefixCls } = useContext(ConfigProvider.ConfigContext);
  const prefixCls = getPrefixCls("pro-table");
  const hashId = useStyle(prefixCls);

  const filterCardClassNames = {
    root: clsx(hashId, `${prefixCls}-search-card`),
  };
  const [mergedFilterCardClassNames, mergedFilterCardStyles] = useSemanticProps<
    NonNullable<CardProps["classNames"]>,
    NonNullable<CardProps["styles"]>,
    CardProps
  >([filterCardClassNames, cardProps?.search?.classNames], [cardProps?.search?.styles], {
    props: cardProps?.search || {},
  });

  const onSearchFinish = (values: P) => {
    const [paginationWithParams] = params;
    const newParamsWithValues = { ...paginationWithParams, ...values };

    run(newParamsWithValues, filterState, sortState);
    onSearch?.(newParamsWithValues, filterState, sortState);
  };

  const onSearchReset = () => {
    reset();
    onReset?.();
  };

  const renderFilterCard = () => {
    if (search === false || searchColumns.length === 0) {
      return null;
    }
    return (
      <Card {...cardProps?.search} classNames={mergedFilterCardClassNames} styles={mergedFilterCardStyles}>
        <QueryFilter
          form={searchForm}
          onFinish={onSearchFinish}
          onReset={onSearchReset}
          submitter={{
            submitButtonProps: { loading },
            ...search,
          }}
          labelWidth={labelWidth}
        >
          {searchColumns.map((col, index) => {
            const temCol = col as ColumnType<D>; // only as type
            const node = col.renderSearchFormItem?.();
            // 如果是 ProField 类组件，本身带了 FormIem，就不再包了
            if (isCweProFormItem(node)) {
              const { name = temCol.dataIndex as NamePath<D>, label = temCol.title } = node.props;
              return cloneElement(node, { name, label: label as React.ReactNode });
            }
            return (
              <Form.Item
                label={col.title}
                name={temCol.dataIndex as NamePath<D>}
                key={genColumnKey((temCol.key ?? temCol.dataIndex) as React.Key, index)}
                {...col.searchFormItemProps}
              >
                {col.renderSearchFormItem?.()}
              </Form.Item>
            );
          })}
        </QueryFilter>
      </Card>
    );
  };

  // ================================== Table ==================================
  const mergedColumns = genProColumns({
    columns: context.columns,
    emptyText: columnEmptyText,
    filterState,
    sortState,
  });

  const renderRowSelectionAlertDom = () => {
    if (propRowSelection === false) {
      return null;
    }
    return (
      <SelectAlert
        selectedRowKeys={selectedRowKeys}
        selectedRows={selectedRows}
        onClearSelected={onClearSelected}
        alertInfoRender={rowSelectionAlert?.infoRender}
        alertOptionRender={rowSelectionAlert?.optionRender}
      />
    );
  };

  const tableCardClassNames = {
    root: clsx(hashId, `${prefixCls}-card`),
  };
  const [mergedTableCardClassNames, mergedTableCardStyles] = useSemanticProps<
    NonNullable<CardProps["classNames"]>,
    NonNullable<CardProps["styles"]>,
    CardProps
  >([tableCardClassNames, cardProps?.table?.classNames], [cardProps?.table?.styles], {
    props: cardProps?.table || {},
  });

  const MayBeWrapperErrorBoundary = errorBoundary ? ErrorBoundary : Fragment;
  return (
    <MayBeWrapperErrorBoundary>
      {renderFilterCard()}

      <Card {...cardProps?.table} classNames={mergedTableCardClassNames} styles={mergedTableCardStyles}>
        {toolbar !== false ? <ListToolbar {...toolbar} /> : null}
        {renderRowSelectionAlertDom()}
        <Table
          {...restProps}
          {...tableProps}
          loading={loading}
          columns={mergedColumns}
          size={context.size}
          rowSelection={rowSelection}
        />
      </Card>
    </MayBeWrapperErrorBoundary>
  );
}

function InternalProTable<DataType = IAnyObject, Params = IAnyObject>(props: ProTableProps<DataType, Params>) {
  const isDeprecatedSize = props.defaultSize === "middle" || props.size === "middle";
  if (process.env.NODE_ENV !== "production" && isDeprecatedSize) {
    console.error(
      "[deprecated ProTable from antd]: `middle` is deprecated and will be removed in v7, please useContext `medium` instead. "
    );
  }

  return (
    <ProTableProvider
      columnsSettingConfig={props.columnsSettingConfig}
      columns={props.columns}
      onSizeChange={props.onSizeChange}
      size={props.size as DensitySize}
      defaultSize={props.defaultSize}
    >
      <ProTableCore {...props} />
    </ProTableProvider>
  );
}

type CompoundedComponent = typeof InternalProTable & {
  Summary: typeof Table.Summary;
  displayName?: string;
};

const ProTable = InternalProTable as CompoundedComponent;

ProTable.Summary = Table.Summary;

if (process.env.NODE_ENV !== "production") {
  ProTable.displayName = "ProTable";
}

export default ProTable;
