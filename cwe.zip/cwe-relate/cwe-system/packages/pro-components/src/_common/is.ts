import { isValidElement } from "react";

import type { PureFormLayoutItemProps } from "../form/base/pure-form-item";

export function isCweProFormItem(node: React.ReactNode): node is React.ReactElement<PureFormLayoutItemProps> {
  return (
    isValidElement(node) &&
    // export 的组件，需要确认是 Pro 创建的，ProFormItem 和 ProField 类的组件 才存在 colProps，其余强行传入的 colProps 不识别
    ((node.type as any)?.__CWE_PRO_FORM_ITEM === true || (node.type as any)?.__CWE_PRO_FIELD === true)
  );
}

export function isCweProFormItemUnwrap(node: React.ReactNode) {
  return isValidElement(node) && (node.type as any)?.__CWE_PRO_FORM_UN_WRAP === true;
}
