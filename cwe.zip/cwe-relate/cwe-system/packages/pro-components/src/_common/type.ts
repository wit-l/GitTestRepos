export type IAnyObject = Record<PropertyKey, any>;
export type Updater<T> = (updater: T | ((origin: T) => T)) => void;
export type Fn = (this: any, ...args: any[]) => any;
export type Numeric = number | string;
