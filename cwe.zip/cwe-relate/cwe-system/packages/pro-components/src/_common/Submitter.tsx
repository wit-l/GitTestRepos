import { Button, Space } from "antd";
import type { ButtonProps } from "antd";

import type { IAnyObject } from "./type";

export interface SubmitterProps<Values = IAnyObject> {
  render?: (props: SubmitterProps<Values>, defaultDom: React.ReactNode[]) => React.ReactNode;
  /**
   * @description 提交按钮的文本
   * @default 提交
   */
  submitText?: string;
  /**
   * @description 重置按钮的文本
   * @default 重置
   */
  resetText?: string;
  /**
   * @description 提交按钮的 props，false 用于控制是否显示
   * @default { type: 'primary', htmlType: 'submit' }
   */
  submitButtonProps?: false | ButtonProps;
  /**
   * @description 重置按钮的 props.，false 用于控制是否显示
   * @default { htmlType: 'reset' }
   */
  resetButtonProps?: false | ButtonProps;
}

function Submitter<Values>(props: SubmitterProps<Values>) {
  const { render, submitText = "提交", resetText = "重置", submitButtonProps, resetButtonProps } = props;

  const defaultDom: React.ReactNode[] = [];

  if (resetButtonProps !== false) {
    defaultDom.push(
      <Button key="reset" htmlType="reset" {...resetButtonProps}>
        {resetText}
      </Button>
    );
  }
  if (submitButtonProps !== false) {
    defaultDom.push(
      <Button key="submit" type="primary" htmlType="submit" {...submitButtonProps}>
        {submitText}
      </Button>
    );
  }

  if (render) {
    return render(props, defaultDom);
  }

  return <Space>{defaultDom}</Space>;
}

export default Submitter;
