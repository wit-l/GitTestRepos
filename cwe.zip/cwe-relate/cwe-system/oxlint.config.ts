import { defineConfig } from "oxlint";

// All in root config https://github.com/oxc-project/oxc/discussions/20970
export default defineConfig({
  env: {
    browser: true,
  },
  plugins: ["eslint", "typescript", "unicorn", "oxc", "import", "node", "vitest", "vue", "react", "react-perf"],
  ignorePatterns: [
    "**/dist",
    "**/storybook-static",
    "**/.turbo",
    "**/package-lock.json",
    "**/routeTree.gen.ts",
    "**/playground",
  ],
  overrides: [
    // vitest
    {
      files: ["**/*.{test,spec}.{ts,tsx,js,jsx}", "**/__tests__/**/*.{ts,tsx,js,jsx}"],
      plugins: ["vitest"],
    },
    // tanstack
    {
      files: ["**/pages/**/*.{tsx,ts}"],
      rules: {
        "unicorn/filename-case": "off",
      },
    },
    {
      files: ["**/routeTree.gen.ts"],
      rules: {
        "unicorn/filename-case": "off",
        "unicorn/no-abusive-eslint-disable": "off",
      },
    },
  ],
  rules: {
    // vitest
    "vitest/require-mock-type-parameters": "off",
  },
});
