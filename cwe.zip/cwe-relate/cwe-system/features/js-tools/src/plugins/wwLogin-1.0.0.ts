// https://jjt.ccccltd.cn/api/doc#10719
interface WwLoginOptions {
  id: string;
  appid: string;
  agentid: string;
  redirect_uri: string;
  state?: string;
  style?: string;
  href?: string;
  host?: string;
}

/**
 * @description jjt [wwLogin](https://jjt.ccccltd.cn/js/sso/wwLogin-1.0.0.js) ts 版本
 */
export default function WwLogin(data: WwLoginOptions) {
  let host = data.host || "https://jjt.ccccltd.cn";

  const frame = document.createElement("iframe");
  let url = `${host}/wwopen/sso/qrConnect?appid=${data.appid}&agentid=${data.agentid}&
  redirect_uri=${data.redirect_uri}&state=${data.state || ""}&login_type=jssdk`;
  url += data.style ? `&style=${data.style}` : "";
  url += data.href ? `&href=${data.href}` : "";
  frame.src = url;
  frame.frameBorder = "0";
  frame.scrolling = "no";
  frame.width = "300px";
  frame.height = "400px";
  const el = document.getElementById(data.id);
  el!.innerHTML = "";
  el!.append(frame);

  frame.addEventListener("load", () => {
    if (frame.contentWindow?.postMessage && window.addEventListener) {
      window.addEventListener("message", (event) => {
        const hostArr = host.split(":");
        const [_host, _port] = hostArr;
        if (_port === "80") {
          host = _host;
        }
        if (event.data && event.origin.includes(host)) {
          window.location.href = event.data;
        }
      });
      frame.contentWindow.postMessage("ask_usePostMessage", "*");
    }
  });
}
