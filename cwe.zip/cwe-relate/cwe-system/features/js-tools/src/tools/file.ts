/**
 * @param url 下载地址
 * @param filename 文件名
 */
export const downloadFileByUrl = (url: string, filename: string) => {
  const a = document.createElement("a");
  a.style.display = "none";
  a.href = url;
  a.download = filename;
  a.rel = "noopener noreferrer";
  //  火狐兼容，防止多次下载只会下载第一个
  if (checkBrowser().browser === "firefox") {
    a.target = "_blank";
  }
  document.body.append(a);
  a.click();
  a.remove();
};

const checkBrowser = () => {
  const ua = navigator.userAgent.toLowerCase();
  const re = /(msie|firefox|chrome|opera|version).*?([\d.]+)/;
  const m = ua.match(re);
  const Sys = {
    browser: m?.[1].replace(/version/, "'safari"),
    version: m?.[2],
  };

  return Sys;
};
