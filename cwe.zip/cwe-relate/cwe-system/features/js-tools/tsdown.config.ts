import { defineConfig } from "tsdown";

export default defineConfig({
  dts: true,
  target: "es2022",
  logLevel: "warn",
  entry: {
    plugins: "./src/plugins/index.ts",
    tools: "./src/tools/index.ts",
  },
  platform: "neutral",
  unbundle: true,
});
