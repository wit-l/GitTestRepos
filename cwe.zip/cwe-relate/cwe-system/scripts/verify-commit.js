import { readFileSync } from "node:fs";
import path from "node:path";
import { styleText } from "node:util";

// source from: https://github.com/vuejs/core/blob/main/scripts/verify-commit.js
const msgPath = path.resolve(".git/COMMIT_EDITMSG");
const msg = readFileSync(msgPath, "utf-8").trim();

const commitRE =
  /^(revert: )?(feat|fix|docs|dx|style|refactor|perf|test|workflow|build|ci|chore|types|wip|release)(\(.+\))?: .{1,50}/;

if (!commitRE.test(msg)) {
  console.log();
  console.error(
    `  ${styleText(["white", "bgRed"], " ERROR ")} ${styleText("red", `invalid commit message format.`)}\n\n${styleText(
      "red",
      `  Error in commit message format. Examples:\n\n`,
    )}    ${styleText("green", `feat(compiler): add 'comments' option`)}\n` +
      `    ${styleText("green", `fix(button): handle events on blur`)}\n\n${styleText(
        "red",
        `  See https://www.conventionalcommits.org/zh-hans/v1.0.0/ for more details.\n`,
      )}`,
  );
  process.exit(1);
}
