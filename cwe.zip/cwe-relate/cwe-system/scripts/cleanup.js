import { readdirSync, rmSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const projectRootDir = fileURLToPath(new URL("..", import.meta.url));

// clean target folder
const delFile = new Set(["node_modules", ".turbo", "dist"]);

function delTargetDirectory(dir) {
  const entries = readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    if (!entry.isDirectory()) {
      continue;
    }

    const systemFilePath = join(dir, entry.name);
    if (delFile.has(entry.name)) {
      console.log(`[Deleting]: ${systemFilePath}`);
      rmSync(systemFilePath, { force: true, recursive: true });
    } else {
      // 递归检查项目子目录
      delTargetDirectory(systemFilePath);
    }
  }
}

try {
  delTargetDirectory(projectRootDir);
  console.log("[Done]: Clean complete!");
} catch (error) {
  console.error(error);
  process.exit(1);
}
