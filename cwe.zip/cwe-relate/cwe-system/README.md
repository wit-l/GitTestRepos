# 项目介绍

水电对外前端系统。计划包含所有的业务系统，以单仓库以提高系统业务代码的复用性

- 使用 [pnpm](https://pnpm.io) 管理依赖
- 使用 [pnpm workspace](https://pnpm.io/zh/workspaces)来作为 monorepo 多包管理
  - turbo 目前暂不支持 pnpm v11 的 `devEngines.packageManager`，见 [discussions](https://github.com/vercel/turborepo/discussions/10848)
- 使用 [turbo](https://turborepo.dev) 做多包的任务流程构建，与其类似还有 lerna、nx 等

什么是 monorepo ？ 自行搜索

**传统单仓库单项目的缺点：**

无法复用项目的业务封装。

在新建项目的同时，公用业务代码要重新迁移一份至新项目，同时还有项目所需的常用配置、核心依赖等。当公用业务变动时，所有关于此业务的项目都要重新更改，从而导致维护困难，甚至可能出现更改遗漏，造成多个项目之间虽然是同一个业务，但是处理逻辑不一致的情况

**monorepo 的设计架构可以很好的解决以上问题：**

所有公用模块以类似于 npm 包的方式分发给各业务项目使用，多个项目统一消费一个业务功能，目前主流的大型开源库都在采取此方式

在拥有 `pnpm-workspace.yaml` 的文件后，所有在**根目录**安装的依赖，都需要添加 `--workspace` 选项（简化为 `-w`），如：`pnpm add -w vue`

缺点就是大仓无法很好的控制每个项目的开发权限，需结合 Git 或者 Gitlab 的权限控制。

## 项目整体设计概览

此项目基本全量采用 vite 系列的工具链（vite、oxc、vitest 等等）以减少工具链割裂。

- [pnpm workspace](https://pnpm.io/zh/workspaces)：基于 pnpm workspace 管理 monorepo 项目
- [turbo](https://turborepo.dev)：自动生成依赖拓扑图，调度多个项目之间的依赖关系，dev build 等，调度缓存优化
- [oxlint oxfmt](https://oxc.rs)：基于 oxc 的 lint & format 工具
- [tsdown](https://tsdown.dev/zh-CN)：基于 oxc 的库打包工具
- [taze](https://github.com/antfu-collective/taze)：更方便管理 monorepo 项目的依赖更新

### 目录结构

```bash
.
├── apps
│   ├── site # 主网站
│   └── ...  # 部分业务较大的子系统（如市场平台）
├── feature # 与业务对接的封装 组件、方法等 （TODO）
│   ├── js-tools # 业务工具类
├── packages
│   ├── site-layout  # cwe 网站 ui 布局，仅供 apps 下的系统网站使用
│   ├── pro-components # 基于 antd 的复合组件
│   ├── tailwind-preset-antd # （由于其泛用性，已抽离成单独的 npm 包）
│   └── typescript-config # tsconfig 共享配置 json
└── ...
```

### 快速启动

在拥有 pnpm 的前提下，请使用 `corepack enable` 启用包管理器来确保项目的 `packageManager` 配置有效

- `pnpm dev` 启动项目
- `pnpm build` 构建项目
- `pnpm npm-check` 检查并升级可用依赖
- `pnpm check` 检查代码
- `pnpm fix` 检查并修复代码
- `pnpm typecheck` 运行 tsc 检查代码正确性
- `pnpm cleanup` 删除项目所有的 .turbo node_modules dist 文件

以上命令除 `cleanup` 外的任务执行都由 turbo 管理

使用 vscode 或者 zed 开发，已添加兼容性配置文件，但推荐使用 vscode，使用其它编辑器导致的不一致问题自行解决。

## 代码规范

当 vscode 添加 `oxc` 插件后，通常不需要关心格式问题，`oxc` 会自动格式化代码以确保整个项目的代码风格一致，lefthook 也会在代码提交前做 lint 检查

由于 `ultracite` 预设了大量的 oxc 规则，因此可能出现更多的 lint 错误，如果错误规则属于**常用或有必要忽略**的，请向根目录的 `oxlint.config.ts` 中添加忽略规则

### React 书写规范

1. 由于存在 [react-compiler](https://zh-hans.react.dev/learn/react-compiler) 来减轻开发过程中的心智负担，在业务代码中 **通常不需要再写 memo useMemo useCallback 等** 优化措施，且大部分优化都是属于负优化。
2. 适当使用 [useEffectEvent](https://zh-hans.react.dev/reference/react/useEffectEvent) 来避免函数闭包导致的 effect 副作用
3. 当一个业务页面的 effect 副作用超过两个的情况下，适当将业务抽离成 hook 以减少主文件的复杂度
4. 更多 react 规则请查看 [eslint-plugin-react-hooks](https://zh-hans.react.dev/reference/eslint-plugin-react-hooks)
5. 当使用 `tailwindcss` 时，如果样式过于复杂，请使用 `css module` 方案，或使用 `cn` 函数将样式进行分类（css 段落）增加其可读性。类似于：`cn("text-red-500 bg-white"/色彩类/, "flex absolute"/布局类/)`。严禁将大量 class 类名聚合在一个行内标签中，这将会造成极差的可读性和维护效率

更多本项目的 React 规范请查看 [site](./apps/site/README.md)

### 文件（路由）命名规范

tanstack router 的文件即路由，由于写法众多，因此在此对路由命名及格式进行规范：

1. 所有经系统认证的路由文件（白名单路由除外），必须以文件夹命名，index.tsx 为入口文件。例如 `sys.tsx` -> `sys/index.tsx`
2. 所有路由文件名以 `Kebab Case` 单词间用 `-` 分隔符，不推荐使用驼峰命名
3. 路由名称在每个单词较长的情况下，最多不超过 3 个单词。每个单词较短或很短的情况下，最多不超过 4 个单词，尽量保持在 2-3 个单词。

## 注意事项

### React 项目开发注意

1. 确保关闭 react `StrictMode` 以避免 antd 组件的一些异常行为。

原因：

- 严格模式下 Form `preserve=false` 时 Form.List 的赋值会被忽略。相关来源如下：
  - [Default value for List's add operation deleted when strictmode and preserve is false](https://github.com/ant-design/ant-design/issues/49694)
  - [StrictMode 下 preserve=false，使用动态节点时添加的值无法保存](https://github.com/react-component/field-form/issues/705)

2. 更简单处理 antd Modal 弹出时的 setFieldsValue 警告

常见的业务场景下，触发 `openModal` 函数，函数内部使用 `setFieldsValue` 对 Modal 中的 Form 进行赋值，虽然结果正确，但是在开发环境下会出现警告：Warning: Instance created by `useForm` is not connected to any Form element. Forget to pass `form` prop?

关于此警告，详细的讨论及解决方案见 [issues](https://github.com/ant-design/ant-design/issues/21543)

基于 issue 中有提到延迟 setFieldsValue，因此可以使用 `Promise.resolve.then` 来实现，而在现代浏览器中，可使用 `queueMicrotask` 来替代 Promise 微任务。

```tsx
const [form] = Form.useForm();

function openModal(record) {
  // from.setFieldsValue({ ...record });  // Warning: Instance created by `useForm` ...
  // 👇
  queueMicrotask(() => {
    from.setFieldsValue({ ...record });
  });
}
```

### 关于内部包是否在运行时编译问题

见 [internal-packages](https://turborepo.dev/docs/core-concepts/internal-packages)

折中选择是：dev 时引用源码，build 时引用 dist 产物，如果出现开发和构建环境不一致的情况，请统一使用 dist 产物。
