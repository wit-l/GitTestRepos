import { defineConfig } from "oxfmt";
// import ultracite from "ultracite/oxfmt";

export default defineConfig({
  // extends: [ultracite],
  printWidth: 120,
  arrowParens: "always",
  bracketSameLine: false,
  bracketSpacing: true,
  endOfLine: "lf",
  jsxSingleQuote: false,
  quoteProps: "as-needed",
  semi: true,
  singleQuote: false,
  sortImports: {
    ignoreCase: true,
    newlinesBetween: true,
    order: "asc",
  },
  sortPackageJson: true,
  tabWidth: 2,
  trailingComma: "es5",
  useTabs: false,
  sortTailwindcss: true,
  ignorePatterns: ["**/dist", "**/storybook-static", "**/.turbo", "**/package-lock.json", "**/routeTree.gen.ts"],
});
