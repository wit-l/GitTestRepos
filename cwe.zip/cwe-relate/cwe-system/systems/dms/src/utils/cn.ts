import { clsx } from "clsx";
import type { ClassValue } from "clsx";
import { extendTailwindMerge } from "tailwind-merge";
import { colorPresets } from "tailwind-preset-antd/preset";

// https://github.com/tailwindlabs/tailwindcss/discussions/19260
// 自定义的 fontSize 和 color 同时使用 text-* 时，会被 tw-merge 识别为同一种类型而丢失，
// 即 text-fontSizeSM 会被识别成 color，而当同时和自定义颜色一起使用时，tw-merge 会只保留顺序后者的类名
// 此问题详见： layouts/page-header/search-menu/index.tsx 中的 text-colorTextSecondary text-fontSizeSM
const twMerge = extendTailwindMerge({
  prefix: "a",
  extend: {
    theme: {
      // text: [...addPrefixFontSizes], // v3
      // v2 没有 text 属性，只能显式声明 color
      colors: [...colorPresets], // v2
    },
  },
});

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
