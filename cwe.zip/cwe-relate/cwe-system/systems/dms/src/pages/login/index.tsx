import { ProForm, ProFormInput } from "@cwe/pro-components";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useRequest } from "ahooks";
import { App, Button, Form, Input, Space } from "antd";
import { md5 } from "js-md5";
import { nanoid } from "nanoid";
import { useRef, useState } from "react";
import z from "zod/v4";

import { RequestEnum } from "@/config/enum";
import { clientEnv } from "@/config/env";
import { getCaptcha, getCurrentUserInfo, getUserRolesWithMenus, login } from "@/services/apis/login";
import type { ILoginData } from "@/services/apis/login/type";
import { useUserAuthSelector } from "@/store";

export const Route = createFileRoute("/login/")({
  component: RouteComponent,
  validateSearch: z.object({
    redirect: z.string().optional(),
  }),
});

function RouteComponent() {
  const navigate = useNavigate();
  const { redirect } = Route.useSearch();

  const imgRef = useRef<HTMLImageElement>(null);
  const { setUserInfo } = useUserAuthSelector(["setUserInfo"]);

  const { run: refetchCaptcha } = useRequest(() => getCaptcha(nanoid(5)), {
    onSuccess: (data) => {
      if (imgRef.current) {
        imgRef.current.src = URL.createObjectURL(data);
      }
    },
  });

  const { message } = App.useApp();
  async function handleSubmit(values: ILoginData) {
    try {
      const loginResult = await login({
        ...values,
        password: md5(values.password),
        state: "5e9288f19dc0da3d7d179e7469000cc7",
      });

      // 登陆失败
      if (!loginResult.success) {
        refetchCaptcha();
        return;
      }

      sessionStorage.setItem(RequestEnum.TOKEN_CACHE, loginResult.data);
    } catch {
      refetchCaptcha();
      return;
    }

    const userInfoResult = await getCurrentUserInfo();
    // 用户信息获取失败
    if (!userInfoResult.success) {
      return;
    }

    const roleWithMenusResult = await getUserRolesWithMenus();
    // 用户无权限
    if (roleWithMenusResult.success && roleWithMenusResult.data.menus.length === 0) {
      navigate({ to: "/un-roles", replace: true });
      return;
    }

    const { data: userInfo } = userInfoResult;
    userInfo.menus = roleWithMenusResult.data.menus;
    userInfo.roles = roleWithMenusResult.data.roles;
    setUserInfo(userInfo);
    message.success("登录成功");
    navigate({ to: redirect || clientEnv.BASE_URL, replace: true });
  }

  const [loading, setLoading] = useState(false);

  return (
    <div className="flex h-full w-full items-center justify-center">
      <ProForm
        className="w-full sm:w-80"
        size="large"
        onFinish={handleSubmit}
        onLoadingChange={setLoading}
        submitter={{
          render: () => (
            <Button type="primary" htmlType="submit" block loading={loading}>
              登录
            </Button>
          ),
        }}
      >
        <ProFormInput
          name="userName"
          rules={[{ required: true, message: "请输入用户名" }]}
          placeholder="请输入用户名"
        />
        <ProFormInput.Password
          name="password"
          rules={[{ required: true, message: "请输入密码" }]}
          placeholder="请输入密码"
        />
        <Form.Item name="code" rules={[{ required: true, message: "请输入验证码" }]}>
          <Space align="center" size="large">
            <Input placeholder="请输入验证码" />
            <button
              onClick={refetchCaptcha}
              type="button"
              className="m-0 h-10 cursor-pointer overflow-hidden rounded-a-borderRadiusLG border-none bg-transparent p-0"
            >
              <img draggable={false} ref={imgRef} alt="验证码" />
            </button>
          </Space>
        </Form.Item>
      </ProForm>
    </div>
  );
}
