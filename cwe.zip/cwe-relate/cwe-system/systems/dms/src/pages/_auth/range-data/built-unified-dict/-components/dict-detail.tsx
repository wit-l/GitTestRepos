import { LeftOutlined } from "@ant-design/icons";
import { ModalForm, ProFormInput, ProFormSelect, ProTable, type ProColumnsType } from "@cwe/pro-components";
import { useRequest } from "ahooks";
import { App, Button, Descriptions, Form, Table } from "antd";
import { useState } from "react";

import { useAccess } from "@/hooks/useAccess";
import {
  addBuiltDictDetailRecord,
  getBuiltDictDetailRecord,
  getBuiltDictDetailTree,
  updateBuiltDictDetailRecord,
} from "@/services/apis/range-data/built-dict";
import type {
  IBuiltDictDetailRecord,
  IBuiltDictDetailTree,
  IBuiltDictType,
} from "@/services/apis/range-data/built-dict/type";

const dictStateEnum: Record<string, string> = {
  1: "启用",
  0: "禁用",
} as const;
const delStateEnum: Record<string, string> = {
  1: "未删除",
  0: "已删除",
} as const;

interface DictDetailProps {
  dictTypeData: IBuiltDictType;
  onBack: () => void;
}

export default function DictDetail(props: DictDetailProps) {
  const { dictTypeData, onBack } = props;
  const { message } = App.useApp();
  const [modalForm] = Form.useForm<IBuiltDictDetailRecord>();

  // ==================== Modal ====================
  const [modalOpen, setModalOpen] = useState(false);
  const [detailRecord, setDetailRecord] = useState<IBuiltDictDetailRecord>();

  const { loading: modalLoading, runAsync: fetchDetailRecord } = useRequest(getBuiltDictDetailRecord, {
    manual: true,
  });
  async function onOpenModal(record: IBuiltDictDetailTree) {
    setModalOpen(true);

    const { data } = await fetchDetailRecord(record.dataId);
    setDetailRecord(data);
    modalForm.setFieldsValue({ ...data });
  }

  async function handleSubmit(values: IBuiltDictDetailRecord) {
    if (detailRecord?.id) {
      await updateBuiltDictDetailRecord(values);
    } else {
      await addBuiltDictDetailRecord(values);
    }
    message.success("操作成功");
    return true;
  }

  const columns: ProColumnsType<IBuiltDictDetailTree>[] = [
    {
      title: "域值编码",
      dataIndex: "id",
    },
    {
      title: "域值名称",
      dataIndex: "name",
      renderSearchFormItem: () => <ProFormInput />,
    },
    {
      title: "备注",
      dataIndex: "SNO",
    },
    {
      title: "状态",
      dataIndex: "ZSTATE",
      render: (value) => dictStateEnum[value],
      renderSearchFormItem: () => <ProFormSelect allowClear valueEnum={dictStateEnum} />,
    },
    {
      title: "是否删除",
      dataIndex: "ZDELETE",
      render: (value) => delStateEnum[value],
    },
    {
      title: "操作",
      dataIndex: "operation",
      render: (_, record) => (
        <a className="text-a-colorPrimary" onClick={() => onOpenModal(record)}>
          查看
        </a>
      ),
    },
  ];

  const canEditPermission = useAccess("/basic-master-data/general-dictionary-classification/detail");

  return (
    <>
      <div className="mb-a-marginSM flex items-center gap-a-marginXS">
        <Button type="text" icon={<LeftOutlined />} onClick={onBack} />
        <div className="text-a-fontSizeLG font-semibold">{dictTypeData?.zname}</div>
      </div>

      <ProTable<IBuiltDictDetailTree, { ZSTATE?: string; name?: string }>
        rowKey="id"
        columns={columns}
        request={async (params) => {
          const result = await getBuiltDictDetailTree({
            conditions: [
              { column: "zdomCode", value: dictTypeData?.zcode, type: "EQ" },
              { column: "zdomName", value: params?.name, type: "LIKE" },
              { column: "zstate", value: params?.ZSTATE, type: "EQ" },
            ],
          });
          return {
            data: result.data,
            total: result.data?.length,
          };
        }}
      />

      <ModalForm
        width="60%"
        title="操作"
        open={modalOpen}
        onOpenChange={setModalOpen}
        onFinish={handleSubmit}
        form={modalForm}
        layout="vertical"
        modalProps={{
          loading: modalLoading,
          footer: canEditPermission ? undefined : null,
        }}
      >
        <div className="mb-a-marginSM text-a-fontSizeLG font-semibold">基本信息</div>
        <Descriptions
          layout="vertical"
          items={[
            { label: "发送记录ID", children: detailRecord?.ZZSERIAL },
            { label: "分类编码", children: detailRecord?.ZDOM_CODE },
            { label: "分类名称", children: detailRecord?.ZDOM_DESC },
            { label: "域值编码", children: detailRecord?.ZDOM_VALUE },
            { label: "域值描述", children: detailRecord?.ZDOM_NAME },
            { label: "备注", children: detailRecord?.ZREMARKS },
            { label: "上级域值编码", children: detailRecord?.ZDOM_SUP },
            { label: "域值层级", children: detailRecord?.ZDOM_LEVEL },
            { label: "修改时间", children: detailRecord?.ZCHTIME },
            { label: "版本", children: detailRecord?.ZVERSION },
            { label: "状态", children: dictStateEnum[detailRecord?.ZSTATE as string] },
            { label: "是否删除", children: delStateEnum[detailRecord?.ZDELETE as string] },
          ]}
        />

        <div className="my-a-marginSM text-a-fontSizeLG font-semibold">多语言描述</div>
        <Table
          rowKey="key"
          dataSource={detailRecord?.ZSELFLANG_LIST?.item}
          size="small"
          pagination={false}
          columns={[
            { title: "语种代码", dataIndex: "ZLANGCODE" },
            { title: "语种描述", dataIndex: "ZCODE_DESC" },
          ]}
        />

        {/* 这里和后端的返回类型保持一致，不再做二次处理 */}
        <Form.List name={["ZSELFLANG_LIST", "item"]}>
          {(fields, { add, remove }) => (
            <>
              <div className="my-a-marginSM flex justify-between">
                <span className="text-a-fontSizeLG font-semibold">自建多语言描述</span>
                <Button type="primary" onClick={() => add()}>
                  新增一条
                </Button>
              </div>
              <Table
                rowKey="key"
                dataSource={fields}
                size="small"
                pagination={false}
                columns={[
                  {
                    title: "语种代码",
                    width: "40%",
                    render: (_, field) => (
                      <ProFormSelect
                        className="mb-0"
                        name={[field.name, "ZLANGCODE"]}
                        valueEnum={{ chi: "汉语(chi)", fre: "法语(fre)", eng: "英语(eng)", spa: "西班牙语(spa)" }}
                      />
                    ),
                  },
                  {
                    title: "语种描述",
                    width: "50%",
                    render: (_, field) => <ProFormInput name={[field.name, "ZVALUE_DESC"]} className="mb-0" />,
                  },
                  {
                    title: "操作",
                    width: "10%",
                    render: (_, field) => (
                      <a className="text-a-colorError" onClick={() => remove(field.name)}>
                        删除
                      </a>
                    ),
                  },
                ]}
              />
            </>
          )}
        </Form.List>
      </ModalForm>
    </>
  );
}
