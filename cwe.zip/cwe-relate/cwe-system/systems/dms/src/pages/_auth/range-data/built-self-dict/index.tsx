import {
  ModalForm,
  ProFormInput,
  ProFormSelect,
  ProTable,
  type ProColumnsType,
  type ProTableActionType,
} from "@cwe/pro-components";
import { createFileRoute } from "@tanstack/react-router";
import { useRequest } from "ahooks";
import { App, Button, Form, Popconfirm, Space } from "antd";
import { useRef, useState } from "react";
import { Activity } from "react";

import Access from "@/components/access";
import {
  addBuiltDictTypeRecord,
  delBuiltDictTypeRecord,
  getBuiltDictDetailTree,
  getBuiltDictTypeList,
  updateBuiltDictTypeRecord,
} from "@/services/apis/range-data/built-dict";
import type { IBuiltDictDetailTree, IBuiltDictType } from "@/services/apis/range-data/built-dict/type";

import DictDetail from "./-components/dict-detail";

export const Route = createFileRoute("/_auth/range-data/built-self-dict/")({
  component: RouteComponent,
});

function RouteComponent() {
  const { message } = App.useApp();
  const [searchForm] = Form.useForm();
  const actionRef = useRef<ProTableActionType>(null);

  const [dictTree, setDictTree] = useState<IBuiltDictDetailTree[]>([]);

  // ==================== Delete ====================
  const { run: delDictRecord } = useRequest(delDictRecordFn, { manual: true });
  async function delDictRecordFn(id: string) {
    await delBuiltDictTypeRecord(id);
    message.success("操作成功");
    actionRef.current?.reload();
  }

  // ==================== Modal ====================
  const [modalOpen, setModalOpen] = useState(false);
  const [editRecord, setEditRecord] = useState<IBuiltDictType>();

  function onOpenModal(record?: IBuiltDictType) {
    setModalOpen(true);
    setEditRecord(record);
  }

  async function onSubmitModal(values: IBuiltDictType) {
    if (editRecord?.id) {
      await updateBuiltDictTypeRecord({ ...editRecord, ...values });
    } else {
      await addBuiltDictTypeRecord(values);
    }
    message.success("操作成功");
    actionRef.current?.reload();
    return true;
  }

  // ==================== Detail view ====================
  const [dictTypeRecord, seDictTypeRecord] = useState<IBuiltDictType>();

  // ==================== Columns ====================
  const columns: ProColumnsType<IBuiltDictType>[] = [
    {
      title: "名称",
      dataIndex: "zname",
      renderSearchFormItem: () => <ProFormInput name="name" placeholder="请输入" />,
      render: (value, record) => <a onClick={() => seDictTypeRecord(record)}>{value}</a>,
    },
    {
      title: "编码",
      dataIndex: "zcode",
    },
    {
      title: "分类",
      dataIndex: "classify",
      render: (value) => dictTree.find((item) => item.id === value)?.name,
      renderSearchFormItem: () => (
        <ProFormSelect
          name="classify"
          fieldNames={{ label: "name", value: "id" }}
          request={async () => {
            const result = await getBuiltDictDetailTree({
              conditions: [
                { column: "zdomCode", value: "self", type: "EQ" },
                { column: "zstate", value: 1, type: "EQ" },
              ],
            });
            searchForm.setFieldValue("classify", result.data[0].id);
            setDictTree(result.data);
            return result.data;
          }}
          allowClear
          placeholder="请选择"
        />
      ),
    },
    {
      title: "排序号",
      dataIndex: "sno",
    },
    {
      title: "操作",
      dataIndex: "operation",
      render: (_, record) => (
        <Space>
          <a className="text-a-colorPrimary" onClick={() => onOpenModal(record)}>
            编辑
          </a>
          <Popconfirm
            title="删除提示"
            description="此操作将永久删除, 是否继续?"
            onConfirm={() => delDictRecord(record.id)}
          >
            <a className="text-a-colorError">删除</a>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <>
      {dictTypeRecord && <DictDetail dictTypeData={dictTypeRecord} onBack={() => seDictTypeRecord(undefined)} />}

      <Activity mode={dictTypeRecord ? "hidden" : "visible"}>
        <ProTable<IBuiltDictType, { classify?: string; name?: string }>
          actionRef={actionRef}
          form={searchForm}
          columns={columns}
          ready={!!dictTree[0]?.id}
          request={async (params) => {
            if (!dictTree[0]?.id) return { data: [], total: 0 };
            const result = await getBuiltDictTypeList({
              name: params.name,
              classify: params.classify || dictTree[0].id,
              ztype: "self",
            });

            return { data: result.data, total: result.data?.length };
          }}
          toolbar={{
            action: () => [
              <Access key="add" permission="/basic-master-data/general-dictionary-classification/add">
                <Button type="primary" onClick={() => onOpenModal()}>
                  新增
                </Button>
              </Access>,
            ],
          }}
          rowKey="id"
          size="medium"
        />
      </Activity>

      <ModalForm
        title="操作"
        labelCol={{ span: 5 }}
        open={modalOpen}
        onOpenChange={setModalOpen}
        onFinish={onSubmitModal}
        initialValues={{ classify: searchForm.getFieldValue("classify"), ...editRecord }}
      >
        <ProFormSelect
          name="classify"
          label="字典分类"
          options={dictTree}
          fieldNames={{ label: "name", value: "id" }}
          rules={[{ required: true, message: "请选择" }]}
        />
        <ProFormInput name="sno" label="排序号" rules={[{ required: true, message: "请输入" }]} />
        <ProFormInput name="zname" label="名称" rules={[{ required: true, message: "请输入" }]} />
        <ProFormInput name="zcode" label="编码" rules={[{ required: true, message: "请输入" }]} />
      </ModalForm>
    </>
  );
}
