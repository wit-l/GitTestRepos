import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/4a-master-data")({
  beforeLoad(ctx) {
    if (ctx.location.pathname !== "/4a-master-data") {
      return;
    }

    throw redirect({ to: "/4a-master-data/institution-manage" });
  },
});
