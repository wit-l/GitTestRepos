import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/api-market/master-data/biz-master-data-api/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/api-market/master-data/biz-master-data-api/"!</div>;
}
