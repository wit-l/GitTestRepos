import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/range-data")({
  beforeLoad(ctx) {
    if (ctx.location.pathname !== "/range-data") {
      return;
    }

    throw redirect({ to: "/range-data/built-self-dict" });
  },
});
