import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/4a-master-data/institution-manage/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/4a-master-data/institution-manage/"!</div>;
}
