import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/basic-master-data/continent/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/basic-master-data/continent/"!</div>;
}
