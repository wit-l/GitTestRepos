import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/basic-master-data/language-type/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/basic-master-data/language-type/"!</div>;
}
