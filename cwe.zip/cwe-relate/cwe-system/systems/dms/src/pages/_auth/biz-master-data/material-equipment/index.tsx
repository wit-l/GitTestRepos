import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/biz-master-data/material-equipment/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/biz-master-data/material-equipment/"!</div>;
}
