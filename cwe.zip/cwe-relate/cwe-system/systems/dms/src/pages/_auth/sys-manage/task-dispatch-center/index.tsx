import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/sys-manage/task-dispatch-center/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/sys-manage/task-dispatch-center/"!</div>;
}
