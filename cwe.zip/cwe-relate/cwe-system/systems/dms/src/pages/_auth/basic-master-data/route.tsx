import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/basic-master-data")({
  beforeLoad(ctx) {
    if (ctx.location.pathname !== "/basic-master-data") {
      return;
    }

    throw redirect({ to: "/basic-master-data/country-region" });
  },
});
