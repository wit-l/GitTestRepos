import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/biz-master-data/counterparty-unit/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/biz-master-data/counterparty-unit/"!</div>;
}
