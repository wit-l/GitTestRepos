import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/sys-manage")({
  beforeLoad(ctx) {
    if (ctx.location.pathname !== "/sys-manage") {
      return;
    }

    throw redirect({ to: "/sys-manage/menus" });
  },
});
