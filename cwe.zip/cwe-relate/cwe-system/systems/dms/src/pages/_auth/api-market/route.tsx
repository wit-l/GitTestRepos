import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/api-market")({
  beforeLoad(ctx) {
    if (ctx.location.pathname !== "/api-market") {
      return;
    }

    throw redirect({ to: "/api-market/master-data/range-data-api" });
  },
});
