import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/docking-register-manage/app-register-config/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/docking-register-manage/app-register-config/"!</div>;
}
