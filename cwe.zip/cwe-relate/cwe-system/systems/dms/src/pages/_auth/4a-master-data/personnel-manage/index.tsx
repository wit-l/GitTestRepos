import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/4a-master-data/personnel-manage/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/4a-master-data/personnel-manage/"!</div>;
}
