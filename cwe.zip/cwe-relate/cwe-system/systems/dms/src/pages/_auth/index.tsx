import { createFileRoute } from "@tanstack/react-router";
import { Card, Col, Row, Table } from "antd";

import type { ICallbackFailApi, ICommonApiDaysTop, IMostTimesApiTop } from "@/services/apis/home/type";

export const Route = createFileRoute("/_auth/")({
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <Row gutter={[12, 12]}>
      <Col span={12}>
        <Card title="近15天访问次数趋势">
          <div></div>
        </Card>
      </Col>
      <Col span={12}>
        <Card title="近24小时访问统计">
          <div></div>
        </Card>
      </Col>
      <Col span={12}>
        <Card title="近15天常用接口排行TOP10">
          <Table<ICommonApiDaysTop>
            columns={[
              { title: "接口分类", dataIndex: "action" },
              { title: "接口名称", dataIndex: "describe" },
              { title: "请求次数", dataIndex: "requestNum" },
              { title: "平均时长(ms)", dataIndex: "avgTime" },
              { title: "成功率", dataIndex: "successRate" },
            ]}
            size="medium"
            pagination={false}
          />
        </Card>
      </Col>
      <Col span={12}>
        <Card title="近15天最耗时接口排行TOP10">
          <Table<IMostTimesApiTop>
            columns={[
              { title: "接口分类", dataIndex: "action" },
              { title: "接口名称", dataIndex: "describe" },
              { title: "请求次数", dataIndex: "requestNum" },
              { title: "平均时长(ms)", dataIndex: "avgTime" },
              { title: "成功率", dataIndex: "successRate" },
            ]}
            size="medium"
            pagination={false}
          />
        </Card>
      </Col>
      <Col span={24}>
        <Card title="15日内调用失败接口列表">
          <Table<ICallbackFailApi>
            columns={[
              { title: "接口分类", dataIndex: "action" },
              { title: "接口名称", dataIndex: "describe" },
              { title: "接口url", dataIndex: "api" },
              { title: "请求方式", dataIndex: "method" },
              { title: "请求参数", dataIndex: "paramJson" },
              { title: "请求时间", dataIndex: "startTime" },
              { title: "耗时(ms)", dataIndex: "timeConsuming" },
              { title: "Client ID", dataIndex: "clientId" },
              { title: "ip", dataIndex: "ip" },
              { title: "错误信息", dataIndex: "errorMsg" },
            ]}
            size="medium"
          />
        </Card>
      </Col>
    </Row>
  );
}
