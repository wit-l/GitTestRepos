import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/roles-manage")({
  beforeLoad(ctx) {
    if (ctx.location.pathname !== "/roles-manage") {
      return;
    }

    throw redirect({ to: "/roles-manage/post" });
  },
});
