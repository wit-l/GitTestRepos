import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/api-market/process-platform/integration-api/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/api-market/process-platform/integration-api/"!</div>;
}
