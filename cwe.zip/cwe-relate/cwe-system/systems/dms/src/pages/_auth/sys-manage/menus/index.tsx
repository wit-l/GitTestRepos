import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/sys-manage/menus/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/sys-manage/menus/"!</div>;
}
