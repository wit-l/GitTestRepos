import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/range-data/dict-maintain/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/range-data/dict-maintain/"!</div>;
}
