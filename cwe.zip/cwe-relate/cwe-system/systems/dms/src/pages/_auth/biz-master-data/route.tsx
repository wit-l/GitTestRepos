import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/biz-master-data")({
  beforeLoad(ctx) {
    if (ctx.location.pathname !== "/biz-master-data") {
      return;
    }

    throw redirect({ to: "/biz-master-data/equipment-category" });
  },
});
