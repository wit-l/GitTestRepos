import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/4a-master-data/sync-log/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/4a-master-data/sync-log/"!</div>;
}
