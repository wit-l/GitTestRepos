import { ProFormInput, ProFormSelect, ProTable, type ProColumnsType } from "@cwe/pro-components";
import { createFileRoute } from "@tanstack/react-router";
import { Form } from "antd";
import { useState } from "react";
import { Activity } from "react";

import { getBuiltDictDetailTree, getBuiltDictTypeList } from "@/services/apis/range-data/built-dict";
import type { IBuiltDictDetailTree, IBuiltDictType } from "@/services/apis/range-data/built-dict/type";

import DictDetail from "./-components/dict-detail";

export const Route = createFileRoute("/_auth/range-data/built-unified-dict/")({
  component: RouteComponent,
});

function RouteComponent() {
  const [searchForm] = Form.useForm();
  const [dictTree, setDictTree] = useState<IBuiltDictDetailTree[]>([]);

  // ==================== Detail view ====================
  const [dictTypeRecord, seDictTypeRecord] = useState<IBuiltDictType>();

  // ==================== Columns ====================
  const columns: ProColumnsType<IBuiltDictType>[] = [
    {
      title: "名称",
      dataIndex: "zname",
      renderSearchFormItem: () => <ProFormInput name="name" />,
      render: (value, record) => <a onClick={() => seDictTypeRecord(record)}>{value}</a>,
    },
    {
      title: "编码",
      dataIndex: "zcode",
    },
    {
      title: "分类",
      dataIndex: "classify",
      render: (value) => dictTree.find((item) => item.id === value)?.name,
      renderSearchFormItem: () => (
        <ProFormSelect
          allowClear
          fieldNames={{ label: "name", value: "id" }}
          request={async () => {
            const result = await getBuiltDictDetailTree({
              conditions: [
                { column: "zdomCode", value: "unify", type: "EQ" },
                { column: "zstate", value: 1, type: "EQ" },
              ],
            });
            searchForm.setFieldValue("classify", result.data[0].id);
            setDictTree(result.data);
            return result.data;
          }}
        />
      ),
    },
    { title: "排序号", dataIndex: "sno" },
  ];

  return (
    <>
      {dictTypeRecord && <DictDetail dictTypeData={dictTypeRecord} onBack={() => seDictTypeRecord(undefined)} />}

      <Activity mode={dictTypeRecord ? "hidden" : "visible"}>
        <ProTable<IBuiltDictType, { classify?: string; name?: string }>
          form={searchForm}
          columns={columns}
          rowKey="id"
          ready={!!dictTree[0]?.id}
          request={async (params) => {
            const result = await getBuiltDictTypeList({
              name: params.name,
              classify: params.classify || dictTree[0].id,
              ztype: "unify",
            });
            return { data: result.data, total: result.data?.length };
          }}
        />
      </Activity>
    </>
  );
}
