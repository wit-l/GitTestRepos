import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/docking-register-manage")({
  beforeLoad(ctx) {
    if (ctx.location.pathname !== "/docking-register-manage") {
      return;
    }

    throw redirect({ to: "/docking-register-manage/app-register-config" });
  },
});
