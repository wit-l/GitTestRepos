import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/api-market/master-data/biz-master-data-sync-spec/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/api-market/master-data/biz-master-data-sync-spec/"!</div>;
}
