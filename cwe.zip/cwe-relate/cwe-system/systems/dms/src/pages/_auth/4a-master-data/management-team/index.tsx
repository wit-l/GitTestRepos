import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/4a-master-data/management-team/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/4a-master-data/management-team/"!</div>;
}
