import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/roles-manage/roles/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/roles-manage/roles/"!</div>;
}
