import { LeftOutlined } from "@ant-design/icons";
import { downloadFileByUrl } from "@cwe/js-tools/tools";
import {
  ModalForm,
  ProFormInput,
  ProFormRadio,
  ProFormSelect,
  ProTable,
  type ProColumnsType,
} from "@cwe/pro-components";
import { useRequest } from "ahooks";
import { App, Button, Col, Form, Popconfirm, Space, Table, Upload } from "antd";
import type { RcFile } from "antd/es/upload";
import { useState } from "react";

import Access from "@/components/access";
import { useAccess } from "@/hooks/useAccess";
import {
  addBuiltDictDetailRecord,
  delBuiltDictDetailRecord,
  getBuiltDictDetailRecord,
  getBuiltDictDetailTree,
  importBuiltDictDetailExcel,
  updateBuiltDictDetailRecord,
} from "@/services/apis/range-data/built-dict";
import type {
  IBuiltDictDetailRecord,
  IBuiltDictDetailTree,
  IBuiltDictType,
} from "@/services/apis/range-data/built-dict/type";

const dictStateEnum: Record<string, string> = {
  1: "启用",
  0: "禁用",
} as const;
const delStateEnum: Record<string, string> = {
  1: "未删除",
  0: "已删除",
} as const;

interface DictDetailProps {
  dictTypeData: IBuiltDictType;
  onBack: () => void;
}

export default function DictDetail(props: DictDetailProps) {
  const { dictTypeData, onBack } = props;
  const { message } = App.useApp();
  const [modalForm] = Form.useForm<IBuiltDictDetailRecord>();

  const { run: onDelDetailRecord } = useRequest(delBuiltDictDetailRecord, {
    manual: true,
    onSuccess: () => message.success("操作成功"),
  });

  // ==================== Modal ====================
  const [modalOpen, setModalOpen] = useState(false);
  const [detailRecord, setDetailRecord] = useState<IBuiltDictDetailRecord>();

  const { loading: modalLoading, runAsync: fetchDetailRecord } = useRequest(getBuiltDictDetailRecord, {
    manual: true,
  });
  async function onOpenModal(record?: IBuiltDictDetailTree, isEditMode?: boolean) {
    setModalOpen(true);

    queueMicrotask(() => {
      modalForm.setFieldValue("ZDOM_SUP", record?.id);
    });

    if (isEditMode && record) {
      const { data } = await fetchDetailRecord(record.dataId);
      setDetailRecord(data);
      modalForm.setFieldsValue({ ...data });
    } else {
      setDetailRecord(undefined);
    }
  }

  async function handleSubmit(values: IBuiltDictDetailRecord) {
    if (detailRecord?.id) {
      await updateBuiltDictDetailRecord(values);
    } else {
      await addBuiltDictDetailRecord(values);
    }
    message.success("操作成功");
    return true;
  }

  async function importExcel(file: RcFile) {
    const formData = new FormData();
    formData.append("file", file);
    await importBuiltDictDetailExcel(formData);
    message.success("导入成功");
    return false;
  }

  const columns: ProColumnsType<IBuiltDictDetailTree>[] = [
    { title: "域值编码", dataIndex: "id" },
    { title: "域值名称", dataIndex: "name", renderSearchFormItem: () => <ProFormInput /> },
    { title: "排序号", dataIndex: "SNO" },
    {
      title: "状态",
      dataIndex: "ZSTATE",
      render: (value) => dictStateEnum[value],
      renderSearchFormItem: () => <ProFormSelect allowClear valueEnum={dictStateEnum} />,
    },
    { title: "是否删除", dataIndex: "ZDELETE", render: (value) => delStateEnum[value] },
    {
      title: "操作",
      dataIndex: "operation",
      render: (_, record) => (
        <Space size="large">
          <a className="text-a-colorPrimary" onClick={() => onOpenModal(record, true)}>
            查看
          </a>
          <Access permission="/basic-master-data/general-dictionary-classification/detail">
            <a className="text-a-colorPrimary" onClick={() => onOpenModal(record)}>
              新增
            </a>
          </Access>

          <Access permission="/basic-master-data/general-dictionary-classification/delete">
            <Popconfirm
              title="删除提示"
              description="此操作将永久删除, 是否继续?"
              onConfirm={() => onDelDetailRecord(record.dataId)}
            >
              <a className="text-a-colorError">删除</a>
            </Popconfirm>
          </Access>
        </Space>
      ),
    },
  ];

  const canEditPermission = useAccess("/basic-master-data/general-dictionary-classification/detail");

  return (
    <>
      <div className="mb-a-marginSM flex items-center gap-a-marginXS">
        <Button type="text" icon={<LeftOutlined />} onClick={onBack} />
        <div className="text-a-fontSizeLG font-semibold">{dictTypeData?.zname}</div>
      </div>

      <ProTable<IBuiltDictDetailTree, { ZSTATE?: string; name?: string }>
        rowKey="id"
        columns={columns}
        request={async (params) => {
          const result = await getBuiltDictDetailTree({
            conditions: [
              { column: "zdomCode", value: dictTypeData?.zcode, type: "EQ" },
              { column: "zdomName", value: params?.name, type: "LIKE" },
              { column: "zstate", value: params?.ZSTATE, type: "EQ" },
            ],
          });

          return {
            data: result.data,
            total: result.data?.length,
          };
        }}
        toolbar={{
          action: () => [
            <Access key="add" permission="/basic-master-data/general-dictionary-classification/add">
              <Button type="primary" onClick={() => onOpenModal()}>
                新增明细
              </Button>
            </Access>,
            <Access key="download" permission="/range-data/built-self-dict/download">
              <Button type="primary" onClick={() => downloadFileByUrl("/dictionary.xlsx", "字典项收集表.xlsx")}>
                下载模板
              </Button>
            </Access>,
            <Access key="import" permission="/range-data/built-self-dict/upload">
              <Upload showUploadList={false} beforeUpload={importExcel}>
                <Button type="primary">导入</Button>
              </Upload>
            </Access>,
          ],
        }}
      />

      <ModalForm
        width="60%"
        title="操作"
        open={modalOpen}
        grid
        rowProps={{ gutter: 12 }}
        colProps={{ span: 8 }}
        onOpenChange={setModalOpen}
        onFinish={handleSubmit}
        initialValues={{
          ZDOM_CODE: dictTypeData.zcode,
          ZDOM_DESC: dictTypeData.zname,
          ZSTATE: "1",
          ZDELETE: "1",
        }}
        form={modalForm}
        layout="vertical"
        modalProps={{
          loading: modalLoading,
          footer: canEditPermission ? undefined : null,
        }}
      >
        <ProFormInput name="ZDOM_VALUE" label="域值编码" rules={[{ required: true, message: "请输入" }]} />
        <ProFormInput name="ZDOM_CODE" label="分类编码" readonly />
        <ProFormInput name="ZDOM_DESC" label="分类名称" readonly />
        <ProFormInput name="ZDOM_NAME" label="域值描述" rules={[{ required: true, message: "请输入" }]} />
        <ProFormInput name="ZDOM_SUP" label="上级域值编码" readonly />
        <ProFormInput name="ZDOM_LEVEL" label="域值层级" readonly />
        <ProFormInput name="sno" label="排序号" />
        <ProFormRadio.Group name="ZSTATE" label="状态" valueEnum={dictStateEnum} />
        <ProFormRadio.Group name="ZDELETE" label="是否删除" valueEnum={delStateEnum} />
        <ProFormInput.TextArea colProps={{ span: 24 }} name="ZREMARKS" label="备注" />

        <ModalForm.Unwrap>
          <Col span={24}>
            {/* 这里和后端的返回类型保持一致，不再做二次处理 */}
            <Form.List name={["ZSELFLANG_LIST", "item"]}>
              {(fields, { add, remove }) => (
                <>
                  <div className="mb-a-marginSM flex justify-between">
                    <span className="text-a-fontSizeLG font-semibold">自建多语言描述</span>
                    <Button type="primary" onClick={() => add()}>
                      新增一条
                    </Button>
                  </div>
                  <Table
                    rowKey="key"
                    dataSource={fields}
                    size="small"
                    pagination={false}
                    columns={[
                      {
                        title: "语种代码",
                        width: "40%",
                        render: (_, field) => (
                          <ProFormSelect
                            className="mb-0"
                            name={[field.name, "ZLANGCODE"]}
                            valueEnum={{ chi: "汉语(chi)", fre: "法语(fre)", eng: "英语(eng)", spa: "西班牙语(spa)" }}
                          />
                        ),
                      },
                      {
                        title: "语种描述",
                        width: "50%",
                        render: (_, field) => <ProFormInput name={[field.name, "ZVALUE_DESC"]} className="mb-0" />,
                      },
                      {
                        title: "操作",
                        width: "10%",
                        render: (_, field) => (
                          <a className="text-a-colorError" onClick={() => remove(field.name)}>
                            删除
                          </a>
                        ),
                      },
                    ]}
                  />
                </>
              )}
            </Form.List>
          </Col>
        </ModalForm.Unwrap>
      </ModalForm>
    </>
  );
}
