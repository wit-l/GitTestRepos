import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/sys-manage/authorization/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/sys-manage/authorization/"!</div>;
}
