import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/api-market/unified-role/role-sync-spec/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/api-market/unified-role/role-sync-spec/"!</div>;
}
