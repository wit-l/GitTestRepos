import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/docking-register-manage/push-logs/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/docking-register-manage/push-logs/"!</div>;
}
