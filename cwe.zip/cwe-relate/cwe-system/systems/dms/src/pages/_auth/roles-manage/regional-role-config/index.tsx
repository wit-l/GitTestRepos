import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/roles-manage/regional-role-config/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/roles-manage/regional-role-config/"!</div>;
}
