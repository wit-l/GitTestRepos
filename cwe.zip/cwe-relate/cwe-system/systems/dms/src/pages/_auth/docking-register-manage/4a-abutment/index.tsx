import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/docking-register-manage/4a-abutment/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/docking-register-manage/4a-abutment/"!</div>;
}
