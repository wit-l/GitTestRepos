import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/api-market/unified-role/role-api/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/api-market/unified-role/role-api/"!</div>;
}
