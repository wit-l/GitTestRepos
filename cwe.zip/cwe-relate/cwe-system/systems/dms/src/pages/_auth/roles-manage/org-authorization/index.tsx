import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/roles-manage/org-authorization/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/roles-manage/org-authorization/"!</div>;
}
