import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/api-market/master-data/basic-master-data-api/")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/_auth/api-market/master-data/basic-master-data-api/"!</div>;
}
