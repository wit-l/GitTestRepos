import { createFileRoute, notFound, redirect } from "@tanstack/react-router";

import { RequestEnum } from "@/config/enum";
import { collectPermissionMenuPaths } from "@/layouts/core/utils/transform-route";
import PageLayout from "@/layouts/page-layout";
import { getCurrentUserInfo, getUserRolesWithMenus } from "@/services/apis/login";
import type { IUserInfo } from "@/services/apis/login/type";
import { useUserAuthStores } from "@/store";

import NotFound from "./(exception)/-404";
import RouteErrorBoundary from "./(exception)/-500";

export const Route = createFileRoute("/_auth")({
  component: PageLayout,
  notFoundComponent: NotFound,
  errorComponent: RouteErrorBoundary,
  beforeLoad: async (ctx) => {
    function resolveToLogin() {
      throw redirect({
        to: "/login",
        search: { redirect: ctx.location.pathname },
      });
    }

    // 未认证
    if (!sessionStorage.getItem(RequestEnum.TOKEN_CACHE)) {
      resolveToLogin();
    }

    // 无用户信息
    if (!useUserAuthStores.getState().userInfo) {
      try {
        const [userInfoRes, rolesAndMenusRes] = await Promise.all([getCurrentUserInfo(), getUserRolesWithMenus()]);

        if (!userInfoRes.success || !rolesAndMenusRes.success) {
          resolveToLogin();
        }

        // 用户没有任何菜单权限 -> 跳转至无角色提示页
        if (rolesAndMenusRes.data.menus.length === 0) {
          throw redirect({ to: "/un-roles" });
        }

        const mergedUserInfo: IUserInfo = {
          ...userInfoRes.data,
          roles: rolesAndMenusRes.data.roles,
          menus: rolesAndMenusRes.data.menus,
        };
        useUserAuthStores.getState().setUserInfo(mergedUserInfo);
      } catch (error) {
        console.error(error);
        useUserAuthStores.getState().logout();
        resolveToLogin();
      }
    }

    const { pathname } = ctx.location;
    const backendMenu = useUserAuthStores.getState().backendMenu;
    const allowed = collectPermissionMenuPaths(backendMenu);
    allowed.add("/");
    // 所有不在后端权限列表中的，都以 404 返回
    if (!allowed.has(pathname)) {
      throw notFound();
    }
  },
});
