import { StyleProvider } from "@ant-design/cssinjs";
import { createRootRoute, Outlet } from "@tanstack/react-router";
import { ConfigProvider, theme as antTheme } from "antd";
import type { MappingAlgorithm, ThemeConfig } from "antd";
import zhCN from "antd/es/locale/zh_CN";
import dayjs from "dayjs";
import { useEffect, useMemo } from "react";

import AntdApp from "@/components/antd-app";
import LazyLoading from "@/components/lazy-loading";
import { componentConfig } from "@/config/appearance";
import useMediaQuery from "@/hooks/useMediaQuery";
import { useAppearanceSelector, useUserAuthStores } from "@/store";
import "dayjs/locale/zh-cn";

import "@/styles/index.css";

import NotFound from "./(exception)/-404";
import RouteErrorBoundary from "./(exception)/-500";

dayjs.locale("zh-cn");

export const Route = createRootRoute({
  component: RootComponent,
  notFoundComponent: NotFound,
  errorComponent: RouteErrorBoundary,
  pendingComponent: LazyLoading,
  pendingMs: 0,
});

function RootComponent() {
  const { size, theme, colorPrimary, borderRadius, grayMode, invertMode } = useAppearanceSelector([
    "size",
    "theme",
    "colorPrimary",
    "borderRadius",
    "grayMode",
    "invertMode",
  ]);
  const isDarkPrefer = useMediaQuery("(prefers-color-scheme: dark)");
  const isDark = theme === "auto" ? isDarkPrefer : theme === "dark";

  console.log(useUserAuthStores.getState());

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
    document.documentElement.classList.toggle("gray-mode", grayMode);
    document.documentElement.classList.toggle("invert-mode", invertMode);
  }, [isDark, grayMode, invertMode]);

  const combineTheme = useMemo(() => {
    const algorithm: MappingAlgorithm[] = [];

    if (isDark) {
      algorithm.push(antTheme.darkAlgorithm);
    }
    if (size === "small") {
      algorithm.push(antTheme.compactAlgorithm);
    }

    return {
      token: { colorPrimary, borderRadius },
      components: { ...componentConfig },
      algorithm,
      hashed: false,
      zeroRuntime: true,
    } satisfies ThemeConfig;
  }, [colorPrimary, size, borderRadius, isDark]);

  return (
    <StyleProvider layer>
      <ConfigProvider locale={zhCN} theme={combineTheme}>
        <AntdApp>
          <Outlet />
        </AntdApp>
      </ConfigProvider>
    </StyleProvider>
  );
}
