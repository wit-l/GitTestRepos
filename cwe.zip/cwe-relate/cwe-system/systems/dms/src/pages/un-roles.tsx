import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/un-roles")({
  component: RouteComponent,
});

function RouteComponent() {
  return <div>Hello "/un-roles"!</div>;
}
