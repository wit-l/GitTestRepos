import { useNavigate } from "@tanstack/react-router";
import type { ErrorComponentProps } from "@tanstack/react-router";
import { Button } from "antd";
import { CircleX } from "lucide-react";

import { clientEnv } from "@/config/env";

export default function RouteErrorBoundary(props: ErrorComponentProps) {
  const { error, reset } = props;
  const navigate = useNavigate();

  const onBackHome = () => navigate({ to: clientEnv.BASE_URL });

  return (
    <div className="flex flex-col items-center p-12">
      <CircleX className="text-7xl text-a-colorError" />
      <div className="mb-2 mt-6 text-2xl">页面加载失败</div>
      <div className="text-a-colorTextSecondary">{error.message}</div>

      <div className="mt-4 flex items-center justify-center gap-2">
        <Button type="primary" onClick={onBackHome}>
          回到主页
        </Button>
        <Button onClick={reset}>重置</Button>
      </div>

      <div className="mt-6 overflow-auto whitespace-pre-line rounded bg-a-colorFillSecondary px-12 py-6">
        {error.stack}
      </div>
    </div>
  );
}
