import type { AxiosError, AxiosHeaders, AxiosInstance, AxiosRequestConfig, InternalAxiosRequestConfig } from "axios";
import { create } from "axios";

import { message } from "@/components/antd-app/staticAntd";
import { RequestEnum } from "@/config/enum";
import { clientEnv } from "@/config/env";
import type { R } from "@/types/common";

import { httpStatus } from "./httpStatus";

type BinaryType = ArrayBuffer | Blob | File | ReadableStream;
// 流文件类型没有正常的 json 格式
type ApiResponse<T> = T extends BinaryType ? Promise<T> : Promise<R<T>>;

class HttpClient {
  instance: AxiosInstance;

  public constructor(config: AxiosRequestConfig) {
    this.instance = create(config);

    this.instance.interceptors.request.use(
      (requestConfig: InternalAxiosRequestConfig<AxiosHeaders>) => {
        const localToken = sessionStorage.getItem(RequestEnum.TOKEN_CACHE);

        // Object.assign 不会导致 ts 类型错误
        requestConfig.headers = Object.assign(
          requestConfig.headers,
          {
            [RequestEnum.TOKEN_HEADER]: `Bearer ${localToken}`,
          },
          config.headers
        );
        return requestConfig;
      },
      (error: AxiosError) => {
        Promise.reject(error);
      }
    );

    this.instance.interceptors.response.use(
      (response) => {
        const { data } = response;

        // if (data.code === HttpEnum.UN_AUTH) {
        //   //   config.onUnAuth?.(response);
        //   // localStorage.removeItem(RequestEnum.TOKEN_CACHE);
        //   window.$message.warning(data.msg || "登陆已失效");
        //   return Promise.reject(data);
        // }
        // // * 全局错误信息拦截（防止下载文件得时候返回数据流，没有code，直接报错）
        // if (data.code && data.code !== HttpEnum.SUCCESS) {
        //   window.$message.error(data.msg);
        //   //   config.onDataError?.(response, data);
        // }
        // * 成功请求（在页面上除非特殊情况，否则不用处理失败逻辑）
        // * 当下载文件时，需要拿 response 中的内容
        return data;
      },
      (error: AxiosError<R>) => {
        const { response } = error;
        console.log(response);
        if (response?.data?.msg) {
          message.error(response.data.msg);
        } else if (error.message.includes("timeout")) {
          // 请求超时没有 response
          message.error("请求超时，请稍后再试");
        } else if (response) {
          message.error(httpStatus[response.status]);
        }
        return Promise.reject(error);
      }
    );
  }

  get<T, D = any>(url: string, params?: object, config: AxiosRequestConfig<D> = {}): ApiResponse<T> {
    return this.instance.get(url, { params, ...config }) as ApiResponse<T>;
  }
  post<T, D = any>(url: string, data?: any, config: AxiosRequestConfig<D> = {}): ApiResponse<T> {
    return this.instance.post(url, data, config) as ApiResponse<T>;
  }
  put<T, D = any>(url: string, data?: any, config: AxiosRequestConfig<D> = {}): ApiResponse<T> {
    return this.instance.put(url, data, config) as ApiResponse<T>;
  }
  delete<T, D = any>(url: string, params?: any, config: AxiosRequestConfig<D> = {}): ApiResponse<T> {
    return this.instance.delete(url, { params, ...config }) as ApiResponse<T>;
  }
}

export const http = new HttpClient({
  baseURL: clientEnv.VITE_API_BASE_URL,
  // timeout: 20000,
  withCredentials: true,
});

export const http2 = new HttpClient({
  baseURL: "/test-online",
  // timeout: 20000,
  withCredentials: true,
});
