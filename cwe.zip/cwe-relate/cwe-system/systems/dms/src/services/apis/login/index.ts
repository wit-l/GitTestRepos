import { http, http2 } from "@/services/http";

import type { ILoginData, IRoleWithMenusData, IUserInfo } from "./type";

/** 登录 */
export const login = (data: ILoginData) => http.get<string>("/platform/platform-system/sys/login/code/v1.0", data);

/** 获取验证码 */
export const getCaptcha = (randomStr: string) =>
  http.get<Blob>("/platform/platform-system/sys/code/v1.0", { randomStr }, { responseType: "blob" });

/** 获取当前用户角色和权限菜单 */
// export const getUserRolesWithMenus = () => http.get<IRoleWithMenusData>("/system-server/sys/userInfo/rolesAndmenus");
export const getUserRolesWithMenus = () => http2.get<IRoleWithMenusData>("/system-server/sys/userInfo/rolesAndmenus");

/** 获取当前用户信息 */
export const getCurrentUserInfo = () => http2.get<IUserInfo>("/system-server/sys/userInfo/v1.0");
