export interface IBuiltDictType {
  id: string;
  createTime: string;
  updateTime: string;
  zcode: string;
  zname: string;
  sno: string;
  ztype: string;
  classify: string;
}

export interface IBuiltDictTypeParams {
  name?: string;
  ztype?: string;
  classify?: string;
}

export interface IBuiltDictDetailTree {
  id: string;
  parentId?: string;
  weight: string;
  name: string;
  ZDOM_DESC: string;
  dataId: string;
  ZVERSION: number;
  SNO: string;
  ZDOM_LEVEL?: never;
  ZREMARKS?: never;
  ZSTATE: string;
  ZDOM_CODE: string;
  ZLANG_LIST: {
    item?: never;
  };
  ZDELETE: string;
  ZTYPE: string;
}

export interface IBuiltDictDetailTreeParams {
  conditions: {
    column: string;
    value?: string | number;
    type?: string;
  }[];
}

export interface IBuiltDictDetailRecord {
  id: string;
  createTime: string;
  updateTime: string;
  sno: string;
  children?: never;
  dictIds?: never;
  dicts?: never;
  ZZSERIAL?: never;
  ZVERSION: number;
  ZSTATE: string;
  ZDELETE: string;
  ZLANG_LIST: {
    item?: never;
  };
  ZSELFLANG_LIST?: {
    item: {
      ZLANGCODE: string;
      ZCODE_DESC: string;
      ZVALUE_DESC: string;
      ZSCRTEXT_S?: string;
    }[];
  };
  ZDOM_CODE: string;
  ZDOM_DESC: string;
  ZDOM_NAME: string;
  ZDOM_VALUE: string;
  ZDOM_LEVEL?: never;
  ZDOM_SUP?: string;
  ZREMARKS?: string;
  ZCHTIME?: never;
  ZTYPE: string;
}
