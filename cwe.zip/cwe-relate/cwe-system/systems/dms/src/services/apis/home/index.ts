import { http } from "@/services/http";
import type { List } from "@/types/common";

import type { ICallbackFailApi, ICommonApiDaysTop, IMostTimesApiTop, IVisitHours, IVisitTimeDays } from "./type";

/** 近15天访问次数趋势 */
export const getDaysVisitTrend = () => http.get<IVisitTimeDays[]>("/mdm-server/log/aspect/day/trend");

/** 近24小时访问统计 */
export const getHoursVisitStatistics = () => http.get<IVisitHours[]>("/mdm-server/log/aspect/hour/trend");

/** 近15天常用接口排行TOP10 */
export const getCommonApiTop = () => http.get<ICommonApiDaysTop[]>("/mdm-server/log/aspect/common/rankings");

/** 近15天最耗时接口排行TOP10 */
export const getMostTimeApiTop = () => http.get<IMostTimesApiTop[]>("/mdm-server/log/aspect/most/time/rankings");

/** 15日内调用失败接口列表 */
export const getDaysCallbackFailApi = () => http.get<List<ICallbackFailApi>>("/mdm-server/log/aspect/fail/list");
