import { http } from "@/services/http";

import type {
  IBuiltDictType,
  IBuiltDictTypeParams,
  IBuiltDictDetailTree,
  IBuiltDictDetailTreeParams,
  IBuiltDictDetailRecord,
} from "./type";

/** 自建字典列表 */
export const getBuiltDictTypeList = (params?: IBuiltDictTypeParams) =>
  http.get<IBuiltDictType[]>("/mdm-server/dict/type/v1.0/list", params);

/** 自建字典列表 */
export const delBuiltDictTypeRecord = (id: string) => http.delete(`/mdm-server/dict/type/v1.0/list/${id}`);

/** 新建字典类型 */
export const addBuiltDictTypeRecord = (data: IBuiltDictType) => http.post("/mdm-server/dict/type/v1.0", data);

/** 更新字典类型 */
export const updateBuiltDictTypeRecord = (data: IBuiltDictType) => http.put("/mdm-server/dict/type/v1.0", data);

/** 自建字典分类明细(树状列表) */
export const getBuiltDictDetailTree = (data: IBuiltDictDetailTreeParams) =>
  http.post<IBuiltDictDetailTree[]>("/mdm-server/dict/detail/v1.0/tree", data);

/** 自建字典分类明细详情数据 */
export const getBuiltDictDetailRecord = (id: string) =>
  http.get<IBuiltDictDetailRecord>(`/mdm-server/dict/detail/v1.0/${id}`);

/** 新建自建字典分类明细详情数据 */
export const addBuiltDictDetailRecord = (data: IBuiltDictDetailRecord) =>
  http.post("/mdm-server/dict/detail/v1.0", data);

/** 更新自建字典分类明细详情数据 */
export const updateBuiltDictDetailRecord = (data: IBuiltDictDetailRecord) =>
  http.put("/mdm-server/dict/detail/v1.0", data);

/** 删除自建字典分类明细 */
export const delBuiltDictDetailRecord = (id: string) => http.delete(`/mdm-server/dict/detail/v1.0/${id}`);

/** 删除自建字典分类明细 */
export const importBuiltDictDetailExcel = (formData: FormData) =>
  http.post("/mdm-server/dict/detail/import/infos", formData);
