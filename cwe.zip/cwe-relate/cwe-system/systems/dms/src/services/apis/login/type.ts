export interface ILoginData {
  userName: string;
  password: string;
  code: string;
  state: string;
}

export interface IUserInfo {
  empcode: string;
  name: string;
  jobname: string;
  officedepid: string;
  photo?: {
    fileURL?: string;
  };
  posts: any[];
  checUserName: string;
  extendedParams: {
    sysConfig: {
      bucketName?: string;
      mobileIp: string;
      orderSource?: string;
      code: string;
      processAppId: string;
      userSource: string;
      portalTableSuffix?: string;
      frontendUrl?: string;
      name: string;
      processAppSecret?: string;
      id: string;
      pcIp: string;
    };
  };
  orule: string;
  // 合并进来的
  roles?: IRole[];
  menus?: IMenuItem[];
}

export interface IRoleWithMenusData {
  roles: IRole[];
  menus: IMenuItem[];
}
export interface IRole {
  code: string;
  name: string;
  id: string;
}
export interface IMenuItem {
  id: string;
  parentId: string;
  weight?: number;
  name: string;
  path: string;
  icon?: string;
  permission?: string;
  label: string;
  /** 0 菜单 1 按钮 */
  type: 0 | 1;
  /** 0 展示 1 隐藏 */
  isShow: 0 | 1;
  children?: IMenuItem[];
}
