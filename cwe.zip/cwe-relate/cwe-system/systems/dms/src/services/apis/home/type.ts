export type IVisitTimeDays = Record<string, number>;

export interface IVisitHours {
  no: number;
  dateStr?: string;
  action?: string;
  describe?: string;
  requestNum: number;
  successNum: number;
  failNum: number;
  avgTime: number;
  successRate?: string;
}

export interface ICommonApiDaysTop extends IVisitHours {}

export interface IMostTimesApiTop extends IVisitHours {}

export interface ICallbackFailApi {
  action: string;
  describe: string;
  api: string;
  method: string;
  paramJson: string;
  startTime: string;
  timeConsuming: string;
  clientId: string;
  ip: string;
  errorMsg: string;
}
