import type { TabsProps } from "antd";
import { pick } from "es-toolkit";
import { House } from "lucide-react";
import { createElement } from "react";
import isEqual from "react-fast-compare";
import type { StateCreator } from "zustand";
import { immer } from "zustand/middleware/immer";
import { createWithEqualityFn } from "zustand/traditional";

import { clientEnv } from "@/config/env";

type TabItem = NonNullable<TabsProps["items"]>[number];

export interface TabRoute {
  pathname: string;
  search: Record<string, unknown>;
  hash: string;
}

export interface TabsState {
  activeTabKey: string;
  openTabs: NonNullable<TabsProps["items"]>;
  tabRoutes: Record<string, TabRoute>;
  refreshKey: number;
  isMaximize: boolean;
}

export interface TabsAction {
  forceRefresh: () => void;
  setActiveTabKey: (tabKey: string) => void;
  addTab: (tabKey: string, route: TabRoute, cb: (tabKey: string) => TabItem) => void;
  removeTab: (tabKey: string) => void;
  closeLeftTabs: (tabKey: string) => void;
  closeRightTabs: (tabKey: string) => void;
  closeOtherTabs: (tabKey: string) => void;
  closeAllTabs: () => void;
  toggleMaximize: () => void;
}

const HOME_KEY = clientEnv.BASE_URL;

const defaultTabs: TabItem = {
  key: HOME_KEY,
  label: "首页",
  icon: createElement(House),
  closable: false,
};

const defaultHomeRoute: TabRoute = { pathname: HOME_KEY, search: {}, hash: "" };

const defaultState: TabsState = {
  activeTabKey: HOME_KEY,
  openTabs: [defaultTabs],
  tabRoutes: { [HOME_KEY]: defaultHomeRoute },
  refreshKey: 0,
  isMaximize: false,
};

export type TabsStore = TabsState & TabsAction;

const createTabsStore: StateCreator<TabsStore, [["zustand/immer", never]], [], TabsStore> = (set) => ({
  ...defaultState,
  forceRefresh: () => set((state) => ({ refreshKey: state.refreshKey + 1 })),
  setActiveTabKey: (tabKey: string) => set(() => ({ activeTabKey: tabKey })),

  addTab: (tabKey: string, route: TabRoute, cb: (tabKey: string) => TabItem) =>
    set((state) => {
      const isExistPath = state.openTabs.find((item) => item.key === tabKey);
      // 已存在，刷新路由信息并切换 active
      if (isExistPath) {
        return {
          activeTabKey: tabKey,
          tabRoutes: { ...state.tabRoutes, [tabKey]: route },
        };
      }

      const newTabItem = cb(tabKey);
      return {
        openTabs: [...state.openTabs, newTabItem],
        tabRoutes: { ...state.tabRoutes, [tabKey]: route },
        activeTabKey: tabKey,
      };
    }),
  removeTab: (tabKey: string) =>
    set((state) => {
      // 首页路由禁止关闭
      if (tabKey === HOME_KEY) {
        return state;
      }
      // 由于首页始终位于首位，且不可删除，因此 currentIndex 始终可以安全访问上一个 tabItem
      const currentIndex = state.openTabs.findIndex((item) => item.key === tabKey);
      const isSelectedTab = tabKey === state.activeTabKey;
      const { [tabKey]: _removed, ...restRoutes } = state.tabRoutes;
      return {
        openTabs: state.openTabs.filter((item) => item.key !== tabKey),
        tabRoutes: restRoutes,
        activeTabKey: isSelectedTab ? state.openTabs[currentIndex - 1].key : state.activeTabKey,
      };
    }),

  closeLeftTabs: (tabKey: string) =>
    set((state) => {
      const currentIndex = state.openTabs.findIndex((item) => item.key === tabKey);
      const keptTabs = [defaultTabs, ...state.openTabs.slice(currentIndex)];
      const keptKeys = new Set(keptTabs.map((t) => t.key));
      const tabRoutes = Object.fromEntries(Object.entries(state.tabRoutes).filter(([k]) => keptKeys.has(k)));
      return {
        openTabs: keptTabs,
        tabRoutes: { [HOME_KEY]: defaultHomeRoute, ...tabRoutes },
      };
    }),
  closeRightTabs: (tabKey: string) =>
    set((state) => {
      const currentIndex = state.openTabs.findIndex((item) => item.key === tabKey);
      const keptTabs = state.openTabs.slice(0, currentIndex + 1);
      const keptKeys = new Set(keptTabs.map((t) => t.key));
      return {
        openTabs: keptTabs,
        tabRoutes: Object.fromEntries(Object.entries(state.tabRoutes).filter(([k]) => keptKeys.has(k))),
      };
    }),
  closeOtherTabs: (tabKey: string) =>
    set((state) => {
      const keptTabs = state.openTabs.filter((item) => item.key === tabKey || item.key === HOME_KEY);
      const keptKeys = new Set(keptTabs.map((t) => t.key));
      return {
        openTabs: keptTabs,
        tabRoutes: Object.fromEntries(Object.entries(state.tabRoutes).filter(([k]) => keptKeys.has(k))),
      };
    }),
  closeAllTabs: () =>
    set(() => ({
      openTabs: [defaultTabs],
      tabRoutes: { [HOME_KEY]: defaultHomeRoute },
      activeTabKey: defaultTabs.key,
    })),

  toggleMaximize: () =>
    set((state) => ({
      isMaximize: !state.isMaximize,
    })),
});

export const useTabsStores = createWithEqualityFn<TabsStore>()(
  immer((...args) => createTabsStore(...args)),
  isEqual
);

export const useTabsSelector = <K extends keyof TabsStore>(key: K[]) => useTabsStores((state) => pick(state, key));
