import type { MenuTheme } from "antd";
import { pick } from "es-toolkit";
import isEqual from "react-fast-compare";
import type { StateCreator } from "zustand";
import { persist } from "zustand/middleware";
import { immer } from "zustand/middleware/immer";
import { createWithEqualityFn } from "zustand/traditional";

import { LayoutPresetMode } from "@/config/appearance";
import type { LayoutPresetModeType } from "@/config/appearance";

export type GlobalThemeMode = "light" | "dark" | "auto";
export type GlobalSizeMode = "default" | "small";

export type TransitionName = "fade" | "fade-slide" | "fade-up" | "fade-down";

export type TabsMode = "chrome" | "plain" | "card" | "line";

interface AppearanceState {
  // ========= Theme =========
  theme: GlobalThemeMode;
  size: GlobalSizeMode;
  menuTheme: MenuTheme;
  colorPrimary: string;
  borderRadius: number;
  grayMode: boolean;
  invertMode: boolean;
  tabsMode: TabsMode;
  layoutMode: LayoutPresetModeType;

  // ========= Data/State =========
  // menus: MenuProps["items"];
  collapsed: boolean;

  dynamicTitle: boolean;
  versionCheck: boolean;

  // ========= transition =========
  transitionPageSwitch: boolean;
  transitionName: TransitionName;
  transitionProgress: boolean;
  transitionPageLoading: boolean;
}

interface AppearanceAction {
  setAppearance: {
    // 单个 key-value 更新
    <K extends keyof AppearanceState>(key: K, value: AppearanceState[K]): void;
    // 对象形式批量更新
    (preferences: { [K in keyof AppearanceState]?: AppearanceState[K] }): void;
  };
  reset: () => void;
}

const defaultState: AppearanceState = {
  theme: "auto",
  size: "default",
  menuTheme: "light",
  colorPrimary: "#1677ff",
  borderRadius: 4,
  grayMode: false,
  invertMode: false,
  tabsMode: "plain",
  layoutMode: LayoutPresetMode.Side_Nav,

  // menus: [],
  collapsed: false,

  dynamicTitle: true,
  versionCheck: false,

  transitionPageSwitch: true,
  transitionName: "fade-slide",
  transitionProgress: true,
  transitionPageLoading: true,
};

export type AppearanceStore = AppearanceState & AppearanceAction;

// https://zustand.docs.pmnd.rs/learn/guides/advanced-typescript#slices-pattern
const createAppearanceStore: StateCreator<
  AppearanceStore,
  // https://zustand.docs.pmnd.rs/learn/guides/advanced-typescript#middlewares-and-their-mutators-reference
  [["zustand/immer", never], ["zustand/persist", unknown]],
  [],
  AppearanceStore
> = (set) => ({
  ...defaultState,
  setAppearance: (...args: any[]) => {
    if (args.length === 1) {
      const preferences = args[0];
      set(() => ({ ...preferences }));
    } else if (args.length === 2) {
      const [key, value] = args;
      set(() => ({ [key]: value }));
    } else {
      console.error("setAppearance 不接受此类参数");
    }
  },
  reset: () => {
    set(() => ({ ...defaultState }));
  },
});

// https://zustand.docs.pmnd.rs/reference/apis/create-with-equality-fn#createwithequalityfn
export const useAppearanceStores = createWithEqualityFn<AppearanceStore>()(
  immer(
    persist((...args) => createAppearanceStore(...args), {
      name: "uckj_appearance",
      partialize: (state) =>
        pick(state, [
          "theme",
          "size",
          "menuTheme",
          "colorPrimary",
          "borderRadius",
          "grayMode",
          "invertMode",
          "tabsMode",
          "layoutMode",

          "dynamicTitle",
          "versionCheck",

          "transitionPageSwitch",
          "transitionName",
          "transitionProgress",
          "transitionPageLoading",
        ]),
    })
  ),
  isEqual
);

export const useAppearanceSelector = <K extends keyof AppearanceStore>(key: K[]) =>
  useAppearanceStores((state) => pick(state, key));
