import type { ItemType } from "antd/es/menu/interface";
import { pick } from "es-toolkit";
import isEqual from "react-fast-compare";
import type { StateCreator } from "zustand";
import { immer } from "zustand/middleware/immer";
import { createWithEqualityFn } from "zustand/traditional";

import {
  collectButtonPermissions,
  convertBackendMenuToAllItems,
  convertBackendMenuToItems,
} from "@/layouts/core/utils/transform-route";
import type { IMenuItem, IUserInfo } from "@/services/apis/login/type";

export interface UserAuthState {
  userInfo?: IUserInfo;
  /** 后端原始菜单树 */
  backendMenu: IMenuItem[];
  /** 经转换后可直接被 antd Menu 消费的 items（仅 isShow === 0，用于侧边栏渲染） */
  menus: ItemType[];
  /** 全量可访问路由 items（含 isShow === 1 的隐藏路由），用于 Tab/Breadcrumb 等按 path 反查标题 */
  allRouteItems: ItemType[];
  /** 按钮级权限码集合（type === 1 节点的 permission，缺省回退 path）。 */
  permissions: string[];
}

export interface UserAuthAction {
  /**
   * 写入用户信息；同时根据 `userInfo.menus` 派生 backendMenu / menus / permissions。
   * 调用方只需保证已把 rolesAndMenus 合并到 userInfo 上即可。
   */
  setUserInfo: (userInfo: IUserInfo) => void;
  logout: () => void;
}

const defaultState: UserAuthState = {
  userInfo: undefined,
  backendMenu: [],
  menus: [],
  allRouteItems: [],
  permissions: [],
};

export type UserAuthsStore = UserAuthState & UserAuthAction;

const createUserAuthsStore: StateCreator<UserAuthsStore, [["zustand/immer", never]], [], UserAuthsStore> = (set) => ({
  ...defaultState,
  setUserInfo: (userInfo) =>
    set(() => {
      const backendMenu = userInfo.menus ?? [];
      return {
        userInfo,
        backendMenu,
        menus: convertBackendMenuToItems(backendMenu),
        allRouteItems: convertBackendMenuToAllItems(backendMenu),
        permissions: collectButtonPermissions(backendMenu),
      };
    }),
  logout: () => set(() => ({ ...defaultState })),
});

export const useUserAuthStores = createWithEqualityFn<UserAuthsStore>()(
  immer((...args) => createUserAuthsStore(...args)),
  isEqual
);

export const useUserAuthSelector = <K extends keyof UserAuthsStore>(key: K[]) =>
  useUserAuthStores((state) => pick(state, key));
