import { createRouter } from "@tanstack/react-router";

import { routeTree } from "./routeTree.gen";

export const router = createRouter({
  routeTree,
  scrollRestoration: true,
  defaultPreload: "intent",
  defaultPreloadStaleTime: 0,
  trailingSlash: "never",
});

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }

  interface StaticDataRouteOption {
    /**
     * @description 页面标题，若设置，则会自动拼接网站标题
     */
    title?: string;
    /**
     * @description 按钮/页面级权限码（与后端菜单 `permission` 字段对齐）。空数组或 undefined 表示无限制。
     */
    access?: string[];
  }
}
