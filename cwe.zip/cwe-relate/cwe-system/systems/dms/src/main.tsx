import { TanStackDevtools } from "@tanstack/react-devtools";
import { RouterProvider } from "@tanstack/react-router";
import { TanStackRouterDevtoolsPanel } from "@tanstack/react-router-devtools";
import { createRoot } from "react-dom/client";

import { clientEnv } from "./config/env";
import { router } from "./router";

createRoot(document.getElementById("root")!).render(
  <>
    <RouterProvider basepath={clientEnv.BASE_URL} router={router} />
    {clientEnv.DEV && (
      <TanStackDevtools
        config={{ position: "bottom-right" }}
        plugins={[
          { name: "TanStack Router", render: <TanStackRouterDevtoolsPanel router={router} /> },
          // { name: "TanStack Query", render: <ReactQueryDevtools /> },
        ]}
      />
    )}
  </>
);
