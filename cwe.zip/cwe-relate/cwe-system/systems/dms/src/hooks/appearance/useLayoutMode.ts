import { useMemo } from "react";

import { LayoutPresetMode } from "@/config/appearance";
import { useAppearanceSelector } from "@/store";

export default function useLayoutMode() {
  const { layoutMode } = useAppearanceSelector(["layoutMode"]);

  return useMemo(
    () => ({
      isSideLayout: layoutMode === LayoutPresetMode.Side_Nav,
      isTopLayout: layoutMode === LayoutPresetMode.Top_Nav,
      isMixedLayout: layoutMode === LayoutPresetMode.Mixed_Nav,
      isTwoColumnLayout: layoutMode === LayoutPresetMode.Two_Column_Nav,
    }),
    [layoutMode]
  );
}
