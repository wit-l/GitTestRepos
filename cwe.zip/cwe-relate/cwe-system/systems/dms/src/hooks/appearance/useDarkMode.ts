import { useMemo } from "react";

import { useAppearanceSelector } from "@/store";

export function getSystemPreference() {
  return window.matchMedia("(prefers-color-scheme: dark)").matches;
}

export default function useDarkMode() {
  const { theme } = useAppearanceSelector(["theme"]);

  return useMemo(() => {
    const isMqlDark = getSystemPreference();
    return theme === "auto" ? isMqlDark : theme === "dark";
  }, [theme]);
}
