import { useTitle } from "ahooks";

import { clientEnv } from "@/config/env";
import { useAppearanceSelector } from "@/store";

function genDocumentTitle(enable: boolean, moduleTitle?: string) {
  if (!enable || !moduleTitle) {
    return clientEnv.VITE_APP_TITLE;
  }

  return `${moduleTitle} - ${clientEnv.VITE_APP_TITLE}`;
}

/**
 * @description 结合 store dynamicTitle 生成 document title
 * @default clientEnv.VITE_APP_TITLE
 */
export default function useAppTitle(title?: string) {
  const { dynamicTitle } = useAppearanceSelector(["dynamicTitle"]);

  const documentTitle = genDocumentTitle(dynamicTitle, title);
  useTitle(documentTitle);

  return documentTitle;
}
