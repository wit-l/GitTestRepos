import { useState, useEffect } from "react";

export default function useMediaQuery(query: string) {
  const [state, setState] = useState<boolean>(() => window.matchMedia(query).matches);

  useEffect(() => {
    let mounted = true;
    const mql = window.matchMedia(query);

    const listenMqlChange = () => {
      if (!mounted) {
        return;
      }
      setState(!!mql.matches);
    };

    mql.addEventListener("change", listenMqlChange);
    setState(mql.matches);

    return () => {
      mounted = false;
      mql.removeEventListener("change", listenMqlChange);
    };
  }, [query]);

  return state;
}
