import { isString } from "es-toolkit";
import { useMemo } from "react";

import { useUserAuthSelector } from "@/store";

export function canAccess(requiredAuths?: string | string[], userPermissions?: string[]): boolean {
  if (!requiredAuths || requiredAuths.length === 0) {
    return true;
  }

  if (!userPermissions || userPermissions.length === 0) {
    return false;
  }

  if (isString(requiredAuths)) {
    return userPermissions.includes(requiredAuths);
  }

  return requiredAuths.some((item) => userPermissions.includes(item));
}

export function useAccess(access?: string | string[]): boolean {
  const { permissions } = useUserAuthSelector(["permissions"]);
  return useMemo(() => canAccess(access, permissions), [permissions, access]);
}
