// 系列类型
import type { BarSeriesOption, LineSeriesOption, PieSeriesOption } from "echarts/charts";
// 图表
import { BarChart, LineChart, PieChart } from "echarts/charts";
// 组件类型
import type {
  DatasetComponentOption,
  DataZoomComponentOption,
  GridComponentOption,
  LegendComponentOption,
  TitleComponentOption,
  TooltipComponentOption,
} from "echarts/components";
// 组件
import {
  DatasetComponent,
  DataZoomComponent,
  GridComponent,
  LegendComponent,
  TitleComponent,
  TooltipComponent,
  // 内置数据转换器组件 (filter, sort)
  TransformComponent,
} from "echarts/components";
import * as echarts from "echarts/core";
// 类型工具
import type { ComposeOption } from "echarts/core";
// 功能
import { LabelLayout, UniversalTransition } from "echarts/features";
// 渲染器
import { CanvasRenderer } from "echarts/renderers";

export type EChartsOptions = ComposeOption<
  | BarSeriesOption
  | LineSeriesOption
  | TitleComponentOption
  | TooltipComponentOption
  | GridComponentOption
  | DatasetComponentOption
  | PieSeriesOption
  | LegendComponentOption
  | DataZoomComponentOption
>;

// 注册必须的组件
echarts.use([
  // 组件
  TitleComponent,
  TooltipComponent,
  GridComponent,
  DatasetComponent,
  TransformComponent,
  LegendComponent,
  DataZoomComponent,
  // 图表
  BarChart,
  LineChart,
  PieChart,
  // 功能
  LabelLayout,
  UniversalTransition,
  // 渲染器
  CanvasRenderer,
]);

export default echarts;
