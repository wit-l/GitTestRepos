import { useDebounceFn, useEventListener, useMemoizedFn, useMount, useUnmount, useUpdateEffect } from "ahooks";
import type { ECharts, EChartsInitOpts } from "echarts/core";
import { useMemo, useRef } from "react";

import useDarkMode from "../appearance/useDarkMode";
import type { EChartsOptions } from "./plugins";
import echarts from "./plugins";

export interface UseEChartsOptions {
  /**
   * echarts 初始化选项
   */
  initOptions?: EChartsInitOpts;
  /**
   * 是否自动调整尺寸
   */
  autoResize?: boolean;
  /**
   * 是否开启动画
   */
  animation?: boolean;
  /**
   * resize 防抖时间
   */
  resizeDebounce?: number;
  /**
   * 是否默认初始化 options
   */
  defaultInit?: boolean;
}

export function useECharts<T extends HTMLElement = HTMLDivElement>(
  chartOptions: EChartsOptions,
  options?: UseEChartsOptions
) {
  const { initOptions, autoResize = true, animation = true, resizeDebounce = 300, defaultInit = true } = options ?? {};

  const containerRef = useRef<T>(null);
  const chartInstRef = useRef<ECharts | null>(null);
  const isDark = useDarkMode();
  // https://echarts.apache.arg/handbook/zh/basics/release-not/v6-feature

  useMount(() => {
    const dom = containerRef.current;
    if (!dom) {
      return;
    }
    const chart = echarts.init(dom, isDark ? "dark" : "default", initOptions);
    chartInstRef.current = chart;
    if (defaultInit) {
      chart.setOption(chartOptions, { silent: !animation });
    }
  });

  const destroy = useMemoizedFn(() => {
    chartInstRef.current?.dispose();
    chartInstRef.current = null;
  });

  useUnmount(destroy);

  // 初次已在 mount 中设置，仅在更新时重新设置
  useUpdateEffect(() => {
    chartInstRef.current?.setTheme(isDark ? "dark" : "default");
  }, [isDark]);

  const { run: runResize } = useDebounceFn(
    () => {
      chartInstRef.current?.resize({
        animation: animation ? { duration: 300 } : undefined,
      });
    },
    { wait: resizeDebounce, leading: true, trailing: true }
  );

  useEventListener("resize", runResize, { enable: autoResize });

  const setOption = useMemoizedFn((opts: EChartsOptions, notMerge?: boolean, lazyUpdate?: boolean) => {
    chartInstRef.current?.setOption(opts, {
      notMerge,
      lazyUpdate,
      silent: !animation,
    });
  });

  const resize = useMemoizedFn(() => {
    chartInstRef.current?.resize({
      animation: animation ? { duration: 300 } : undefined,
    });
  });

  const getInstance = useMemoizedFn((): ECharts | null => chartInstRef.current);

  // useMemoizedFn 返回的函数引用永久稳定,这里 useMemo 仅会执行一次
  return useMemo(
    () => ({ ref: containerRef, getInstance, setOption, resize, destroy }),
    [getInstance, setOption, resize, destroy]
  );
}
