import { Outlet } from "@tanstack/react-router";
import { Layout } from "antd";

import PageHeader from "../page-header";
import PageSider from "../page-sider";

const { Content } = Layout;

export default function PageLayout() {
  return (
    <Layout className="h-full">
      <PageSider />
      <Layout>
        <PageHeader />
        <Content className="h-full overflow-auto p-4 pt-2">
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
}
