import type { ItemType, SubMenuType } from "antd/es/menu/interface";

export function matchMenus(menus: ItemType[], pathname: string, parents: ItemType[] = []): ItemType[] | undefined {
  for (const menu of menus) {
    const currentPath = [...parents, menu];

    if (menu?.key === pathname) {
      return currentPath;
    }

    if ((menu as SubMenuType)?.children) {
      const found = matchMenus((menu as SubMenuType).children, pathname, currentPath);
      if (found) {
        return found;
      }
    }
  }
  return undefined;
}
