import { Switch } from "antd";

import { useAppearanceSelector } from "@/store";

import SwitchItemWrapper from "../components/switch-item";

export default function AppearanceVersionMonitorSetting() {
  const { versionCheck, setAppearance } = useAppearanceSelector(["versionCheck", "setAppearance"]);

  const handleSwitchChange = (checked: boolean) => {
    setAppearance("versionCheck", checked);
  };

  const handleClickItemWrapper = () => {
    setAppearance("versionCheck", !versionCheck);
  };

  return (
    <SwitchItemWrapper onClick={handleClickItemWrapper}>
      <span>定时检查更新</span>
      <Switch className="min-w-10" checked={versionCheck} onChange={handleSwitchChange} />
    </SwitchItemWrapper>
  );
}
