import { cn } from "@/utils/cn";

import styles from "./style.module.css";

interface OutlineBoxProps extends React.ComponentProps<"div"> {
  icon: React.ReactElement<any>;
  text?: React.ReactNode;
  isActive?: boolean;
}

export default function OutlineBox(props: OutlineBoxProps) {
  const { text, icon, isActive, className, ...restProps } = props;

  return (
    <li className="flex cursor-pointer list-none flex-col">
      <div {...restProps} className={cn(styles["outline-box-wrapper"], isActive && styles["box-active"], className)}>
        {icon}
      </div>
      {text && <div className="mt-a-marginXS text-center text-a-fontSizeSM text-a-colorTextSecondary">{text}</div>}
    </li>
  );
}
