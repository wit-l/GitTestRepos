import { cn } from "@/utils/cn";

export const shareToolbarBtnStyle = cn(
  "cursor-pointer bg-transparent p-0 text-a-fontSizeLG transition-colors hover:text-a-colorTextSecondary",
  "focus-visible:outline-a-colorPrimaryBorder focus-visible:outline-offset-2"
);
