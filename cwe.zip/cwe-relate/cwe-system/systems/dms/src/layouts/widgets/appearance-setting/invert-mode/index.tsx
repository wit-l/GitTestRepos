import { Switch } from "antd";

import { useAppearanceSelector } from "@/store";

import SwitchItemWrapper from "../components/switch-item";

export default function AppearanceInvertModeSetting() {
  const { invertMode, setAppearance } = useAppearanceSelector(["invertMode", "setAppearance"]);

  const handleSwitchChange = (checked: boolean) => {
    setAppearance("invertMode", checked);
  };

  const handleClickItemWrapper = () => {
    setAppearance("invertMode", !invertMode);
  };

  return (
    <SwitchItemWrapper onClick={handleClickItemWrapper}>
      <span>色弱模式</span>
      <Switch className="min-w-10" checked={invertMode} onChange={handleSwitchChange} />
    </SwitchItemWrapper>
  );
}
