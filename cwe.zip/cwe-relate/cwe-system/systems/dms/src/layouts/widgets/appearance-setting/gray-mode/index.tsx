import { Switch } from "antd";

import { useAppearanceSelector } from "@/store";

import SwitchItemWrapper from "../components/switch-item";

export default function AppearanceGrayModeSetting() {
  const { grayMode, setAppearance } = useAppearanceSelector(["grayMode", "setAppearance"]);

  const handleSwitchChange = (checked: boolean) => {
    setAppearance("grayMode", checked);
  };

  const handleClickItemWrapper = () => {
    setAppearance("grayMode", !grayMode);
  };

  return (
    <SwitchItemWrapper onClick={handleClickItemWrapper}>
      <span>灰色模式</span>
      <Switch className="min-w-10" checked={grayMode} onChange={handleSwitchChange} />
    </SwitchItemWrapper>
  );
}
