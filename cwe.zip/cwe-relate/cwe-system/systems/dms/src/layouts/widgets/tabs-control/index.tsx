import { useLocation, useMatches, useNavigate, useRouter } from "@tanstack/react-router";
import { useUpdateEffect } from "ahooks";
import { Tabs } from "antd";
import type { TabsProps } from "antd";
import type { MenuItemType } from "antd/es/menu/interface";
import { cloneElement, useCallback, useEffect, useMemo } from "react";

import { matchMenus } from "@/layouts/utils";
import type { FileRoutesByFullPath } from "@/routeTree.gen";
import { useAppearanceSelector, useUserAuthSelector } from "@/store";
import { useTabsSelector } from "@/store/modules/tabs";
import { cn } from "@/utils/cn";

import ForceRefreshPage from "./tabs-toolbar/force-refresh-page";
import MaxContent from "./tabs-toolbar/max-content";
import MoreToolbar from "./tabs-toolbar/more-toolbar";

import styles from "./style.module.css";

export default function TabsControl() {
  const location = useLocation();
  const { pathname, href } = location;
  const navigate = useNavigate();
  const router = useRouter();
  const { tabsMode } = useAppearanceSelector(["tabsMode"]);
  const { allRouteItems } = useUserAuthSelector(["allRouteItems"]);
  const { openTabs, activeTabKey, tabRoutes, setActiveTabKey, addTab, removeTab } = useTabsSelector([
    "openTabs",
    "activeTabKey",
    "tabRoutes",
    "setActiveTabKey",
    "addTab",
    "removeTab",
  ]);

  const matches = useMatches();
  const currentMatch = matches.at(-1);

  const matchRouteTabOption = useCallback(
    (tabKey: string): NonNullable<TabsProps["items"]>[number] => {
      // tabKey 现在是完整 href（含 search），而菜单 key 是纯 pathname，按 ? 切出 pathname 再匹配
      const lookupPathname = tabKey.split("?")[0];
      // 先匹配菜单数据，如果在菜单中，则展示图标和文本
      const menuItems = matchMenus(allRouteItems, lookupPathname);
      const currentMenu = menuItems?.at(-1);
      if (currentMenu) {
        return {
          key: tabKey,
          label: (currentMenu as MenuItemType).label,
          icon: (currentMenu as MenuItemType).icon,
        };
      }

      // 不在菜单中的路由（login/403 等）只展示标题，无图标
      return {
        key: tabKey,
        label: currentMatch?.staticData?.title,
      };
    },
    [allRouteItems, currentMatch]
  );

  const isUnRedirectPath = useMemo(() => {
    const { routesByPath } = router;
    // 容器路由（仅 beforeLoad 重定向、自身没有 component）不应作为 tab。
    // 双列/混合布局点击一级菜单时，pathname 会先提交为容器路径再被 beforeLoad 重定向到子页，不过滤会导致容器路径被记成一个 tab。
    return routesByPath?.[pathname as keyof FileRoutesByFullPath]?.options?.component;
  }, [pathname, router.routesByPath]);

  useEffect(() => {
    if (isUnRedirectPath) {
      addTab(href, { pathname, search: location.search, hash: location.hash }, matchRouteTabOption);
    }
  }, [href, pathname, location.search, location.hash, isUnRedirectPath, addTab, matchRouteTabOption]);

  useUpdateEffect(() => {
    if (activeTabKey === href) {
      return;
    }
    const route = tabRoutes[activeTabKey];
    if (!route) {
      return;
    }
    navigate({ to: route.pathname, search: route.search, hash: route.hash });
  }, [activeTabKey]);

  const switchRoute = (key: string) => {
    if (key === activeTabKey) {
      return;
    }
    setActiveTabKey(key);
  };

  const removeTabRoute: TabsProps["onEdit"] = (target, action) => {
    if (action === "add") {
      return;
    }
    removeTab(target as string);
  };

  return (
    <Tabs
      hideAdd
      type="editable-card"
      size="small"
      classNames={{
        item: cn("[&_.ant-tabs-tab-icon]:mr-1", styles["reset-tab-item"], {
          [styles["chrome-item"]]: tabsMode === "chrome",
          [styles["plain-item"]]: tabsMode === "plain",
          [styles["card-item"]]: tabsMode === "card",
          [styles["line-item"]]: tabsMode === "line",
        }),
        indicator: cn({ visible: tabsMode === "line" }),
        header: "mb-0",
      }}
      activeKey={activeTabKey}
      items={openTabs}
      onChange={switchRoute}
      onEdit={removeTabRoute}
      renderTabBar={(props, DefaultTabBar) => (
        <DefaultTabBar {...props}>
          {(node) => cloneElement(node, { "data-tabs-selected": node.key === href } as React.ComponentProps<"div">)}
        </DefaultTabBar>
      )}
      tabBarExtraContent={
        <div className="flex items-center gap-a-margin px-2">
          <ForceRefreshPage />
          <MaxContent />
          <MoreToolbar />
        </div>
      }
    />
  );
}
