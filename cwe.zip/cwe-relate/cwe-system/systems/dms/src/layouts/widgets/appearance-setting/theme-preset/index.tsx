import { ColorPicker } from "antd";
import type { ColorPickerProps } from "antd";
import { debounce } from "es-toolkit";
import { Palette } from "lucide-react";

import { useAppearanceSelector } from "@/store";
import { cn } from "@/utils/cn";

import OutlineBox from "../components/outline-box";
import { themeColorsPreset } from "./config";

export default function AppearanceThemePreset() {
  const { colorPrimary, setAppearance } = useAppearanceSelector(["colorPrimary", "setAppearance"]);

  const handleChangePresetColor = (color: string) => {
    setAppearance("colorPrimary", color);
  };

  const handleChangeCustomColor: ColorPickerProps["onChange"] = (color) => {
    setAppearance("colorPrimary", color.toHexString());
  };

  return (
    <ul className="flex w-full flex-wrap justify-between gap-y-3 p-0">
      {themeColorsPreset.map((item) => (
        <OutlineBox
          onClick={() => handleChangePresetColor(item.color)}
          isActive={item.color === colorPrimary}
          key={item.color}
          icon={<ColorBox bgColor={item.color} />}
          text={item.label}
        />
      ))}
      <ColorPicker value={colorPrimary} onChange={debounce(handleChangeCustomColor, 100)}>
        <OutlineBox icon={<Palette className="mx-9 size-5" />} text="自定义" />
      </ColorPicker>
    </ul>
  );
}

interface ColorBoxProps extends React.ComponentProps<"div"> {
  bgColor: string;
}

function ColorBox(props: ColorBoxProps) {
  const { bgColor, className, ...restProps } = props;

  return (
    <div
      {...restProps}
      style={{ backgroundColor: bgColor }}
      className={cn("mx-9 size-5 rounded-a-borderRadius", className)}
    />
  );
}
