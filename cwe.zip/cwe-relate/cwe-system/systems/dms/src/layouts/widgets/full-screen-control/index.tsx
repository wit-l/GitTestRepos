import { useFullscreen } from "ahooks";
import { Expand, Shrink } from "lucide-react";

import ToolbarButton from "../toolbar-button";

export default function FullScreenControl() {
  const [isFullscreen, { toggleFullscreen }] = useFullscreen(() => document.querySelector("html"));

  return <ToolbarButton icon={isFullscreen ? <Shrink /> : <Expand />} onClick={toggleFullscreen} />;
}
