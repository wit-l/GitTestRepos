import { UserOutlined } from "@ant-design/icons";
import { Avatar, Button } from "antd";

import { useUserAuthSelector } from "@/store";

export default function UserAvatar() {
  const { userInfo } = useUserAuthSelector(["userInfo"]);

  return (
    <Button
      shape="circle"
      type="text"
      icon={<Avatar icon={<UserOutlined />} src={userInfo?.photo?.fileURL || "/user-avatar.png"} />}
    />
  );
}
