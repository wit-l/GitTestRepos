import { Select } from "antd";

import { useAppearanceSelector } from "@/store";
import type { TabsMode } from "@/store/modules/appearance";

import SwitchItemWrapper from "../components/switch-item";

export default function AppearanceTabsModeSetting() {
  const { tabsMode, setAppearance } = useAppearanceSelector(["tabsMode", "setAppearance"]);

  const changeTabsMode = (value: TabsMode) => {
    setAppearance("tabsMode", value);
  };

  return (
    <SwitchItemWrapper>
      <span>标签页风格</span>
      <Select<TabsMode, { label: string; value: TabsMode }>
        className="w-2/5"
        options={[
          { label: "谷歌", value: "chrome" },
          { label: "朴素", value: "plain" },
          { label: "卡片", value: "card" },
          { label: "线条", value: "line" },
        ]}
        value={tabsMode}
        onChange={changeTabsMode}
      />
    </SwitchItemWrapper>
  );
}
