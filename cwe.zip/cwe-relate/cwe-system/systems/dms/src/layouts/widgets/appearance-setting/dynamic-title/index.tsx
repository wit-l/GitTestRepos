import { Switch, Tooltip } from "antd";
import { CircleQuestionMark } from "lucide-react";

import { useAppearanceSelector } from "@/store";

import SwitchItemWrapper from "../components/switch-item";

export default function AppearanceDynamicTitleSetting() {
  const { dynamicTitle, setAppearance } = useAppearanceSelector(["dynamicTitle", "setAppearance"]);

  const handleSwitchChange = (checked: boolean) => {
    setAppearance("dynamicTitle", checked);
  };

  const handleClickItemWrapper = () => {
    setAppearance("dynamicTitle", !dynamicTitle);
  };

  return (
    <SwitchItemWrapper onClick={handleClickItemWrapper}>
      <span>
        动态标题
        <Tooltip title="浏览器上方的标题">
          <CircleQuestionMark className="ml-1 text-xs" />
        </Tooltip>
      </span>
      <Switch className="min-w-10" checked={dynamicTitle} onChange={handleSwitchChange} />
    </SwitchItemWrapper>
  );
}
