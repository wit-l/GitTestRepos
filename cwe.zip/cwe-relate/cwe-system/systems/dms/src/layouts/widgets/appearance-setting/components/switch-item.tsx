import { cn } from "@/utils/cn";

interface SwitchItemWrapperProps extends React.ComponentProps<"div"> {
  children?: React.ReactNode;
}

export default function SwitchItemWrapper(props: SwitchItemWrapperProps) {
  const { className, ...restProps } = props;
  return (
    <div
      {...restProps}
      className={cn(
        "my-2 flex w-full items-center justify-between",
        "rounded-a-borderRadius px-2 py-3 transition-colors hover:bg-a-colorFillTertiary",
        className
      )}
    />
  );
}
