import { Switch } from "antd";

import { useAppearanceSelector } from "@/store";

import SwitchItemWrapper from "../components/switch-item";

export default function AppearancePageLoadingSetting() {
  const { transitionPageLoading, setAppearance } = useAppearanceSelector(["transitionPageLoading", "setAppearance"]);

  const handleSwitchChange = (checked: boolean) => {
    setAppearance("transitionPageLoading", checked);
  };

  const handleClickItemWrapper = () => {
    setAppearance("transitionPageLoading", !transitionPageLoading);
  };

  return (
    <SwitchItemWrapper onClick={handleClickItemWrapper}>
      <span>页面加载 Loading</span>
      <Switch className="min-w-10" checked={transitionPageLoading} onChange={handleSwitchChange} />
    </SwitchItemWrapper>
  );
}
