import { useLocation } from "@tanstack/react-router";
import { Dropdown } from "antd";
import type { MenuProps } from "antd";
import {
  ArrowLeftToLine,
  ArrowRightLeft,
  ArrowRightToLine,
  ExternalLink,
  FoldHorizontal,
  LayoutGrid,
  RotateCw,
  X,
} from "lucide-react";
import { useMemo } from "react";

import { clientEnv } from "@/config/env";
import { useTabsSelector } from "@/store/modules/tabs";

import { shareToolbarBtnStyle } from "./_share-style";

const ControlEnum = {
  CLOSE: "close",
  RELOAD: "reload",
  OPEN_NEW: "open-new",

  CLOSE_LEFT: "close-left",
  CLOSE_RIGHT: "close-right",
  CLOSE_OTHERS: "close-others",
  CLOSE_ALL: "close-all",
} as const;

type ControlEnumValueType = (typeof ControlEnum)[keyof typeof ControlEnum];

export default function MoreToolbar() {
  const { pathname, href } = useLocation({
    select: (location) => ({
      href: location.href,
      pathname: location.pathname,
    }),
  });

  const { openTabs, forceRefresh, removeTab, closeLeftTabs, closeRightTabs, closeOtherTabs, closeAllTabs } =
    useTabsSelector([
      "openTabs",
      "forceRefresh",
      "removeTab",
      "closeLeftTabs",
      "closeRightTabs",
      "closeOtherTabs",
      "closeAllTabs",
    ]);

  const handleClick: MenuProps["onClick"] = ({ key }) => {
    const handleFn: Record<ControlEnumValueType, () => void> = {
      [ControlEnum.CLOSE]: onClosePage,
      [ControlEnum.RELOAD]: forceRefresh,
      [ControlEnum.OPEN_NEW]: onOpenNewWindow,
      [ControlEnum.CLOSE_LEFT]: onCloseLeft,
      [ControlEnum.CLOSE_RIGHT]: onCloseRight,
      [ControlEnum.CLOSE_OTHERS]: onCloseOthers,
      [ControlEnum.CLOSE_ALL]: onCloseAll,
    };

    handleFn[key as ControlEnumValueType]();
  };

  function onClosePage() {
    removeTab(href);
  }

  function onCloseOthers() {
    closeOtherTabs(href);
  }

  function onCloseAll() {
    closeAllTabs();
  }

  function onCloseLeft() {
    closeLeftTabs(href);
  }

  function onCloseRight() {
    closeRightTabs(href);
  }

  function onOpenNewWindow() {
    const { hash, origin } = window.location;
    const url = `${origin}${hash && !pathname.startsWith("/#") ? "/#" : ""}${href}`;
    window.open(url, "_blank", "noopener=yes,noreferrer=yes");
  }

  const dropDownItems = useMemo(() => {
    const currentIndex = openTabs.findIndex((item) => item.key === href);
    const isFirst = currentIndex === 0;
    const isLast = currentIndex === openTabs.length - 1;

    return [
      { key: ControlEnum.CLOSE, label: "关闭", icon: <X />, disabled: pathname === clientEnv.BASE_URL },
      { key: ControlEnum.RELOAD, label: "重新加载", icon: <RotateCw /> },
      { key: ControlEnum.OPEN_NEW, label: "在新窗口打开", icon: <ExternalLink /> },
      { type: "divider" },
      { key: ControlEnum.CLOSE_LEFT, label: "关闭左侧标签页", icon: <ArrowLeftToLine />, disabled: isFirst },
      {
        key: ControlEnum.CLOSE_RIGHT,
        label: "关闭右侧标签页",
        icon: <ArrowRightToLine />,
        disabled: isLast,
      },
      { type: "divider" },
      { key: ControlEnum.CLOSE_OTHERS, label: "关闭其它标签页", icon: <FoldHorizontal /> },
      { key: ControlEnum.CLOSE_ALL, label: "关闭全部标签页", icon: <ArrowRightLeft /> },
    ] satisfies MenuProps["items"];
  }, [pathname, href, openTabs]);

  return (
    <Dropdown trigger={["click"]} placement="bottomRight" menu={{ items: dropDownItems, onClick: handleClick }}>
      <button type="button" className={shareToolbarBtnStyle}>
        <LayoutGrid />
      </button>
    </Dropdown>
  );
}
