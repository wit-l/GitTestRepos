import { Divider, Drawer, Segmented } from "antd";
import { Settings } from "lucide-react";
import { useState } from "react";

import ToolbarButton from "../toolbar-button";
import AppearanceAnimationSetting from "./animation";
import AppearanceDynamicTitleSetting from "./dynamic-title";
import AppearanceGrayModeSetting from "./gray-mode";
import AppearanceInvertModeSetting from "./invert-mode";
import AppearanceMultiLayoutSetting from "./multi-layout";
import AppearancePageLoadingSetting from "./page-loading";
import AppearanceProgressSetting from "./progress";
import AppearanceRadiusSetting from "./radius";
import AppearanceSizeSetting from "./size";
import AppearanceTabsModeSetting from "./tabs-mode";
import AppearanceThemeSetting from "./theme";
import AppearanceThemePreset from "./theme-preset";
import AppearanceVersionMonitorSetting from "./version-monitor";

const SegmentOptions = ["外观", "布局", "通用"];

export default function AppearanceSetting() {
  const [open, setOpen] = useState(false);
  const [segmentValue, setSegmentValue] = useState<string>("外观");

  const openDrawer = () => setOpen(true);
  const closeDrawer = () => setOpen(false);

  function renderCombineSetting() {
    if (segmentValue === "外观") {
      return (
        <>
          <Divider titlePlacement="start">主题</Divider>
          <AppearanceThemeSetting />
          <Divider titlePlacement="start">尺寸</Divider>
          <AppearanceSizeSetting />
          <Divider titlePlacement="start">内置主题</Divider>
          <AppearanceThemePreset />
          <Divider titlePlacement="start">圆角</Divider>
          <AppearanceRadiusSetting />
          <Divider titlePlacement="start">其它</Divider>
          <AppearanceGrayModeSetting />
          <AppearanceInvertModeSetting />
        </>
      );
    }

    if (segmentValue === "布局") {
      return (
        <>
          <Divider titlePlacement="start">布局</Divider>
          <AppearanceMultiLayoutSetting />
          <Divider titlePlacement="start">标签</Divider>
          <AppearanceTabsModeSetting />
        </>
      );
    }

    if (segmentValue === "通用") {
      return (
        <>
          <Divider titlePlacement="start">通用</Divider>
          <AppearanceDynamicTitleSetting />
          <AppearanceVersionMonitorSetting />
          <Divider titlePlacement="start">动画</Divider>
          <AppearanceProgressSetting />
          <AppearancePageLoadingSetting />
          <AppearanceAnimationSetting />
        </>
      );
    }
  }

  return (
    <>
      <ToolbarButton className="hidden md:inline-flex" icon={<Settings />} onClick={openDrawer} />
      <Drawer size={384} title="偏好设置" closable={{ placement: "end" }} open={open} onClose={closeDrawer}>
        <Segmented
          classNames={{ root: "w-full", item: "flex-1" }}
          options={SegmentOptions}
          value={segmentValue}
          onChange={setSegmentValue}
        />
        {renderCombineSetting()}
      </Drawer>
    </>
  );
}
