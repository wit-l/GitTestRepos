import { Switch } from "antd";

import { useAppearanceSelector } from "@/store";

import SwitchItemWrapper from "../components/switch-item";

export default function AppearanceProgressSetting() {
  const { transitionProgress, setAppearance } = useAppearanceSelector(["transitionProgress", "setAppearance"]);

  const handleSwitchChange = (checked: boolean) => {
    setAppearance("transitionProgress", checked);
  };

  const handleClickItemWrapper = () => {
    setAppearance("transitionProgress", !transitionProgress);
  };

  return (
    <SwitchItemWrapper onClick={handleClickItemWrapper}>
      <span>页面加载进度条</span>
      <Switch className="min-w-10" checked={transitionProgress} onChange={handleSwitchChange} />
    </SwitchItemWrapper>
  );
}
