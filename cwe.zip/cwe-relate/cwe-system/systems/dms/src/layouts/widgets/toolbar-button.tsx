import { Button } from "antd";
import type { ButtonProps } from "antd";

import { cn } from "@/utils/cn";

export default function ToolbarButton(props: ButtonProps) {
  const { className, classNames, ...restProps } = props;

  return (
    <Button
      shape="circle"
      type="text"
      className={cn("hover:animate-[shrink_0.25s_ease-in-out]", className)}
      classNames={{ ...classNames, icon: cn("text-a-fontSizeLG", (classNames as any)?.icon) }}
      {...restProps}
    />
  );
}
