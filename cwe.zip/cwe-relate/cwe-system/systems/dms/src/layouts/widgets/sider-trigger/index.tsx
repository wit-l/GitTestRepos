import { MenuFoldOutlined, MenuUnfoldOutlined } from "@ant-design/icons";
import { Button, theme as antTheme, ConfigProvider } from "antd";

import { useAppearanceSelector } from "@/store";

interface SiderTriggerProps {
  theme?: "light" | "dark";
}
export default function SiderTrigger(props: SiderTriggerProps) {
  const { theme } = props;
  const { collapsed, setAppearance } = useAppearanceSelector(["collapsed", "setAppearance"]);

  const handleCollapse = () => {
    setAppearance("collapsed", !collapsed);
  };

  const toolbarNode = (
    <Button
      type="text"
      classNames={{ icon: "text-a-fontSizeLG" }}
      icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
      onClick={handleCollapse}
    />
  );

  // 仅处理暗色主题下的按钮样式，因为仅 light 主题下的 Sider 才允许设置 dark mode
  // 暗色侧边情况下，按钮样式应符合全局的 dark 主题
  if (theme === "dark") {
    return <ConfigProvider theme={{ algorithm: [antTheme.darkAlgorithm] }}>{toolbarNode}</ConfigProvider>;
  }

  return toolbarNode;
}
