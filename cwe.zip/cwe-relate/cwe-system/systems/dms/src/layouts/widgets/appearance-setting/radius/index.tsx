import { Button } from "antd";

import { useAppearanceSelector } from "@/store";

const presetRadius = [0, 2, 4, 6, 8];

export default function AppearanceRadiusSetting() {
  const { borderRadius, setAppearance } = useAppearanceSelector(["borderRadius", "setAppearance"]);

  const handleChangeRadius = (value: number) => {
    setAppearance("borderRadius", value);
  };

  return (
    <div className="flex items-center justify-center gap-3">
      {presetRadius.map((item) => (
        <Button
          key={item}
          className="w-14 font-semibold"
          type={item === borderRadius ? "primary" : "default"}
          onClick={() => handleChangeRadius(item)}
        >
          {item}
        </Button>
      ))}
    </div>
  );
}
