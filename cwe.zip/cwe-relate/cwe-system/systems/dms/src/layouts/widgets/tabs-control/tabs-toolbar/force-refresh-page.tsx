import { RotateCw } from "lucide-react";

import { useTabsSelector } from "@/store";

import { shareToolbarBtnStyle } from "./_share-style";

export default function ForceRefreshPage() {
  const { forceRefresh } = useTabsSelector(["forceRefresh"]);

  return (
    <button type="button" className={shareToolbarBtnStyle} onClick={forceRefresh}>
      {<RotateCw />}
    </button>
  );
}
