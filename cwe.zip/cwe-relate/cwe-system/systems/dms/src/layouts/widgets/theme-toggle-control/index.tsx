import { Moon, Sun } from "lucide-react";
import { flushSync } from "react-dom";

import { useAppearanceSelector } from "@/store";

import ToolbarButton from "../toolbar-button";

export default function ThemeToggleControl() {
  const { theme, setAppearance } = useAppearanceSelector(["theme", "setAppearance"]);
  const isDark = theme === "auto" ? window.matchMedia("(prefers-color-scheme: dark)").matches : theme === "dark";

  function toggleTheme(event: React.MouseEvent<HTMLElement, MouseEvent>) {
    const supportViewTransition =
      !!document.startViewTransition && !window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (!supportViewTransition || !event) {
      return setAppearance("theme", isDark ? "light" : "dark");
    }

    const x = event.clientX;
    const y = event.clientY;
    const endRadius = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
    const transition = document.startViewTransition(() => {
      flushSync(() => {
        setAppearance("theme", isDark ? "light" : "dark");
      });
    });

    transition.ready.then(() => {
      const clipPath = [`circle(0px at ${x}px ${y}px)`, `circle(${endRadius}px at ${x}px ${y}px)`];
      document.documentElement.animate(
        {
          clipPath: isDark ? [...clipPath].toReversed() : clipPath,
        },
        {
          duration: 500,
          easing: "ease-in",
          fill: "forwards",
          pseudoElement: isDark ? "::view-transition-old(root)" : "::view-transition-new(root)",
        }
      );
    });
  }

  return (
    <>
      <style id="theme-view-transition">
        {`
        html.stop-transition * {
          transition: none !important;
        }
        ::view-transition-old(root),
        ::view-transition-new(root) {
          animation: none;
          mix-blend-mode: normal;
        }
        ::view-transition-old(root),
        .dark::view-transition-new(root) {
          z-index: 999999999;
        }
        ::view-transition-new(root),
        .dark::view-transition-old(root) {
          z-index: 1;
        }
      `}
      </style>
      <ToolbarButton icon={isDark ? <Sun /> : <Moon />} onClick={toggleTheme} />
    </>
  );
}
