// https://ant-design.antgroup.com/docs/spec/colors-cn
export const themeColorsPreset = [
  { color: "#1677ff", label: "默认" },
  { color: "#1890ff", label: "拂晓蓝" },
  { color: "#2f54eb", label: "极客蓝" },
  { color: "#f1212c", label: "薄暮" },
  { color: "#f7531c", label: "火山" },
  { color: "#f7ab14", label: "日暮" },
  { color: "#13bdbd", label: "明青" },
  { color: "#51c11a", label: "极光绿" },
  { color: "#13c2c2", label: "明青" },
  { color: "#722ed1", label: "酱紫" },
  { color: "#eb2f96", label: "法式洋红" },
];
