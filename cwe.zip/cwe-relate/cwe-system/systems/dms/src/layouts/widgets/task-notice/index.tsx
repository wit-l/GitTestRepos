import { Bell } from "lucide-react";

import ToolbarButton from "../toolbar-button";

export default function TaskNotice() {
  return (
    <ToolbarButton
      className="group hover:animate-none"
      icon={<Bell className="group-hover:animate-[wiggle_1s_both]" />}
    />
  );
}
