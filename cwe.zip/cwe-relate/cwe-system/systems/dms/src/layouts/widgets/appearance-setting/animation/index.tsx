import { Switch } from "antd";

import { useAppearanceSelector } from "@/store";
import type { TransitionName } from "@/store/modules/appearance";
import { cn } from "@/utils/cn";

import OutlineBox from "../components/outline-box";
import SwitchItemWrapper from "../components/switch-item";

const presetTransitionName: TransitionName[] = ["fade", "fade-slide", "fade-up", "fade-down"];

export default function AppearanceAnimationSetting() {
  const { transitionName, transitionPageSwitch, setAppearance } = useAppearanceSelector([
    "transitionName",
    "transitionPageSwitch",
    "setAppearance",
  ]);

  const handleChangePresetColor = (name: TransitionName) => {
    setAppearance("transitionName", name);
  };

  const handleSwitchChange = (checked: boolean) => {
    setAppearance("transitionPageSwitch", checked);
  };

  const handleClickItemWrapper = () => {
    setAppearance("transitionPageSwitch", !transitionPageSwitch);
  };

  return (
    <>
      <SwitchItemWrapper onClick={handleClickItemWrapper}>
        <span>页面切换动画</span>
        <Switch className="min-w-10" checked={transitionPageSwitch} onChange={handleSwitchChange} />
      </SwitchItemWrapper>

      {transitionPageSwitch && (
        <ul className="flex w-full flex-wrap justify-between gap-y-3 p-0">
          {presetTransitionName.map((item) => (
            <OutlineBox
              style={{ padding: "0.5rem" }}
              onClick={() => handleChangePresetColor(item)}
              isActive={item === transitionName}
              key={item}
              icon={<MotionBox text={item} className={`${item}-slow`} />}
            />
          ))}
        </ul>
      )}
    </>
  );
}

function MotionBox(props: React.ComponentProps<"div"> & { text: string }) {
  const { className, text, ...restProps } = props;

  return (
    <div
      {...restProps}
      className={cn("flex h-10 w-12 items-center justify-center rounded-md bg-colorFillSecondary text-xs", className)}
    >
      <span className="scale-75 text-center text-opacity-75">{text}</span>
    </div>
  );
}
