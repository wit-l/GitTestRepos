import { Switch } from "antd";
import { Moon, Sun, SunMoon } from "lucide-react";

import useDarkMode from "@/hooks/appearance/useDarkMode";
import useLayoutMode from "@/hooks/appearance/useLayoutMode";
import { useAppearanceSelector } from "@/store";

import OutlineBox from "../components/outline-box";
import SwitchItemWrapper from "../components/switch-item";

export default function AppearanceThemeSetting() {
  const { isTopLayout } = useLayoutMode();
  const isDarkMode = useDarkMode();
  const { theme, menuTheme, setAppearance } = useAppearanceSelector(["theme", "menuTheme", "setAppearance"]);

  const setLightTheme = () => setAppearance("theme", "light");
  const setDarkTheme = () => setAppearance("theme", "dark");
  const setSystemTheme = () => setAppearance("theme", "auto");

  const handleSwitchChange = (checked: boolean) => {
    setAppearance("menuTheme", checked ? "dark" : "light");
  };

  const handleClickItemWrapper = () => {
    if (isDarkMode || isTopLayout) {
      return;
    }
    setAppearance("menuTheme", menuTheme === "dark" ? "light" : "dark");
  };

  return (
    <>
      <ul className="flex justify-between p-0">
        <OutlineBox
          icon={<Sun className="mx-9 size-5" />}
          text="浅色"
          isActive={theme === "light"}
          onClick={setLightTheme}
        />
        <OutlineBox
          icon={<Moon className="mx-9 size-5" />}
          text="深色"
          isActive={theme === "dark"}
          onClick={setDarkTheme}
        />
        <OutlineBox
          icon={<SunMoon className="mx-9 size-5" />}
          text="跟随系统"
          isActive={theme === "auto"}
          onClick={setSystemTheme}
        />
      </ul>

      <SwitchItemWrapper className="mt-6" onClick={handleClickItemWrapper}>
        <span>深色侧边栏</span>
        <Switch
          disabled={isDarkMode || isTopLayout}
          className="min-w-10"
          checked={menuTheme === "dark"}
          onChange={handleSwitchChange}
        />
      </SwitchItemWrapper>
    </>
  );
}
