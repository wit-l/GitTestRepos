import { Tooltip } from "antd";
import { CircleQuestionMark } from "lucide-react";
import { createElement } from "react";

import { LayoutPresetMode } from "@/config/appearance";
import type { LayoutPresetModeType } from "@/config/appearance";
import { useAppearanceSelector } from "@/store";

import OutlineBox from "../components/outline-box";
import MixedNavIcon from "./icons/mixed-nav";
import SideNavIcon from "./icons/side-nav";
import TopNavIcon from "./icons/top-nav";
import TowColumnNavIcon from "./icons/two-column-nav";

interface ILayoutPreset {
  name: string;
  type: LayoutPresetModeType;
  tip?: string;
  element: React.ComponentType;
}

const layoutPreset: ILayoutPreset[] = [
  { name: "侧边导航", type: LayoutPresetMode.Side_Nav, element: SideNavIcon, tip: "菜单在侧边" },
  { name: "顶部导航", type: LayoutPresetMode.Top_Nav, element: TopNavIcon, tip: "菜单在顶部" },
  { name: "双列导航", type: LayoutPresetMode.Two_Column_Nav, element: TowColumnNavIcon, tip: "垂直双列菜单在侧边" },
  {
    name: "混合导航",
    type: LayoutPresetMode.Mixed_Nav,
    element: MixedNavIcon,
    tip: "一级导航在顶部，二级导航在侧边",
  },
];

export default function AppearanceMultiLayoutSetting() {
  const { layoutMode, setAppearance } = useAppearanceSelector(["layoutMode", "setAppearance"]);

  function handleChangeLayoutMode(mode: LayoutPresetModeType) {
    setAppearance("layoutMode", mode);
  }

  return (
    <ul className="flex w-full flex-wrap justify-around gap-x-4 gap-y-3 p-0">
      {layoutPreset.map((item) => (
        <OutlineBox
          key={item.type}
          className="py-1"
          isActive={layoutMode === item.type}
          onClick={() => handleChangeLayoutMode(item.type)}
          icon={createElement(item.element)}
          text={
            <>
              {item.name}
              <Tooltip title={item.tip} arrow={false}>
                <CircleQuestionMark className="ml-1.5 cursor-help" />
              </Tooltip>
            </>
          }
        />
      ))}
    </ul>
  );
}
