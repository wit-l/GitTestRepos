import { CloseOutlined, SearchOutlined } from "@ant-design/icons";
import { Link, useNavigate } from "@tanstack/react-router";
import { useDebounceFn, useKeyPress } from "ahooks";
import { Button, Input, Modal } from "antd";
import type { InputRef, MenuProps } from "antd";
import type { MenuItemType, SubMenuType } from "antd/es/menu/interface";
import { isString } from "es-toolkit";
import { ArrowDown, ArrowUp, CornerDownLeft, Search } from "lucide-react";
import { useRef, useState, useMemo, isValidElement, cloneElement } from "react";
import SimpleBar from "simplebar-react";

import { useUserAuthSelector } from "@/store";
import { cn } from "@/utils/cn";
import { isExternal } from "@/utils/is";

type MenuItem = Required<MenuProps>["items"][number];

function transformMenuToFlatMenu(menus: MenuItem[] = [], flatMap: MenuItem[] = []) {
  if (menus && menus.length === 0) {
    return [];
  }
  return menus.reduce((acc, cur) => {
    const shallowData = { ...cur } as SubMenuType<MenuItemType>;

    if (!shallowData.children) {
      acc.push(shallowData);
    }
    if (shallowData.children?.length > 0) {
      transformMenuToFlatMenu(shallowData.children, flatMap);
    }
    return acc;
  }, flatMap);
}

export default function SearchMenu() {
  const navigate = useNavigate();
  const { menus } = useUserAuthSelector(["menus"]);

  const [open, setOpen] = useState(false);
  const inputRef = useRef<InputRef>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  const [keyword, setKeyword] = useState<string>("");
  const [searchResult, setSearchResult] = useState<MenuItemType[]>([]);

  const flatMenus = useMemo(() => transformMenuToFlatMenu(menus), [menus]) as MenuItemType[];

  const { run: debounceSearch } = useDebounceFn(
    (e) => {
      const inputValue = e.target.value?.trim();
      setKeyword(inputValue);
      if (!inputValue) {
        setSearchResult([]);
        return;
      }

      setActiveIndex(0);
      setSearchResult(
        flatMenus.filter((item) => {
          let labelText = "";
          if (isValidElement(item.label) && "children" in (item.label.props as object)) {
            labelText = (item.label.props as any).children;
          } else if (isString(item.label)) {
            labelText = item.label;
          }
          return labelText.includes(inputValue);
        })
      );
    },
    {
      wait: 300,
    }
  );

  const openSearchModal = () => setOpen(true);

  const closeSearchModal = () => {
    setSearchResult([]);
    setKeyword("");
    setOpen(false);
  };

  const preFocusInput = (open: boolean) => {
    if (open) {
      inputRef.current?.focus();
    }
  };

  // ================== Switch Active Index ==================
  const handleHoverIndex = (index: number) => setActiveIndex(index);
  const handleFocusIndex = (index: number) => setActiveIndex(index);

  const handleEnterKey = (e: React.KeyboardEvent<HTMLLIElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      closeSearchModal();
    }
  };

  const handleKeyUp = () => {
    if (!open || searchResult.length === 0) {
      return;
    }
    setActiveIndex((prev) => (prev - 1 + searchResult.length) % searchResult.length);
  };

  const handleKeyDown = () => {
    if (!open || searchResult.length === 0) {
      return;
    }
    setActiveIndex((prev) => (prev + 1) % searchResult.length);
  };

  const handleEnter = () => {
    if (!open || searchResult.length === 0) {
      return;
    }
    const item = searchResult[activeIndex];
    if (!item) {
      return;
    }

    const key = item.key as string;
    if (isExternal(key)) {
      window.open(key, "_blank", "noopener,noreferrer");
    } else {
      navigate({ to: key });
    }
    closeSearchModal();
  };

  const handleShortcutKeyOpenModal = (e: KeyboardEvent) => {
    e.preventDefault(); // 阻止浏览器默认的 Ctrl+K
    if (!open) {
      setOpen(true);
    }
  };

  useKeyPress("uparrow", handleKeyUp);
  useKeyPress("downarrow", handleKeyDown);
  useKeyPress("enter", handleEnter);
  useKeyPress(["ctrl.k"], handleShortcutKeyOpenModal, { exactMatch: true });

  const renderSearchResultSection = () => {
    if (!keyword) {
      return <PlaceholderEmpty />;
    }
    if (searchResult.length === 0) {
      return <SearchEmpty keyword={keyword} />;
    }

    return (
      <ul className="m-0 flex flex-col gap-2 p-a-margin [&>li]:list-none">
        {searchResult.map((item, index) => {
          const key = item.key as string;
          const isExternalLink = isExternal(key);
          const linkClassName = cn(
            "flex w-full items-center justify-between",
            "px-a-marginSM py-a-margin text-inherit [&_svg]:text-a-fontSizeLG"
          );
          const linkContent = (
            <>
              <span>
                {item.icon && cloneElement(item.icon as React.ReactSVGElement, { className: "mr-1.5" })}
                {item.label}
              </span>
              <CornerDownLeft />
            </>
          );
          return (
            <li
              key={item.key}
              className={cn(
                "select-none rounded-a-borderRadius border border-a-colorBorderSecondary",
                "transition-colors [transition-property:background-color]", // transition
                "focus-within:right-2 focus-within:outline focus-within:ring-a-colorPrimary", // focus
                activeIndex === index ? "bg-a-colorPrimary text-white" : "" // active index
              )}
              onClick={closeSearchModal}
              onKeyDown={handleEnterKey}
              onFocus={() => handleFocusIndex(index)}
              onMouseMove={() => handleHoverIndex(index)}
            >
              <Link
                to={key}
                className={linkClassName}
                target={isExternalLink ? "_blank" : undefined}
                rel={isExternalLink ? "noopener noreferrer" : undefined}
              >
                {linkContent}
              </Link>
            </li>
          );
        })}
      </ul>
    );
  };

  return (
    <>
      <button
        onClick={openSearchModal}
        type="button"
        className={cn(
          "group flex h-8 cursor-pointer items-center justify-center gap-3",
          "rounded-full border-none outline-none transition-colors",
          "focus-visible:outline-[3px] focus-visible:outline-a-colorPrimaryBorder focus-visible:outline-offset-1", // tab 聚焦样式 和 antd Button 保持一致
          "px-2 py-0.5 text-a-colorTextSecondary text-a-fontSizeSM [&>svg]:text-a-fontSizeLG",
          "bg-transparent hover:bg-a-colorFillSecondary md:bg-a-colorFillTertiary" // 小屏：仅图标，大屏：背景色+类输入框样式
        )}
      >
        <Search />
        <span className="hidden md:block">搜索</span>
        <span
          className={cn(
            "bg-a-colorBgContainer px-1.5 py-1 group-hover:opacity-100",
            "hidden md:block", // Ctrl + K 仅大屏生效
            "rounded-sm rounded-r-xl"
          )}
        >
          Ctrl <kbd className="font-mono">K</kbd>
        </span>
      </button>

      <Modal
        open={open}
        onCancel={closeSearchModal}
        classNames={{ container: "p-0", header: "mb-0" }}
        afterOpenChange={preFocusInput}
        closeIcon={null}
        destroyOnHidden
        title={
          <div className="flex items-center gap-a-margin border-b p-a-margin">
            <Input
              ref={inputRef}
              variant="borderless"
              placeholder="搜索导航菜单"
              prefix={<SearchOutlined />}
              onInput={debounceSearch}
            />

            <Button size="small" shape="circle" type="text" icon={<CloseOutlined />} onClick={closeSearchModal} />
          </div>
        }
        footer={null}
      >
        <SimpleBar autoHide clickOnTrack={false} className="h-full min-h-40 sm:max-h-[450px]">
          {renderSearchResultSection()}
        </SimpleBar>
        <SearchPanelFooter />
      </Modal>
    </>
  );
}

function PlaceholderEmpty() {
  return <div className="pt-12 text-center text-a-fontSizeSM text-a-colorTextSecondary">暂无搜索结果</div>;
}

function SearchEmpty({ keyword }: { keyword?: string }) {
  return (
    <div className="pt-12 text-center text-a-colorTextSecondary">
      <span className="text-a-fontSizeSM">未找到搜索结果</span>{" "}
      <span className="text-a-fontSizeLG font-semibold">"{keyword}"</span>
    </div>
  );
}

function SearchPanelFooter() {
  return (
    <div className="flex items-center gap-4 border-t px-a-margin py-a-marginXS text-a-fontSizeSM">
      <div className="flex items-center gap-1">
        <CornerDownLeft />
        选择
      </div>
      <div className="flex items-center gap-1">
        <ArrowUp />
        <ArrowDown />
        导航
      </div>
      <div className="flex items-center gap-1">
        <span className="font-mono">ESC</span>
        关闭
      </div>
    </div>
  );
}
