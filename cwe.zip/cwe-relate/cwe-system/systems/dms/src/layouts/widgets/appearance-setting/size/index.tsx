import { Switch } from "antd";

import { useAppearanceSelector } from "@/store";

import SwitchItemWrapper from "../components/switch-item";

export default function AppearanceSizeSetting() {
  const { size, setAppearance } = useAppearanceSelector(["size", "setAppearance"]);

  const handleSwitchChange = (checked: boolean) => {
    setAppearance("size", checked ? "small" : "default");
  };

  const handleClickItemWrapper = () => {
    setAppearance("size", size === "small" ? "default" : "small");
  };

  return (
    <SwitchItemWrapper onClick={handleClickItemWrapper}>
      <span>紧凑主题</span>
      <Switch className="min-w-10" checked={size === "small"} onChange={handleSwitchChange} />
    </SwitchItemWrapper>
  );
}
