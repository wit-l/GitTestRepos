import { Maximize, Minimize } from "lucide-react";

import { useTabsSelector } from "@/store";

import { shareToolbarBtnStyle } from "./_share-style";

export default function MaxContent() {
  const { isMaximize, toggleMaximize } = useTabsSelector(["isMaximize", "toggleMaximize"]);

  return (
    <button type="button" className={shareToolbarBtnStyle} onClick={toggleMaximize}>
      {isMaximize ? <Minimize /> : <Maximize />}
    </button>
  );
}
