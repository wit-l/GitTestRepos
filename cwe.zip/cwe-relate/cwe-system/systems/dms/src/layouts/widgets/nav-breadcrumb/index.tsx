import { useLocation } from "@tanstack/react-router";
import { Breadcrumb } from "antd";
import type { BreadcrumbProps } from "antd";
import type { ItemType, MenuItemType, SubMenuType } from "antd/es/menu/interface";

import { useUserAuthSelector } from "@/store";

type BreadcrumbItems = NonNullable<BreadcrumbProps["items"]>;

const renderBreadcrumbItem = (node: MenuItemType): BreadcrumbItems[number] => ({
  title: (
    <>
      {node.icon && <span className="text-a-fontSizeLG">{node.icon}</span>}
      <span className="ml-1">{"label" in node ? (node.label as React.ReactNode) : null}</span>
    </>
  ),
});

function findBreadcrumbItemsByKey(menus: ItemType[], key: string): BreadcrumbItems {
  const walk = (nodes: ItemType[], chain: BreadcrumbItems = []): BreadcrumbItems | null => {
    for (const node of nodes) {
      if (!node) {
        continue;
      }
      // 拼接上一个 node 节点
      const next = [...chain, renderBreadcrumbItem(node as MenuItemType)];
      // 查到返回，查不到，查 children
      if (node.key === key) {
        return next;
      }
      if ((node as SubMenuType).children?.length) {
        const matchExist = walk((node as SubMenuType).children, next);
        if (matchExist) {
          return matchExist;
        }
      }
    }
    return null;
  };

  return walk(menus) ?? [];
}

export default function NavBreadcrumb() {
  const pathname = useLocation({ select: (location) => location.pathname });
  const { allRouteItems } = useUserAuthSelector(["allRouteItems"]);

  return (
    <Breadcrumb classNames={{ root: "flex items-center" }} items={findBreadcrumbItemsByKey(allRouteItems, pathname)} />
  );
}
