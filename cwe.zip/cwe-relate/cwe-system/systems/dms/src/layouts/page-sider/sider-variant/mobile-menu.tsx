import { useLocation } from "@tanstack/react-router";
import { Drawer } from "antd";
import { cloneElement, useCallback, useEffect, useMemo, useState } from "react";
import SimpleBar from "simplebar-react";

import { LAYOUT_HEADER_HEIGHT, LAYOUT_SIDER_WIDTH } from "@/config/constants";
import CoreMenu from "@/layouts/core/core-menu";
import useMenuDataConfig from "@/layouts/core/hooks/useMenuDataConfig";
import LogoTitle from "@/layouts/core/logo-title";
import { matchMenus } from "@/layouts/utils";
import { useUserAuthSelector } from "@/store";

interface MobileMenuProps {
  trigger?: React.JSX.Element;
}

export default function MobileMenu(props: MobileMenuProps) {
  const { trigger } = props;
  const { menus } = useUserAuthSelector(["menus"]);

  const pathname = useLocation({
    select: (location) => location.pathname,
  });

  const getCurrentRouteOpenKeys = useCallback(
    () => matchMenus(menus, pathname)?.map((item) => item?.key) as string[],
    [menus, pathname]
  );

  const { fullMenus } = useMenuDataConfig();
  const [open, setOpen] = useState(false);
  const [openKeys, setOpenKeys] = useState<string[]>(getCurrentRouteOpenKeys);

  const triggerDom = useMemo(() => {
    if (!trigger) {
      return null;
    }

    return cloneElement(trigger, {
      key: "trigger",
      ...trigger.props,
      onClick: (e: Event) => {
        setOpen(!open);
        trigger.props?.onClick?.(e);
      },
    });
  }, [trigger, open]);

  useEffect(() => {
    setOpenKeys(getCurrentRouteOpenKeys);
  }, [getCurrentRouteOpenKeys]);

  const closeDrawer = () => setOpen(false);

  return (
    <>
      {triggerDom}
      <Drawer
        open={open}
        title={null}
        closeIcon={null}
        classNames={{ body: "p-0" }}
        placement="left"
        size={LAYOUT_SIDER_WIDTH}
        onClose={closeDrawer}
      >
        <LogoTitle />
        <SimpleBar autoHide clickOnTrack={false} style={{ height: `calc(100% - ${LAYOUT_HEADER_HEIGHT}px)` }}>
          <CoreMenu mode="inline" items={fullMenus} openKeys={openKeys} onOpenChange={setOpenKeys} />
        </SimpleBar>
      </Drawer>
    </>
  );
}
