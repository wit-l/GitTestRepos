import { Grid } from "antd";

import useLayoutMode from "@/hooks/appearance/useLayoutMode";

import MixedMenu from "./sider-variant/mixed-menu";
import SideMenu from "./sider-variant/side-menu";
import TwoColumnMenu from "./sider-variant/two-column-menu";

export default function PageSider() {
  const { isSideLayout, isTopLayout, isTwoColumnLayout, isMixedLayout } = useLayoutMode();
  const { md } = Grid.useBreakpoint(); // >=768px true

  if (!md) {
    // 移动设备上的 Sider 在 Header 中控制
    return null;
  }

  if (isSideLayout) {
    return <SideMenu />;
  }
  if (isTopLayout) {
    // 顶部菜单无左侧 Sider
    return null;
  }
  if (isTwoColumnLayout) {
    return <TwoColumnMenu />;
  }
  if (isMixedLayout) {
    return <MixedMenu />;
  }
}
