import { useLocation, useNavigate } from "@tanstack/react-router";
import { Menu } from "antd";
import type { MenuProps } from "antd";
import type { MenuItemType, SubMenuType } from "antd/es/menu/interface";
import { useCallback, useEffect, useMemo, useState } from "react";
import SimpleBar from "simplebar-react";

import { LAYOUT_HEADER_HEIGHT } from "@/config/constants";
import CoreMenu from "@/layouts/core/core-menu";
import useMenuDataConfig from "@/layouts/core/hooks/useMenuDataConfig";
import useMenuTheme from "@/layouts/core/hooks/useMenuTheme";
import LogoTitle from "@/layouts/core/logo-title";
import { matchMenus } from "@/layouts/utils";
import { useAppearanceSelector, useTabsSelector, useUserAuthSelector } from "@/store";
import { cn } from "@/utils/cn";
import { isExternal } from "@/utils/is";

import { overrideFakeSideStyle } from "./_override-fake-side-style";
import SiderWrapper from "./_sider-wrapper";

export default function TwoColumnMenu() {
  const { theme, collapsed } = useAppearanceSelector(["theme", "collapsed"]);
  const { menus } = useUserAuthSelector(["menus"]);
  const { isMaximize } = useTabsSelector(["isMaximize"]);
  const mergedMenuTheme = useMenuTheme();
  const { secondaryMenus } = useMenuDataConfig();

  const hiddenSecondaryMenu = isMaximize || !secondaryMenus?.length;

  const pathname = useLocation({
    select: (location) => location.pathname,
  });
  const getCurrentRouteOpenKeys = useCallback(
    () =>
      matchMenus(menus, pathname)
        ?.map((item) => item?.key)
        // 二级菜单去掉首个一级菜单的 pathname
        .slice(1) as string[],
    [menus, pathname]
  );

  const [openKeys, setOpenKeys] = useState(getCurrentRouteOpenKeys);

  useEffect(() => {
    setOpenKeys(getCurrentRouteOpenKeys);
  }, [getCurrentRouteOpenKeys]);

  return (
    <div
      data-system-theme={theme}
      data-menu-theme={mergedMenuTheme}
      className={cn("flex h-full", overrideFakeSideStyle)}
    >
      <FirstColumnMenu isMaximize={isMaximize} />

      <SiderWrapper
        showExtraTriggerNode
        width={hiddenSecondaryMenu ? 0 : 210}
        collapsedWidth={hiddenSecondaryMenu ? 0 : undefined}
        // 双列收缩二级侧边时，右 border 置 0，否则会有 2px border-right
        className={cn({ "border-r-0": hiddenSecondaryMenu })}
        // 二级菜单收缩时不展示标题
        headerNode={<LogoTitle showLogo={false} showTitle={!collapsed} />}
      >
        <CoreMenu mode="inline" items={secondaryMenus} openKeys={openKeys} onOpenChange={setOpenKeys} />
      </SiderWrapper>
    </div>
  );
}

interface FirstColumnMenuProps {
  isMaximize: boolean;
}

function FirstColumnMenu(props: FirstColumnMenuProps) {
  const { isMaximize } = props;

  const { menus } = useUserAuthSelector(["menus"]);
  const pathname = useLocation({
    select: (location) => location.pathname,
  });
  const selectedKey = useMemo(() => matchMenus(menus, pathname)?.[0]?.key as string, [menus, pathname]);

  const navigate = useNavigate();
  const handleSelectMenu: MenuProps["onSelect"] = ({ key }) => {
    if (isExternal(key)) {
      window.open(key, "_blank", "noopener,noreferrer");
      return;
    }
    navigate({ to: key });
  };

  const topLevelMenus = menus?.map((item) => {
    // 一级菜单只取第一级路由，不包含子菜单
    // 移除子菜单，仅保留一级菜单项
    const { children: _children, ...topLevelItem } = item as SubMenuType;
    return topLevelItem as MenuItemType;
  });

  const mergedMenuTheme = useMenuTheme();

  return (
    <aside
      className={cn(
        "h-full overflow-hidden border-r transition-[width] duration-200",
        isMaximize ? "w-0" : "w-20",
        mergedMenuTheme === "dark" ? "border-r-white/30" : "border-r-a-colorBorderSecondary"
      )}
    >
      <LogoTitle showTitle={false} />
      <SimpleBar autoHide clickOnTrack={false} style={{ height: `calc(100% - ${LAYOUT_HEADER_HEIGHT}px)` }}>
        <Menu
          mode="vertical"
          theme={mergedMenuTheme}
          items={topLevelMenus}
          tooltip={false}
          selectedKeys={[selectedKey]}
          onSelect={handleSelectMenu}
          classNames={{
            root: cn("overflow-y-auto overflow-x-hidden border-r-0"),
            item: cn(
              "gap-a-marginXS flex flex-col justify-center items-center h-16",
              "[&.ant-menu-item-selected]:bg-a-colorPrimary [&.ant-menu-item-selected]:text-white"
            ),
            itemContent: "leading-none m-0 text-a-fontSizeSM",
            itemIcon: "text-a-fontSizeLG",
          }}
        />
      </SimpleBar>
    </aside>
  );
}
