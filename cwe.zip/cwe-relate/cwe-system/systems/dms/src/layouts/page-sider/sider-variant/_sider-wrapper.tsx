import { Layout } from "antd";
import type { SiderProps } from "antd";
import SimpleBar from "simplebar-react";

import { LAYOUT_HEADER_HEIGHT, MENU_EXTRA_HEIGHT } from "@/config/constants";
import useMenuTheme from "@/layouts/core/hooks/useMenuTheme";
import { useAppearanceSelector } from "@/store";
import { cn } from "@/utils/cn";

import { SiderTrigger } from "../../widgets";
import { overrideFakeSideStyle } from "./_override-fake-side-style";

const { Sider } = Layout;

interface SiderWrapperProps extends SiderProps {
  /**
   * @description 是否显示 Menu 下方的 TriggerNode。**需预留出 Trigger 的高度（MENU_EXTRA_HEIGHT）**
   * @default false
   */
  showExtraTriggerNode?: boolean;
  headerNode?: React.ReactNode;
}

export default function SiderWrapper(props: SiderWrapperProps) {
  const { showExtraTriggerNode, headerNode, children, className, ...restProps } = props;

  const { collapsed, theme, setAppearance } = useAppearanceSelector(["collapsed", "theme", "setAppearance"]);
  const mergedMenuTheme = useMenuTheme();

  const setCollapsed = (newCollapsed: boolean) => {
    setAppearance("collapsed", newCollapsed);
  };

  const scrollHeight = showExtraTriggerNode ? LAYOUT_HEADER_HEIGHT + MENU_EXTRA_HEIGHT : LAYOUT_HEADER_HEIGHT;

  return (
    <Sider
      data-system-theme={theme}
      data-menu-theme={mergedMenuTheme}
      collapsible
      trigger={null}
      className={cn("overflow-hidden border-r border-r-a-colorBorderSecondary", overrideFakeSideStyle, className)}
      breakpoint="lg"
      collapsed={collapsed}
      onCollapse={setCollapsed}
      onBreakpoint={setCollapsed}
      {...restProps}
    >
      {headerNode}
      <SimpleBar autoHide clickOnTrack={false} style={{ height: `calc(100% - ${scrollHeight}px)` }}>
        {children}
      </SimpleBar>
      {showExtraTriggerNode && (
        <div style={{ height: MENU_EXTRA_HEIGHT }} className="flex items-center justify-end p-a-marginXXS">
          <SiderTrigger theme={mergedMenuTheme} />
        </div>
      )}
    </Sider>
  );
}
