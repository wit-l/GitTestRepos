import { cn } from "@/utils/cn";

// 重写 Sider 的背景色
export const overrideFakeSideStyle = cn(
  // 默认情况下，sider 背景色跟随 Menu 的主题色走
  "bg-[var(--menu-bg)]",
  /* 亮色主题下允许设置 Menu 的主题色，但是 menu 为 dark 时，需单独处理 */
  /* 暗色主题下，Menu 主题色始终为 light，因此不需要设置亮色主题下的 dark Menu */
  "[&:not([data-system-theme='dark'])[data-menu-theme='dark']]:bg-[var(--menu-dark-bg)]"
);
