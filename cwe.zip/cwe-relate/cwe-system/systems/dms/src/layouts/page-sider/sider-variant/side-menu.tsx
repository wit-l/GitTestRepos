import { useLocation } from "@tanstack/react-router";
import { useUpdateEffect } from "ahooks";
import { useCallback, useEffect, useState } from "react";

import { LAYOUT_SIDER_WIDTH } from "@/config/constants";
import CoreMenu from "@/layouts/core/core-menu";
import useMenuDataConfig from "@/layouts/core/hooks/useMenuDataConfig";
import LogoTitle from "@/layouts/core/logo-title";
import { matchMenus } from "@/layouts/utils";
import { useAppearanceSelector, useTabsSelector, useUserAuthSelector } from "@/store";

import SiderWrapper from "./_sider-wrapper";

export default function SideMenu() {
  const { menus } = useUserAuthSelector(["menus"]);

  const pathname = useLocation({
    select: (location) => location.pathname,
  });
  const getCurrentRouteOpenKeys = useCallback(
    () => matchMenus(menus, pathname)?.map((item) => item?.key) as string[],
    [menus, pathname]
  );
  const [openKeys, setOpenKeys] = useState<string[]>(getCurrentRouteOpenKeys);

  useEffect(() => {
    setOpenKeys(getCurrentRouteOpenKeys);
  }, [getCurrentRouteOpenKeys]);

  const { collapsed } = useAppearanceSelector(["collapsed"]);
  const { isMaximize } = useTabsSelector(["isMaximize"]);

  useUpdateEffect(() => {
    // 当菜单从展开变成收缩再展开时，openKeys 会被置空，因此当 collapsed 展开时, 需重新设置 openKeys
    if (!collapsed) {
      setOpenKeys(getCurrentRouteOpenKeys);
    }
  }, [collapsed]);

  const { fullMenus } = useMenuDataConfig();

  return (
    <SiderWrapper
      width={isMaximize ? 0 : LAYOUT_SIDER_WIDTH}
      collapsedWidth={isMaximize ? 0 : undefined}
      headerNode={<LogoTitle showTitle={!collapsed} />}
    >
      <CoreMenu mode="inline" items={fullMenus} openKeys={openKeys} onOpenChange={setOpenKeys} />
    </SiderWrapper>
  );
}
