import { useLocation } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";

import { LAYOUT_SIDER_WIDTH } from "@/config/constants";
import CoreMenu from "@/layouts/core/core-menu";
import useMenuDataConfig from "@/layouts/core/hooks/useMenuDataConfig";
import LogoTitle from "@/layouts/core/logo-title";
import { matchMenus } from "@/layouts/utils";
import { useAppearanceSelector, useTabsSelector, useUserAuthSelector } from "@/store";

import SiderWrapper from "./_sider-wrapper";

export default function MixedMenu() {
  const { collapsed } = useAppearanceSelector(["collapsed"]);
  const { isMaximize } = useTabsSelector(["isMaximize"]);
  const { menus } = useUserAuthSelector(["menus"]);
  const { secondaryMenus } = useMenuDataConfig();

  const hiddenSecondaryMenu = isMaximize || !secondaryMenus?.length;

  const pathname = useLocation({
    select: (location) => location.pathname,
  });
  const getCurrentRouteOpenKeys = useCallback(
    () => matchMenus(menus, pathname)?.map((item) => item?.key) as string[],
    [menus, pathname]
  );

  const [openKeys, setOpenKeys] = useState(getCurrentRouteOpenKeys);

  useEffect(() => {
    setOpenKeys(getCurrentRouteOpenKeys);
  }, [getCurrentRouteOpenKeys]);

  return (
    <SiderWrapper
      showExtraTriggerNode
      width={hiddenSecondaryMenu ? 0 : LAYOUT_SIDER_WIDTH}
      collapsedWidth={isMaximize ? 0 : undefined}
      headerNode={<LogoTitle showTitle={!collapsed} />}
    >
      <CoreMenu mode="inline" items={secondaryMenus} openKeys={openKeys} onOpenChange={setOpenKeys} />
    </SiderWrapper>
  );
}
