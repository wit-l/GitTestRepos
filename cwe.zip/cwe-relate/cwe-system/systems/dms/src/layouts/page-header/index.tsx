import { useLocation } from "@tanstack/react-router";
import { Grid, Layout, Space } from "antd";
import { List } from "lucide-react";

import useLayoutMode from "@/hooks/appearance/useLayoutMode";
import CoreMenu from "@/layouts/core/core-menu";
import LogoTitle from "@/layouts/core/logo-title";
import { useTabsSelector, useUserAuthSelector } from "@/store";
import { cn } from "@/utils/cn";

import useMenuDataConfig from "../core/hooks/useMenuDataConfig";
import MobileMenu from "../page-sider/sider-variant/mobile-menu";
import { matchMenus } from "../utils";
import {
  AppearanceSetting,
  FullScreenControl,
  NavBreadcrumb,
  SearchMenu,
  SiderTrigger,
  TabsControl,
  TaskNotice,
  ThemeToggleControl,
  UserAvatar,
} from "../widgets";
import ToolbarButton from "../widgets/toolbar-button";

const { Header } = Layout;

/**
 * @description 聚合多布局的 Header
 * - 由于动态 render 不同 Header 布局会导致 SettingDrawer 销毁，因此不能分情况渲染
 * ```jsx
 * // 错误写法示例：使用主题设置切换布局会直接导致 Drawer 卸载
 * if(mixed) return <MixedHeader/>
 * if(side) return <SideHeader/>
 * ```
 */
export default function PageHeader() {
  const { isSideLayout, isTopLayout, isTwoColumnLayout, isMixedLayout } = useLayoutMode();
  const { isMaximize } = useTabsSelector(["isMaximize"]);
  const { menus } = useUserAuthSelector(["menus"]);
  const { fullMenus, topLevelMenus } = useMenuDataConfig();
  const { md } = Grid.useBreakpoint();

  const pathname = useLocation({
    select: (location) => location.pathname,
  });

  function renderHeaderNode() {
    if (!md) {
      return (
        <Space>
          <MobileMenu trigger={<ToolbarButton type="text" icon={<List />} />} />
          <LogoTitle showTitle={false} classNames={{ root: "px-0" }} />
        </Space>
      );
    }

    if (isSideLayout) {
      return (
        // Space 组件无法让 trigger 和 breadcrumb 垂直对齐
        // 结合 NavBreadcrumb 对 root 的样式修改，两边结合使用才实现了对齐效果
        <div className="flex gap-a-margin">
          <SiderTrigger />
          <NavBreadcrumb />
        </div>
      );
    }

    if (isTwoColumnLayout) {
      return (
        <Space>
          <NavBreadcrumb />
        </Space>
      );
    }

    if (isTopLayout) {
      return (
        // overflow-hidden + w-full 确保 menu 拥有足够的宽度进行响应式调整
        <div className="flex w-full gap-a-marginXS overflow-hidden">
          <LogoTitle classNames={{ title: "!text-a-colorText" }} />
          <CoreMenu items={fullMenus} mode="horizontal" />
        </div>
      );
    }

    if (isMixedLayout) {
      // 截取一级路由项作为 menu selectedKeys
      const topLevelSelectedKey = (matchMenus(menus, pathname)?.[0]?.key || "") as string;
      return (
        <div className="w-full overflow-hidden">
          <CoreMenu items={topLevelMenus} mode="horizontal" theme="light" selectedKeys={[topLevelSelectedKey]} />
        </div>
      );
    }
  }

  return (
    <div className="sticky top-0 z-10">
      <Header
        style={isMaximize ? { height: 0 } : undefined}
        className={cn(
          "flex items-center overflow-hidden px-4 py-0",
          "border-b border-b-a-colorBorderSecondary bg-a-colorBgContainer",
          "transition-[height] duration-200"
        )}
      >
        <div className="flex w-full justify-between">
          {renderHeaderNode()}
          <div className="flex flex-shrink-0 items-center gap-a-marginXS">
            <SearchMenu />
            <AppearanceSetting />
            <ThemeToggleControl />
            <FullScreenControl />
            <TaskNotice />
            <UserAvatar />
          </div>
        </div>
      </Header>

      <div className="border-b-a-colorBorderSecondary bg-a-colorBgContainer">
        <TabsControl />
      </div>
    </div>
  );
}
