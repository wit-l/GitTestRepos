import { useLocation, useNavigate } from "@tanstack/react-router";
import { Menu } from "antd";
import type { MenuProps } from "antd";
import { merge } from "es-toolkit";
import { useEffect, useState } from "react";

import { cn } from "@/utils/cn";
import { isExternal } from "@/utils/is";

import useMenuTheme from "./hooks/useMenuTheme";

interface CoreMenuProps extends MenuProps {
  /**
   * @description 是否对 Menu 的选中色进行优化
   * @default false
   */
  enableOptimizedSelectedColor?: boolean;
}

export default function CoreMenu(props: CoreMenuProps) {
  const { enableOptimizedSelectedColor = false, classNames = {}, ...restProps } = props;
  const { pathname } = useLocation();
  const [selectedKey, setSelectedKey] = useState<string>(() => pathname);

  useEffect(() => {
    setSelectedKey(pathname);
  }, [pathname]);

  const navigate = useNavigate();

  const handleSelectMenu: MenuProps["onSelect"] = ({ key }) => {
    if (isExternal(key)) {
      window.open(key, "_blank", "noopener,noreferrer");
      return;
    }
    setSelectedKey(key);
    navigate({ to: key });
  };

  const mergedMenuTheme = useMenuTheme();
  const innerClassNames: MenuProps["classNames"] = enableOptimizedSelectedColor
    ? {
        // 优化 Menu 的选中背景色，用 cn 函数是为了有代码提示
        item: cn(mergedMenuTheme === "light" ? "[&.ant-menu-item-selected]:bg-a-colorPrimary/15" : ""),
        subMenu: {
          item: cn(mergedMenuTheme === "light" ? "[&.ant-menu-item-selected]:bg-a-colorPrimary/15" : ""),
        },
      }
    : undefined;

  return (
    <Menu
      theme={mergedMenuTheme}
      classNames={merge(
        {
          // 顶部布局下需要 https://ant-design.antgroup.com/components/menu-cn#faq-flex-layout
          root: "min-w-0 flex-auto border-r-0",
          ...innerClassNames,
        },
        classNames
      )}
      selectedKeys={[selectedKey]}
      onSelect={handleSelectMenu}
      {...restProps}
    />
  );
}
