import { Link } from "@tanstack/react-router";

import { LAYOUT_HEADER_HEIGHT } from "@/config/constants";
import { clientEnv } from "@/config/env";
import { useAppearanceSelector } from "@/store";
import { cn } from "@/utils/cn";

interface LogoTitleProps {
  /**
   * @description 是否展示logo
   * @default true
   */
  showLogo?: boolean;
  /**
   * @description 是否展示标题
   * @default true
   */
  showTitle?: boolean;
  classNames?: {
    root?: string;
    logo?: string;
    title?: string;
  };
  styles?: {
    root?: React.CSSProperties;
    logo?: React.CSSProperties;
    title?: React.CSSProperties;
  };
}

export default function LogoTitle(props: LogoTitleProps) {
  const { showLogo = true, showTitle = true, classNames, styles } = props;
  const { menuTheme } = useAppearanceSelector(["menuTheme"]);

  return (
    <div
      className={cn("flex items-center justify-center px-3 py-4", classNames?.root)}
      style={{ height: LAYOUT_HEADER_HEIGHT, ...styles?.root }}
    >
      <Link preload={false} to="/" className="flex items-center justify-center gap-2">
        {showLogo && (
          <img
            src="/logo.png"
            alt="Logo"
            className={cn("w-16 object-contain", classNames?.logo)}
            style={styles?.logo}
          />
        )}
        {showTitle && (
          <h1
            className={cn(
              "m-0 line-clamp-1 text-a-fontSizeLG opacity-100 font-semibold",
              menuTheme === "dark" ? "text-white/85" : "text-a-colorText",
              classNames?.title
            )}
            style={styles?.title}
          >
            {clientEnv.VITE_APP_TITLE}
          </h1>
        )}
      </Link>
    </div>
  );
}
