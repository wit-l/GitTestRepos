import type { ItemType, MenuItemType, SubMenuType } from "antd/es/menu/interface";
import { House } from "lucide-react";
import { createElement } from "react";

import { clientEnv } from "@/config/env";
import { menuIcons } from "@/config/menu-icons";
import type { IMenuItem } from "@/services/apis/login/type";
import { isExternal } from "@/utils/is";

export type MenuIconMap = Record<string, React.ElementType>;

const orderByWeight = (a: IMenuItem, b: IMenuItem) =>
  (a.weight ?? Number.POSITIVE_INFINITY) - (b.weight ?? Number.POSITIVE_INFINITY);

function resolveIcon(iconKey: string | null | undefined): React.ReactNode {
  if (!iconKey) {
    return undefined;
  }
  const Icon = menuIcons[iconKey];
  return Icon ? createElement(Icon) : undefined;
}

// 保留以 /、http://、https:// 开头的 path（例如 “数据归集管理” 的 path 是 2222，属于不规范测试数据）
const isValidPath = (path?: string) => !!path && (path.startsWith("/") || isExternal(path));
// 侧边栏渲染：必须可见（isShow === 0）
const isMenuVisible = (n: IMenuItem) => n.type === 0 && n.isShow === 0 && isValidPath(n.path);
// 访问控制：只判定是否为合法路由节点；isShow === 1 表示不在菜单展示但仍可访问（如详情页）
const isAccessibleRoute = (n: IMenuItem) => n.type === 0 && isValidPath(n.path);

function nodeToItem(node: IMenuItem, predicate: (n: IMenuItem) => boolean): ItemType {
  const visibleChildren = (node.children ?? []).filter(predicate).toSorted(orderByWeight);

  const base: MenuItemType = {
    key: node.path,
    label: node.name,
    icon: resolveIcon(node.icon),
  };

  if (visibleChildren.length === 0) {
    return base;
  }

  return {
    ...base,
    children: visibleChildren.map((child) => nodeToItem(child, predicate)),
  } as SubMenuType;
}

const HOME_MENU_ITEM: MenuItemType = {
  key: clientEnv.BASE_URL,
  label: "首页",
  icon: createElement(House),
};

/**
 * @description 把后端菜单树转换为 antd Menu 可消费的 items。
 */
export function convertBackendMenuToItems(backendMenu: IMenuItem[]): ItemType[] {
  const items = backendMenu
    .filter(isMenuVisible)
    .toSorted(orderByWeight)
    .map((n) => nodeToItem(n, isMenuVisible));

  return [HOME_MENU_ITEM, ...items];
}

/**
 * @description 与 `convertBackendMenuToItems` 类似，但保留 `isShow === 1` 的节点（仍可访问，仅不在侧边栏渲染）。
 *
 * 用于 Tab、Breadcrumb 等基于路径反查标题/图标的场景，确保非菜单路由也能正确显示。
 */
export function convertBackendMenuToAllItems(backendMenu: IMenuItem[]): ItemType[] {
  const items = backendMenu
    .filter(isAccessibleRoute)
    .toSorted(orderByWeight)
    .map((n) => nodeToItem(n, isAccessibleRoute));

  return [HOME_MENU_ITEM, ...items];
}

/**
 * @description 收集所有可访问的路由节点 path
 */
export function collectPermissionMenuPaths(backendMenu: IMenuItem[]): Set<string> {
  const result = new Set<string>();
  const walk = (nodes: IMenuItem[]) => {
    for (const n of nodes) {
      if (isAccessibleRoute(n)) {
        result.add(n.path);
      }
      if (n.children?.length) {
        walk(n.children);
      }
    }
  };
  walk(backendMenu);
  return result;
}

/**
 * @description 收集所有按钮权限节点（type === 1）的权限码
 */
export function collectButtonPermissions(backendMenu: IMenuItem[]): string[] {
  const result: string[] = [];
  const walk = (nodes: IMenuItem[]) => {
    for (const n of nodes) {
      if (n.type === 1) {
        // permission 后端暂时没用到，用的是 path 控制的按钮权限
        const roleCode = typeof n.permission === "string" ? n.permission : n.path;
        if (roleCode) {
          result.push(roleCode);
        }
      }
      if (n.children?.length) {
        walk(n.children);
      }
    }
  };
  walk(backendMenu);
  return result;
}
