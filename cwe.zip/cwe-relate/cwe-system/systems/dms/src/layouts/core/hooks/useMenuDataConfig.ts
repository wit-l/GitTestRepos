import { useLocation } from "@tanstack/react-router";
import type { ItemType, MenuItemType, SubMenuType } from "antd/es/menu/interface";
import { useMemo } from "react";

import { matchMenus } from "@/layouts/utils";
// import { LAYOUT_ROOT_ID } from "@/config/constants";
import { useUserAuthSelector } from "@/store";

interface UseMenuDataReturn {
  fullMenus?: ItemType[];
  /** 一级菜单 */
  topLevelMenus?: ItemType[];
  /** 二级菜单，根据当前路由匹配对应的二级菜单 */
  secondaryMenus?: ItemType[];
}

export default function useMenuDataConfig(): UseMenuDataReturn {
  const { menus } = useUserAuthSelector(["menus"]);

  const topLevelMenus = useMemo(
    () =>
      menus?.map((item) => {
        // 一级菜单只取第一级路由，不包含子菜单
        // 移除子菜单，仅保留一级菜单项
        const { children: _children, ...topLevelItem } = item as SubMenuType;
        return topLevelItem as MenuItemType;
      }),
    [menus]
  );

  const { pathname } = useLocation();

  const secondaryMenus = useMemo(() => {
    const ancestors = matchMenus(menus, pathname);
    // 当前的一级菜单路由
    const selectedKey = ancestors?.[0]?.key;
    // 根据一级菜单查找对应的二级菜单
    return (menus as SubMenuType[])?.find((item) => item.key === selectedKey)?.children;
  }, [pathname, menus]);

  return {
    fullMenus: menus,
    topLevelMenus,
    secondaryMenus,
  };
}
