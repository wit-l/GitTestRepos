import type { MenuTheme } from "antd";
import { useMemo } from "react";

import useDarkMode from "@/hooks/appearance/useDarkMode";
import useLayoutMode from "@/hooks/appearance/useLayoutMode";
import { useAppearanceSelector } from "@/store";

export default function useMenuTheme(): MenuTheme {
  const { isTopLayout } = useLayoutMode();
  const isDark = useDarkMode();
  const { menuTheme } = useAppearanceSelector(["menuTheme", "theme"]);

  return useMemo(() => {
    // 顶部导航下，Menu 始终为 light 模式
    if (isTopLayout) {
      return "light";
    }
    // 暗色模式下，菜单始终为 light，不允许切换 dark 色
    return isDark ? "light" : menuTheme;
  }, [menuTheme, isTopLayout, isDark]);
}
