import styles from "./style.module.css";

const compatBrowserVersionList = [
  { title: "IE/Edge", version: "Edge >= 99", img: "/edge_48x48.png" },
  { title: "Chrome", version: "Chrome >= 99", img: "/chrome_48x48.png" },
  { title: "Firefox", version: "Firefox >= 97", img: "/firefox_48x48.png" },
  { title: "Safari", version: "Safari >= 15.4", img: "/safari_48x48.png" },
];

export default function LegacyBrowserAlert() {
  return (
    <div className={styles["legacy-alert"]}>
      <h1 className={styles["alert-title"]}>
        当前浏览器可能不支持此系统的使用，推荐使用以下浏览器或升级您的浏览器版本内核
      </h1>
      <table>
        <thead>
          <tr>
            {compatBrowserVersionList.map((item) => (
              <th key={item.title}>
                <img src={item.img} alt={item.title} width="24" height="24" />
                <br />
                {item.title}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr>
            {compatBrowserVersionList.map((item) => (
              <td key={item.title}>{item.version}</td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
