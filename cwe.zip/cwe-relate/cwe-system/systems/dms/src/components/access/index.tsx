import { useAccess } from "@/hooks/useAccess";

interface AccessProps {
  children?: React.ReactNode;
  permission?: string | string[];
}

export default function Access(props: AccessProps) {
  const { children, permission } = props;
  const hasAccess = useAccess(permission);

  if (hasAccess) {
    return children;
  }

  return null;
}
