import { App } from "antd";
import GlobalAntdCssVar from "tailwind-preset-antd/components";

import { StaticAntd } from "./staticAntd";

interface AntdAppProps {
  children: React.ReactNode;
}

export default function AntdApp(props: AntdAppProps) {
  return (
    <App className="h-full">
      <GlobalAntdCssVar />
      <StaticAntd />
      {props.children}
    </App>
  );
}
