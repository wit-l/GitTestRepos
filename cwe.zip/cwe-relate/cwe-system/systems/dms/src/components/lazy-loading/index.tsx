import styles from "./style.module.css";

export default function LazyLoading() {
  return (
    <div className="flex h-full flex-col items-center justify-center">
      <div className={styles["square-jelly-box"]}>
        <div></div>
        <div></div>
      </div>
    </div>
  );
}
