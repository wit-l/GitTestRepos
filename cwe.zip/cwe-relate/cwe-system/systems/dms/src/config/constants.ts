// export const LAYOUT_ROOT_ID = "root" as const;

export const LAYOUT_HEADER_HEIGHT = 56 as const;
export const LAYOUT_SIDER_WIDTH = 240 as const;
export const MENU_EXTRA_HEIGHT = 40 as const;
