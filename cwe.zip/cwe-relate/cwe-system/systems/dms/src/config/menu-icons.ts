import {
  BookA,
  BookAlert,
  BookAudio,
  BookCheck,
  BookUser,
  Boxes,
  CircleDollarSign,
  Columns3Cog,
  Component,
  Database,
  DatabaseZap,
  Earth,
  Group,
  Hospital,
  Landmark,
  Languages,
  Layers,
  LayersPlus,
  LayoutDashboard,
  Link,
  Link2Off,
  LocateFixed,
  Logs,
  MapPinMinus,
  MapPinPlus,
  MapPlus,
  Menu,
  MessageSquareText,
  MonitorCog,
  Navigation,
  Network,
  NotepadText,
  Package,
  ReceiptText,
  Rotate3d,
  Route,
  RulerDimensionLine,
  ShieldCog,
  ShipWheel,
  UserCog,
  UserKey,
  UserRound,
  Users,
  Vault,
  VectorSquare,
} from "lucide-react";

import type { MenuIconMap } from "@/layouts/core/utils/transform-route";

/**
 * 后端 `menu.icon` 字符串 → 前端图标组件 映射表。
 * 后端目前下发的是 el-icon-* 命名（兼容旧 vue 系统的图标库），前端按需在这里登记对应的 lucide 组件即可。
 * 未登记的 key 会渲染为无图标，不会报错。
 */
export const menuIcons: MenuIconMap = {
  "book-a": BookA, // 值域数据
  "book-alert": BookAlert, // 数据字典(自建)
  "book-audio": BookAudio, // 数据字典(统建)
  "book-check": BookCheck, // 字典维护申请
  database: Database, // 基础主数据

  "map-plus": MapPlus, // 国家与地区
  "map-pin-plus": MapPinPlus, // 境内行政区划
  "locate-fixed": LocateFixed, // 中交区域中心
  "map-pin-minus": MapPinMinus, // 境外行政区划
  hospital: Hospital, // 中交区域总部
  "ruler-dimension-line": RulerDimensionLine, // 常用计量单位
  boxes: Boxes, // 国民经济分类
  "receipt-text": ReceiptText, // 发票类型
  earth: Earth, // 大洲
  "circle-dollar-sign": CircleDollarSign, // 币种
  languages: Languages, // 语种

  "database-zap": DatabaseZap, // 业务主数据
  "layout-dashboard": LayoutDashboard, // 设备分类
  package: Package, // 物资设备
  route: Route, // 往来单位
  landmark: Landmark, // 金融机构
  layers: Layers, // 科研项目
  "ship-wheel": ShipWheel, // 数字化项目

  "book-user": BookUser, // 组织人员管理
  network: Network, // 机构管理
  "user-cog": UserCog, // 人员管理
  users: Users, // 管理团队
  "notepad-text": NotepadText, // 4A同步日志

  "shield-cog": ShieldCog, // 统一角色管理
  group: Group, // 岗位管理
  "user-round": UserRound, // 角色管理
  "user-key": UserKey, // 按角色授权
  vault: Vault, // 按组织授权
  "vector-square": VectorSquare, // 角色矩阵配置

  "rotate-3d": Rotate3d, // 对接注册管理
  "layers-plus": LayersPlus, // 应用注册配置
  "link-2-off": Link2Off, // 对接注册配置
  "message-square-text": MessageSquareText, // 推送日志

  link: Link, // API 市场

  "monitor-cog": MonitorCog, // 系统管理
  menu: Menu, // 菜单管理
  "columns-3-cog": Columns3Cog, // 授权管理
  component: Component, // 分级授权
  logs: Logs, // 集成日志
  navigation: Navigation, // 任务调度中心
};
