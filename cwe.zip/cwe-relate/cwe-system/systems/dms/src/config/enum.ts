// typescript 现在不推荐使用 enum 不可擦除语法
export const RequestEnum = {
  TOKEN_CACHE: "cwe_dms_token",
  TOKEN_HEADER: "Authorization",
} as const;
