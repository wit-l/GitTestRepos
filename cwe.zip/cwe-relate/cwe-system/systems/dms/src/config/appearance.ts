import type { ThemeConfig } from "antd";

import { LAYOUT_HEADER_HEIGHT } from "./constants";

export const componentConfig: ThemeConfig["components"] = {
  Layout: {
    headerHeight: LAYOUT_HEADER_HEIGHT,
    headerPadding: 16,
  },
};

export type LayoutPresetModeType = (typeof LayoutPresetMode)[keyof typeof LayoutPresetMode];
export const LayoutPresetMode = {
  Side_Nav: "side-nav",
  Top_Nav: "top-nav",
  Two_Column_Nav: "two-column-nav",
  Mixed_Nav: "mixed-nav",
} as const;
