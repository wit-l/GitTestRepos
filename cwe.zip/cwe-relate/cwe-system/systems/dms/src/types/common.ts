export interface R<D = any> {
  success: number;
  msg: string;
  data: D;
}

export interface List<D = any> {
  current: number;
  records: D[];
  size: number;
  total: number;
}
