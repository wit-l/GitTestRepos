// https://cn.vitejs.dev/guide/env-and-mode#intellisense-for-typescript
/// <reference types="vite-plugin-svgr/client" />

interface ViteTypeOptions {
  strictImportMetaEnv: unknown;
}

interface ImportMetaEnv {
  /** @description 网站标题 */
  readonly VITE_APP_TITLE: string;
  /** @description 后端接口 api 地址 */
  readonly VITE_API_URL: string;
  /** @description 代理前缀 */
  readonly VITE_API_BASE_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

declare namespace NodeJS {
  interface ProcessEnv extends ImportMetaEnv {}
}

/* Inspired by https://github.com/soybeanjs/soybean-admin/blob/v1.3.8/src/typings/global.d.ts */
interface Window {
  $message: import("antd/es/message/interface").MessageInstance;
  $modal: Omit<import("antd/es/modal/confirm").ModalStaticFunctions, "warn">;
  $notification: import("antd/es/notification/interface").NotificationInstance;
}
