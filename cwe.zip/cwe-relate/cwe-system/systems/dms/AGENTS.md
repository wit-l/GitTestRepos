# AGENTS.md — @cwe/dms

> 主业务网站。本文件叠加在仓库根 `AGENTS.md` 之上。

## 技术栈

- React 19（react-compiler） + TypeScript + TanStack Router
- Tailwindcss v3 + Antd v6 + tailwind-preset-antd（统一tw前缀 `a-`）
- zustand、ahooks、dayjs、axios、immer、es-toolkit

## 目录约定

```
src/
├── main.tsx            # 项目入口、全局组件配置
├── router.ts           # createTanstackRouter
├── routeTree.gen.ts    # tanstack router 自动生成，禁止修改
├── pages/              # 文件路由根（vite.config.ts 中 routesDirectory）
│   ├── __root.tsx
│   ├── _auth/          # 需登录才可访问的页面
│   └── ...
├── config/env.ts       # 仅暴露客户端环境变量 import.meta.env.VITE_*
└── utils               # 常用业务工具函数
└── ...
```

## 路由（TanStack Router）

- 文件路由根目录：`src/pages`，自动生成 `routeTree.gen.ts`。
- **被忽略**为路由的文件名模式（在 `vite.config.ts` 配置），也可用 `-` 前缀。

## 请求（Tanstack React Query）

按照 [The Query Options API](https://tkdodo.eu/blog/the-query-options-api) 中管理 queryKey

## 样式策略

1. **首选 Tailwind**：项目使用前缀 `a-`，因此原生 Tailwind class 写作 `bg-a-colorPrimary`。颜色全走 antd token（由 `tailwind-preset-antd` 注入为 CSS 变量）。
2. CSS-in-JS 仅在必要时用 [goober](https://goober.js.org/)（2kb），**不要**引入 emotion / styled-components。
3. 全局样式优先级：原生 css > react `<style>` 标签 > goober `createGlobalStyles`。
4. 消费 antd token 的优先级：tw 自定义属性 > antd CSS Var > `theme.useToken()`。

## 状态管理与数据请求

- 全局状态用 zustand，正常情况下使用 store 的 `useXXSelector`，只有在非 hook 环境下用 `useXXStore`。
- 状态不可变更新用 `immer`；浅比较用 `react-fast-compare`。

## 行为约束

- 写或重构 React 代码时，先调用 `vercel-react-best-practices` skill。
- **不要**编辑 `src/routeTree.gen.ts`。
- **不要**在 page 文件里写非路由代码——按项目中 vite.config.ts 中的 `routeFileIgnorePattern` 约定命名拆分。
- 添加客户端环境变量 `import.meta.env.VITE_*` 时，同步到 `src/config/env.ts` 的 `clientEnv`。
