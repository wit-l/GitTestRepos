import tailwindPresetAntd from "tailwind-preset-antd/plugin";
import type { Config } from "tailwindcss/types/config";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  corePlugins: {
    preflight: false,
  },
  theme: {
    colors: {}, // 禁用 tw 内置颜色
  },
  safelist: ["lucide"], // 防止 lucide 的重置样式被 tw tree shake 掉
  plugins: [tailwindPresetAntd({ twPrefix: "a" })],
};

export default config;
