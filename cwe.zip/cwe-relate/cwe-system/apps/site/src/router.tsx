import { CweGeneralErrorPage, CweNotFoundPage } from "@cwe/site-layout";
import type { CwePageContainerProps } from "@cwe/site-layout";
import { createRouter as createTanStackRouter } from "@tanstack/react-router";

import { routeTree } from "./routeTree.gen";

export const router = createTanStackRouter({
  routeTree,
  scrollRestoration: true,
  defaultPreload: "intent",
  defaultPreloadStaleTime: 0,
  defaultNotFoundComponent: () => <CweNotFoundPage />,
  defaultErrorComponent: (props) => <CweGeneralErrorPage errMsg={props.error.stack} />,
});

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }

  interface StaticDataRouteOption {
    /**
     * @description 页面标题，若设置，则会自动拼接网站标题
     */
    title?: string;
    /**
     * @description 配置 CwePageContainer 使用此参数针对某个页面进行单独的样式配置
     */
    layoutConfig?: Omit<CwePageContainerProps, "children" | "username">;
  }
}
