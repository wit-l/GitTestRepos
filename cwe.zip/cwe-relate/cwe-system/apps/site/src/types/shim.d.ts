/// <reference types="vite-plugin-svgr/client" />

interface ViteTypeOptions {
  // https://cn.vite.dev/guide/env-and-mode#intellisense-for-typescript
  strictImportMetaEnv: unknown;
}

interface ImportMetaEnv {
  readonly VITE_APP_TITLE: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
