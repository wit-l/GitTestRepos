import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/qr-code")({
  component: RouteComponent,
  staticData: {
    title: "扫码登陆",
  },
});

/**
export const Route = createFileRoute('/login')({
  validateSearch: z.object({
    redirect: z.string().optional().catch(''),
  }),
  beforeLoad: ({ context, search }) => {
    if (context.auth.isAuthenticated) {
      throw redirect({ to: search.redirect || fallback })
    }
  },
  component: LoginComponent,
})
 */

/**
    // WwLogin({
    //   id: "qr-code",
    //   // appid: "wl2c5e89d5c4",
    //   // agentid: "1003276",
    //   // redirect_uri: encodeURIComponent("https://cloud.cwe.cn/platformsso/sys/jjt/login/oauth2/code/platformsso"),
    //   // appid: "wl2c5e89d5c4",
    //   // agentid: "1002806",
    //   // redirect_uri: encodeURIComponent("https://cloud.cwe.cn/platformsso/sys/jjt/login/oauth2/code/platformsso"),
    //   // redirect_uri: encodeURIComponent(`${window.location.origin}redirect=/}`),
    //   state: "cloud-f13cbd3000eb1611624446d678e6bbf5",
    // });

 */
function RouteComponent() {
  return (
    <>
      {/* <div id="qr-code"></div> */}
      Hello "/(qr-code)/" Index!
    </>
  );
}
