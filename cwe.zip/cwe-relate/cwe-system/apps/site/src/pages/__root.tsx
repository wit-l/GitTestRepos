import { TanStackDevtools } from "@tanstack/react-devtools";
import { createRootRoute, Outlet, useMatches } from "@tanstack/react-router";
import { TanStackRouterDevtoolsPanel } from "@tanstack/react-router-devtools";
import { useTitle } from "ahooks";

import { clientEnv } from "@/config/env";

export const Route = createRootRoute({
  component: RootComponent,
});

function RootComponent() {
  const metaTitle = useMatches({
    select: (matches) => matches.findLast((item) => item.staticData.title)?.staticData.title,
  });
  const documentTitle = metaTitle ? `${metaTitle} - ${clientEnv.VITE_APP_TITLE}` : clientEnv.VITE_APP_TITLE;
  useTitle(documentTitle);

  return (
    <>
      <Outlet />
      {clientEnv.DEV && (
        <TanStackDevtools
          config={{ position: "bottom-right" }}
          plugins={[{ name: "TanStack Router", render: <TanStackRouterDevtoolsPanel /> }]}
        />
      )}
    </>
  );
}
