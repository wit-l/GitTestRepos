import { Link } from "@tanstack/react-router";
import { Card, Tabs } from "antd";
import type { TabsProps } from "antd";
import { ChevronRight } from "lucide-react";

import styles from "./style.module.css";

interface SectionCardTabsProps extends TabsProps {
  extraContentLink?: string;
}

export default function SectionCardTabs(props: SectionCardTabsProps) {
  const { extraContentLink, children, ...restProps } = props;
  return (
    <Card size="small">
      <Tabs
        size="small"
        tabBarGutter={24}
        {...restProps}
        classNames={{
          header: styles["header"],
          item: styles["item"],
          indicator: styles["indicator"],
          ...props.classNames,
        }}
        tabBarExtraContent={
          extraContentLink && (
            <Link to={extraContentLink} className={styles["extra-content"]}>
              <ChevronRight />
            </Link>
          )
        }
      />
      {children}
    </Card>
  );
}
