import { CwePageContainer } from "@cwe/site-layout";
import { createFileRoute, Outlet, useMatches } from "@tanstack/react-router";
import { toMerged } from "es-toolkit/object";

export const Route = createFileRoute("/_auth")({
  component: RouteComponent,
  beforeLoad(_ctx) {
    console.log(_ctx);

    // throw redirect({
    //   to: "/qr-code",
    //   search: {
    //     redirect: _ctx.location.href,
    //   },
    // });
  },
});

function RouteComponent() {
  const layoutConfig = useMatches({
    select: (matches) =>
      matches
        .map((item) => item.staticData.layoutConfig || {}) // 每个层级都会进行合并，子路由可以继承父路由的配置
        .reduce((acc, curr) => toMerged(acc, curr), {}),
  });

  return (
    <CwePageContainer username="焦松奇" {...layoutConfig}>
      <Outlet />
    </CwePageContainer>
  );
}
