import { Link } from "@tanstack/react-router";
import dayjs from "dayjs";

import { cn } from "@/utils/cn";

import userPartingbarImg from "../assets/index-user-partingbar.png";
import utilsPartingbarImg from "../assets/index-utils-partingbar.png";
import AccountIcon from "../icons/account-icon";
import AppDownloadIcon from "../icons/app-download-icon";
import MealCardIcon from "../icons/meal-card-icon";
import MeetIcon from "../icons/meet-icon";
import TechSupportIcon from "../icons/tech-support-icon";
import UseUtilIcon from "../icons/use-util-icon";

import styles from "./style.module.css";

const date = dayjs().format("MM.DD");
const day = dayjs().format("dddd");
const menuConfig = [
  { title: "会议申请", href: "#", icon: <MeetIcon /> },
  { title: "技术支持", href: "#", icon: <TechSupportIcon /> },
  { title: "账号申请", href: "#", icon: <AccountIcon /> },
  { title: "餐卡充值", href: "#", icon: <MealCardIcon /> },
  { title: "软件下载", href: "#", icon: <AppDownloadIcon /> },
];

export default function SideList() {
  return (
    <>
      <div className={styles["userinfo-section"]}>
        <div className={styles["avatar"]}></div>
        <span className={styles["username"]}>焦松奇</span>
        <span className={styles["deptname"]}>业务支持保障中心</span>
        <img src={userPartingbarImg} className="w-full" alt="" />
        <span className={styles["date"]}>
          {date} | {day}
        </span>
        <img src={userPartingbarImg} className="w-full" />
      </div>

      <div className={cn(styles["use-util-section"], "flex-1")}>
        <div className={styles["title"]}>
          <UseUtilIcon />
          <span>常用工具</span>
        </div>
        <img src={utilsPartingbarImg} className="w-full" />
        <ul className={styles["menu-section"]}>
          {menuConfig.map((item) => (
            <li key={item.title}>
              <Link to={item.href} className={styles["menu-item"]}>
                {item.icon}
                <span>{item.title}</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
}
