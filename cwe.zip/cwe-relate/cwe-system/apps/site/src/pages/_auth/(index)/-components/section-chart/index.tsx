import SectionCardTabs from "../sectio-card-tabs";

export default function SectionChart() {
  return (
    <SectionCardTabs
      extraContentLink="#"
      items={[
        { label: "电量", key: "electric" },
        { label: "水情", key: "water" },
      ]}
    ></SectionCardTabs>
  );
}
