import { Link } from "@tanstack/react-router";
import { ClipboardList, FileSliders, MapPinPlus, UserRoundPlus } from "lucide-react";

import styles from "./style.module.css";

const navItem = [
  {
    title: "中国交建门户",
    href: "http://cwe.ccccltd.cn/",
    icon: <UserRoundPlus />,
    gradationColor: ["#34D5F7", "#26A6E1"],
    iconBgColor: "#0E93D0",
  },
  {
    title: "财务资源管理",
    href: "#",
    icon: <FileSliders />,
    gradationColor: ["#E2A3EF", "#907DBC"],
    iconBgColor: "#7763A7",
  },
  {
    title: "市场开发管理",
    href: "#",
    icon: <MapPinPlus />,
    gradationColor: ["#FFE293", "#C68E65"],
    iconBgColor: "#B4794E",
  },
  {
    title: "外事管理平台",
    href: "#",
    icon: <ClipboardList />,
    gradationColor: ["#CCDF49", "#7EA237"],
    iconBgColor: "#6C9123",
  },
];

export default function NavSwiper() {
  return (
    <div className={styles["nav-swiper"]}>
      {navItem.map((item) => (
        <Link
          key={item.title}
          target="_blank"
          to={item.href}
          className={styles["nav-swiper-item"]}
          style={{
            background: `radial-gradient(circle at 100% 0%, ${item.gradationColor[0]}, ${item.gradationColor[1]} 50%)`,
          }}
        >
          <div className={styles["icon-wrapper"]} style={{ backgroundColor: item.iconBgColor }}>
            {item.icon}
          </div>
          {item.title}
        </Link>
      ))}
    </div>
  );
}
