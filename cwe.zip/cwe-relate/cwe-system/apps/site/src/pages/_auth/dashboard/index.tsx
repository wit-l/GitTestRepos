import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/dashboard/")({
  component: RouteComponent,

  staticData: {
    title: "Dashboard",
    layoutConfig: {
      classNames: {
        header: "bg-red-600",
        section: "w-4/6 min-w-0",
      },
    },
  },
});

function RouteComponent() {
  return <div className="bg-a-colorPrimary">Hello "/(authenticated)/dashboard/"!</div>;
}
