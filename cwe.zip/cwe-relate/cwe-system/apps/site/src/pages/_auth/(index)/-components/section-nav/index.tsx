import {
  ApartmentOutlined,
  AuditOutlined,
  BookOutlined,
  FileProtectOutlined,
  FileSyncOutlined,
  FormOutlined,
  LineChartOutlined,
  ReadOutlined,
} from "@ant-design/icons";
import { Link } from "@tanstack/react-router";

import SectionCardTabs from "../sectio-card-tabs";

import styles from "./style.module.css";

const navConfig = [
  { title: "内网签报", href: "#", icon: <FormOutlined /> },
  { title: "部门业务", href: "#", icon: <ApartmentOutlined /> },
  { title: "公司党建", href: "#", icon: <ReadOutlined /> },
  { title: "规章制度", href: "#", icon: <FileSyncOutlined /> },
  { title: "印章管理", href: "#", icon: <AuditOutlined /> },
  { title: "授权委托", href: "#", icon: <BookOutlined /> },
  { title: "法制合规", href: "#", icon: <FileProtectOutlined /> },
  { title: "风险内控", href: "#", icon: <LineChartOutlined /> },
];

export default function SectionNav() {
  return (
    <SectionCardTabs extraContentLink="#" items={[{ label: "业务导航", key: "nav" }]}>
      <ul className="grid grid-cols-4 gap-4 px-2">
        {navConfig.map((item) => (
          <li key={item.title}>
            <Link to={item.href} className={styles["nav-item"]}>
              {item.icon}
              {item.title}
            </Link>
          </li>
        ))}
      </ul>
    </SectionCardTabs>
  );
}
