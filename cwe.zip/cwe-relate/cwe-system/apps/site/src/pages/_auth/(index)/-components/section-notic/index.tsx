import { Link } from "@tanstack/react-router";

import SectionCardTabs from "../sectio-card-tabs";

const mockData = [
  { title: "关于开展喀麦隆有限责任公司总经理于永任中经济责任审计的通知", href: "#", date: "2023-09-22" },
  { title: "关于开展喀麦隆有限责任公司总经理于永任中经济责任审计的通知", href: "#", date: "2023-09-22" },
  { title: "关于开展喀麦隆有限责任公司总经理于永任中经济责任审计的通知", href: "#", date: "2023-09-22" },
  { title: "关于开展喀麦隆有限责任公司总经理于永任中经济责任审计的通知", href: "#", date: "2023-09-22" },
  { title: "关于开展喀麦隆有限责任公司总经理于永任中经济责任审计的通知", href: "#", date: "2023-09-22" },
];

export default function SectionNotic() {
  return (
    <SectionCardTabs
      extraContentLink="#"
      items={[
        { label: "通知", key: "notice" },
        { label: "公告", key: "publicity" },
      ]}
    >
      <ul className="flex flex-col [&>li]:p-a-marginXS">
        {mockData.map((item, index) => (
          <li key={index} className="border-b border-b-a-colorBorderSecondary">
            <Link to={item.href} className="flex justify-between gap-1 text-inherit hover:text-a-colorPrimary">
              <span className="line-clamp-1">{item.title}</span>
              <span className="flex-shrink-0">{item.date}</span>
            </Link>
          </li>
        ))}
      </ul>
    </SectionCardTabs>
  );
}
