import { createFileRoute } from "@tanstack/react-router";
import { Col, Row } from "antd";

import NavSwiper from "./-components/nav-swiper";
import SectionChart from "./-components/section-chart";
import SectionNav from "./-components/section-nav";
import SectionNotic from "./-components/section-notic";
import SectionToDo from "./-components/section-todo";
import SideList from "./-components/side-list";

export const Route = createFileRoute("/_auth/(index)/")({
  component: RouteComponent,
});

function RouteComponent() {
  return (
    <Row gutter={20}>
      <Col span={4} className="flex flex-col">
        <SideList />
      </Col>
      <Col span={20} className="flex flex-col gap-5">
        <NavSwiper />
        <div className="grid grid-cols-2 gap-5">
          <SectionNotic />
          <SectionToDo />
          <SectionChart />
          <SectionNav />
        </div>
      </Col>
    </Row>
  );
}
