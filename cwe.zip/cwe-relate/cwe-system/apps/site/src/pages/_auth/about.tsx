import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth/about")({
  component: RouteComponent,
  staticData: {
    layoutConfig: {
      fullscreen: true,
    },
  },
});

function RouteComponent() {
  return (
    <div>
      Hello "/about"!
      <p>这个页面是 fullScreen</p>
    </div>
  );
}
