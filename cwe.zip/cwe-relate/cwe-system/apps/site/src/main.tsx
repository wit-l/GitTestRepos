import { StyleProvider } from "@ant-design/cssinjs";
import { RouterProvider } from "@tanstack/react-router";
import { App as AntdApp, ConfigProvider } from "antd";
import zhCN from "antd/es/locale/zh_CN";
import dayjs from "dayjs";
import { createRoot } from "react-dom/client";
import AntdTokenCssVar from "tailwind-preset-antd/components";
import "dayjs/locale/zh-cn";

import "./styles/global.css";
import { clientEnv } from "./config/env";
import { router } from "./router";

dayjs.locale("zh-cn");

createRoot(document.getElementById("root")!).render(
  <StyleProvider layer>
    <ConfigProvider locale={zhCN} theme={{ hashed: false, zeroRuntime: true }}>
      <AntdTokenCssVar />
      <AntdApp className="h-full w-full">
        <RouterProvider basepath={clientEnv.BASE_URL} router={router} />
      </AntdApp>
    </ConfigProvider>
  </StyleProvider>
);
