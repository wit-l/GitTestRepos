export const clientEnv = {
  VITE_APP_TITLE: import.meta.env.VITE_APP_TITLE,
  DEV: import.meta.env.DEV,
  PROD: import.meta.env.PROD,
  BASE_URL: import.meta.env.BASE_URL,
};
