import { fileURLToPath } from "node:url";

import babel from "@rolldown/plugin-babel";
import { tanstackRouter } from "@tanstack/router-plugin/vite";
import legacy from "@vitejs/plugin-legacy";
import react, { reactCompilerPreset } from "@vitejs/plugin-react";
import { defineConfig, loadEnv } from "vite";

// https://vite.dev/config/
export default defineConfig((config) => {
  const env = loadEnv(config.mode, process.cwd());

  return {
    resolve: {
      alias: {
        "@": fileURLToPath(new URL("src", import.meta.url)),
      },
    },
    plugins: [
      tanstackRouter({
        target: "react",
        autoCodeSplitting: true,
        routesDirectory: "./src/pages",
        routeFileIgnorePattern: "(style|util|data).ts|components|utils|hooks",
      }),
      react(),
      babel({ presets: [reactCompilerPreset()] }),
      legacy({
        // https://cn.vite.dev/guide/build#browser-compatibility
        // https://juejin.cn/post/7520478620043542547
        // 默认的 legacy 配置是为了兼容非 type="module" 会生成 legacy的 js文件（相当于两份打包，一份 module 一份 nomodule）
        // 默认配置并不是对 js 语法转换，而是对 type="module" 的转换
        // 以下配置生成的是正确的针对现代浏览器的 polyfill js 而非 legacy
        modernTargets: ["Chrome>=99", "Safari>=15.4", "Firefox>=97"], // @layer 的兼容性
        modernPolyfills: true, // 添加 polyfill 到现代 bundle 中
        renderLegacyChunks: false, // 禁用 legacy 的生成，仅支持现代浏览器，因为 chrome 99 早已支持 type="module"
      }),
    ],
    server: {
      port: 8000,
      cors: true,
      proxy: {
        [env.VITE_API_BASE_URL]: {
          target: env.VITE_API_URL,
          changeOrigin: true,
          rewrite: (path) => path.replace(new RegExp(`^${env.VITE_API_BASE_URL}`), ""),
        },
      },
    },
    build: {
      rolldownOptions: {
        experimental: {
          lazyBarrel: true,
        },
        output: {
          entryFileNames: "js/[name].[hash].js",
          chunkFileNames: "js/async/[name].[hash].js",
          // https://rolldown.rs/reference/OutputOptions.codeSplitting#codesplitting
          codeSplitting: {
            groups: [
              {
                name: "lib-react",
                test: /node_modules[\\/](react|react-dom)[\\/]/, // react react-dom
                priority: 0,
              },
            ],
          },
        },
      },
    },
  };
});
