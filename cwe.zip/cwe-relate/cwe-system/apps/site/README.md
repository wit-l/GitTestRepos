# 项目介绍

相关核心库

- react 19 + typescript
- tanstack router
- antd
- tailwindcss v4
- zustand
- vite

**zeroRuntime 的可选性**

使用 antd v6 [zero runtime](https://ant-design.antgroup.com/docs/react/customize-theme-cn#zero-runtime)，以打包体积换取更优的性能，增加 900kb+ 的 css 体积，提升 30% 左右的性能。

在不使用 `Typography` 组件的情况下，zeroRuntime 的性能可能与 v4 较为接近，来源为核心维护者回复 [issue](https://github.com/ant-design/ant-design/issues/57294)

在消费 antd token 时，首先推荐使用 tw 的自定义属性（见下文），其次使用 antd 的 cssVar，尽量避免直接使用 token 变量

## 整体设计

### 路由

使用 tanstack router 的文件路由系统，配置中，所有 `src/pages` 目录下的文件都会被视为路由，如果要让 tanstack router 不视为路由，则添加 `-` 前缀即可，见：[routeFileIgnorePattern](https://tanstack.com.cn/router/latest/docs/api/file-based-routing#routefileignoreprefix)

### 布局配置

网站曾经的设计：由于每个页面的全局布局可能略有不同，比如：页面宽度不同、不需要 footer 布局，全屏展示等，只能在每个页面单独引入布局组件进行传参配置。

现在：得益于 tanstack router 的灵活性，使得布局问题的解决很方便。只需要在每个页面创建的时候，通过 `createFileRoute` 传递布局配置 `staticData.layout` 即可（类似 react router 的 `handle ` 属性）。

```js
export const Route = createFileRoute("/_authenticated/dashboard/")({
  component: RouteComponent,
  staticData: {
    layout: {
      fullScreen: true, // 将会在当前页面开启全屏模式的布局
      styles: {
        header: { backgroundColor: "red" }, // 头部 red 背景色
      },
      // ...
    },
  },
});
```

相关链接：

- [staticData](https://tanstack.com/router/latest/docs/guide/static-route-data)
- [When to Use staticData vs Context](https://tanstack.com/router/latest/docs/guide/static-route-data#when-to-use-staticdata-vs-context)

### CSS 方案

#### Tailwindcss

大部分场景下推荐使用 tailwindcss，其中关于 antd 的核心主题色已转换为 tailwind 自定义属性，可在全局使用。

如果样式较为复杂，使用 tailwindcss 可能会造成维护困难，推荐使用 css module。CSS 语法在现代浏览器支持类 SASS 的 [CSS Nesting](https://developer.mozilla.org/zh-CN/docs/Web/CSS/Guides/Nesting)，此处使用 [postcss-nesting](https://www.npmjs.com/package/postcss-nesting) 进行语法降级以拥有较好的兼容性。

#### Css in JS

如需使用 css in js，推荐使用轻量级的 [goober](https://goober.js.org)，仅 2kb

#### 全局样式

1. 优先使用 css
2. 使用 react 自带的 [style](https://zh-hans.react.dev/reference/react-dom/components/style)
3. 使用 goober [createGlobalStyle](https://goober.js.org/api/createGlobalStyles)
