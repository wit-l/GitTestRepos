#!/bin/bash

node -v
npm -v
npm i pnpm -g
corepack enable
pnpm install
pnpm build:site

cd ./apps/site

IMAGE_NAME="site-app"
CONTAINER_NAME="site-app"

docker stop $CONTAINER_NAME
docker rm $CONTAINER_NAME
docker rmi $IMAGE_NAME

docker build -t $IMAGE_NAME -f Dockerfile .
docker run -d -p 3000:3000 --name $CONTAINER_NAME $IMAGE_NAME
