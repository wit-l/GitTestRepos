import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { cors } from 'hono/cors'
import * as fs from "fs";
import { fileURLToPath } from "url";
import { join, dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = new Hono();

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

app.use('/*', cors())

// 定义数据目录路径
const dataDir = join(__dirname, "../data");

// 读取并提供 login.json 数据
app.get("/test-online/platform/platform-system/sys/login/code/v1.0", async (c) => {
  const loginDataPath = join(dataDir, "login.json");

  const loginData = JSON.parse(fs.readFileSync(loginDataPath, "utf-8"));
  return c.json(loginData);
});

app.get("/test-online/system-server/sys/userInfo/rolesAndmenus", async (c) => {
  const roleMenusDataPath = join(dataDir, "roleMenusNew.json");

  const roleMenusData = JSON.parse(fs.readFileSync(roleMenusDataPath, "utf-8"));
  return c.json(roleMenusData);
});

app.get("/test-online/system-server/sys/userInfo/v1.0", async (c) => {
  const userInfoDataPath = join(dataDir, "userInfo.json");
  const userInfoData = JSON.parse(fs.readFileSync(userInfoDataPath, "utf-8"));
  return c.json(userInfoData);
});

app.get("/", (c) => {
  return c.text(
    "Mock server is running! Access data through /online prefix.\nAvailable endpoints: /online/login, /online/roleMenus, /online/userInfo"
  );
});

serve(
  {
    fetch: app.fetch,
    port: 30015,
    hostname: "127.0.0.1"
  },
  (info) => {
    console.log(`Server is running on http://${info.address}:${info.port}`)
  }
);
